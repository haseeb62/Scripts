#!/bin/bash

# Directory containing directories to enter
parent_dir="/Users/haseeb/Desktop/TA assignment/Submission/Programming Assignment 1"

csv_file="/Users/haseeb/Desktop/TA assignment/Submission/Programming Assignment 1/grades2.csv"
# Get a list of directories in the parent directory
find "$parent_dir" -mindepth 1 -maxdepth 1 -type d -print0 | while IFS= read -r -d '' dir
do
  cd "$dir" 
  # Do something in the directory
  # cd "Submission attachment(s)"
  echo "$dir"
  number=$(echo "$dir" | grep -oE '\(([0-9]+)\)' | sed 's/[()]//g')
  echo "$number"
  cd "Submission attachment(s)"
  cp /Users/haseeb/Desktop/TA\ assignment/Submission/Test/* .
  g++ test1.cpp -std=c++11
  part1=$(./a.out | awk '/Total Points:/ {print $NF}')
  g++ test2.cpp -std=c++11
  part2=$(./a.out | awk '/Total Points:/ {print $NF}')
  # Run the C++ program and capture the output

  # part 3
  g++ test3.cpp -std=c++11
  part3="0/30"
  if /usr/local/bin/timeout 5 ./a.out 100 | awk '/Total Score:/ {print $NF}'; then
    part3=$(./a.out 100 | awk '/Total Score:/ {print $NF}')
  else
    part3="timeout"
  fi
  # part 4
  g++ test4.cpp -std=c++11
  # part4=$(./a.out 100| awk '/Total score:/ {print $NF}')
  # part3="0/30"
  if /usr/local/bin/timeout 5 | awk '/Total score:/ {print $NF}'; then
    part4=$(./a.out 100 | awk '/Total score:/ {print $NF}')
  else
    part4="timeout"
  fi

  # Add the marks to the grades.csv file
  echo "$number,$part3,$part4" >> "$csv_file"
  cd - || exit
done