#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <cmath>
#include <stack>

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	directed = flag;

	fstream file;
	file.open(filename, ios::in);
	if(! file.is_open())
	{
		cout << "File failed to open\n";
		exit(1);
	}
	string line;
	while(getline(file,line))
	{
		if(line.substr(0,1) == "n")
		{
			continue;
		}
		else if(line.substr(0,1) == "c")
		{
			continue;
		}
		else
		{
			char start = line[0];
			char end = line[2];
			int weight = stoi(line.substr(4,-1));

			if(directed)
			{
				if(!out_vertices.count(start))
				{
					order_graph[size++] = start;
					out_vertices.insert(start);
					all_vertices.insert(start);
					all_vertices.insert(end);
					in_vertices.insert(end);
					graph.push_back(list <shared_ptr<Edge>>());
					addEdge(start,end,weight,directed);
				}
				else
				{
					all_vertices.insert(end);
					in_vertices.insert(end);
					addEdge(start,end,weight,directed);
				}
			}
			else
			{
				if((!all_vertices.count(start)) && (!all_vertices.count(end)))
				{
					order_graph[size++] = start;
					order_graph[size++] = end;
					all_vertices.insert(start);
					out_vertices.insert(start);
					in_vertices.insert(end);
					all_vertices.insert(end);
					graph.push_back(list <shared_ptr<Edge>>());
					graph.push_back(list <shared_ptr<Edge>>());
				}
				else if(!all_vertices.count(start))
				{
					order_graph[size++] = start;
					all_vertices.insert(start);
					out_vertices.insert(start);
					in_vertices.insert(end);
					all_vertices.insert(end);
					graph.push_back(list <shared_ptr<Edge>>());
				}
				else if(!all_vertices.count(end))
				{
					order_graph[size++] = end;
					in_vertices.insert(end);
					all_vertices.insert(end);
					all_vertices.insert(start);
					out_vertices.insert(start);
					graph.push_back(list <shared_ptr<Edge>>());
				}
				addEdge(start,end,weight,directed);
			}
		}

	}

}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	bool directed_inserted = false;
	for(int i = 0; i<size; i++)
	{
		if(order_graph[i] == start)
		{
			graph[i].push_back(shared_ptr<Edge> (new Edge(start,end,weight)));
			if(directed)
			{
				return;
			}
			else
			{
				directed_inserted = true;
			}
		}
		if(!directed && (order_graph[i] == end))
		{
			graph[i].push_back(shared_ptr<Edge> (new Edge(end,start,weight)));
			if(directed_inserted)
			{
				return;
			}
		}
	}
	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	string display = "";
	for(int i = 0; i<size;i++)
	{
		for(list<shared_ptr<Edge>>::iterator j = graph[i].begin(); j!= graph[i].end(); j++)
		{
			string s = "";
			s.append(1,(*j)->origin);
			string e = "";
			e.append(1,(*j)->dest);
			string w = to_string((*j)->weight);
			if(j != graph[i].end())
			display += "(" + s + "," + e + "," + w + ") ";
			else
			display += "(" + s + "," + e + "," + w + ")";
		}
		if(i != size -1)
		display += "\n";
	}
	return display;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	if(start == end)
	{
		return true;
	}

	bool reachable = false; 

	set<char> visited;
	list<char> not_visited;
	visited.insert(start);

	int index = 0;

	for(int i = 0; i<size; i++)
	{
		if(order_graph[i] == start)
		{
			index = i;

			for(list<shared_ptr<Edge>>::iterator j = graph[i].begin(); j!= graph[i].end(); j++)
			{
				if(!visited.count((*j)->dest))
				{
					not_visited.push_front((*j)->dest);
				}
			}

			break;
		}
	}

	while(!not_visited.empty())
	{
		char v = not_visited.front();
		if(v == end)
		{
			return true;
		}
		not_visited.pop_front();
		visited.insert(v);
		for(int i = 0; i<size; i++)
		{
			if(order_graph[i] == v)
			{
				index = i;

				for(list<shared_ptr<Edge>>::iterator j = graph[i].begin(); j!= graph[i].end(); j++)
				{
					if(!visited.count((*j)->dest))
					{
						not_visited.push_front((*j)->dest);
					}
				}

				break;
			}
		}

	}


	return reachable;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//


int Graph::Dijkstra(char start, char dest)
{
	if(start == dest)
	{
		return 0;
	}

	int total_weight = 0;
	set <char> frontier_set;
	set <char> visited_set;
	list<char> frontier_list;
	int n = 0;
	vector<char> frontier;
	vector<int> costs;

	visited_set.insert(start);

	for(int i = 0; i<size;i++)
	{
		if(order_graph[i]==start)
		{
			for(list<shared_ptr<Edge>>::iterator j = graph[i].begin(); j!= graph[i].end(); j++)
			{
				// if(((*j)->dest) == dest)
				// {
				// 	return ((*j)->weight);
				// }
				frontier_set.insert((*j)->dest);
				frontier_list.push_back((*j)->dest);
				frontier.push_back((*j)->dest);
				costs.push_back((*j)->weight);
				n++;
			}
			break;
		}
		
	}

	int min_cost = *min_element(costs.begin(), costs.end());
	int index = find(costs.begin(), costs.end(), min_cost) - costs.begin();
	char node = frontier[index];
	visited_set.insert(node);
	frontier_list.remove(node);
	frontier_set.erase(index);
	costs.erase(costs.begin() + index);
	frontier.erase(frontier.begin() + index);
	n--;

	if(node == dest)
	{
		return min_cost;
	}

	while(!frontier_list.empty())
	{
		// int min_cost = *min_element(costs, costs + n);
		// int index = find(costs, costs + n, min_cost) - costs;
		// char node = frontier[index];
		// visited_set.insert(node);

		// if(node == dest)
		// {
		// 	return min_cost;
		// }

		for(int i = 0; i<size;i++)
		{
			if(order_graph[i]==node)
			{
				for(list<shared_ptr<Edge>>::iterator j = graph[i].begin(); j!= graph[i].end(); j++)
				{
					// if(((*j)->dest) == dest)
					// {
					// 	return ((*j)->weight);
					// }
					if(frontier_set.count((*j)->dest) == 0)
					{
						frontier_set.insert((*j)->dest);
						frontier_list.push_back((*j)->dest);
						frontier.push_back((*j)->dest);
						costs.push_back(((*j)->weight) + min_cost);
						n++;
					}
					else
					{
						for(int k = 0; k<n; k++)
						{
							if(frontier[k] == (*j)->dest)
							{
								int alt_cost = ((*j)->weight) + min_cost;
								if(alt_cost < costs[k])
								{
									costs[k] = alt_cost;
								}
								break;
							}
						}
					}
				}
				break;
			}
			
		}

		min_cost = *min_element(costs.begin(), costs.end());
		index = find(costs.begin(), costs.end(), min_cost) - costs.begin();
		node = frontier[index];
		visited_set.insert(node);
		frontier_list.remove(node);
		frontier_set.erase(node);
		costs.erase(costs.begin() + index);
		frontier.erase(frontier.begin() + index);
		n--;

		if(node == dest)
		{
			return min_cost;
		}
	}
	return -1;
}


//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	string topo_order = "";
	int s = all_vertices.size();
	int* indegree = new int[s]{0};
	char* vertices = new char[s];
	// set <int> in_vertices = 
	set <char> visited;
	int n = 0;
	for(set<char>::iterator itr = all_vertices.begin(); itr!=all_vertices.end(); itr++)
	{
		vertices[n] = *itr;
		n++;
 	}
	for(int k = 0; k<s; k++)
	{
		for(int i = 0; i<size; i++)
		{
			for(list<shared_ptr<Edge>>::iterator j = graph[i].begin(); j!= graph[i].end(); j++)
			{
				if((*j)->dest == vertices[k])
				{
					indegree[k]+=1;
				}
			}
		}
	}

	int min_indegree = *min_element(indegree, indegree + s);
	int index = find(indegree, indegree + s, min_indegree) - indegree;
	char node = vertices[index];
	visited.insert(node);
	topo_order.append(1,node);

	for(int v = 0; v<all_vertices.size()-1; v++)
	{
		delete []indegree;
		indegree = new int[s-visited.size()]{0};
		delete [] vertices;
		vertices = new char[s - visited.size()];

		n = 0;
		int index_c = 0;
		for(set<char>::iterator itr = all_vertices.begin(); itr!=all_vertices.end(); itr++)
		{
			if(visited.count(*itr)== 0)
			{
				vertices[n] = *itr;
				n++;
			}
 		}

		for(int k = 0; k<(s-visited.size()); k++)
		{
			for(int i = 0; i<size; i++)
			{
				for(list<shared_ptr<Edge>>::iterator j = graph[i].begin(); j!= graph[i].end(); j++)
				{
					if(((*j)->dest == vertices[k]) && (visited.count((*j)->origin )== 0))
					{
						indegree[k]+=1;
					}
				}
			}
		}

		int min_indegree = *min_element(indegree, indegree + s);
		int index = find(indegree, indegree + s, min_indegree) - indegree;
		char node = vertices[index];
		visited.insert(node);
		topo_order.append(1,node);

	}

	return topo_order;
}

#endif
