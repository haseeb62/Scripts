#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include "string"
#include <queue> 
#include <set> 
#include <tuple> 
#include <vector> 
#include <stack>

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	ifstream file(filename);
	string line;
     while (getline(file, line)) {
        istringstream iss(line);
        char type;
        iss >> type;
        if (type == 'n') {
            int n;
            iss >> n;
            size = n;
            graph.resize(n);
        } else if (type == 'c') {
            int c;
            iss >> c;
        } else {
            char start = type, end;
            int weight;
            iss >> end >> weight;
            addEdge(start, end, weight, flag);
        }
    }
}


//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	
	if(flag == true) 
	{ 
		shared_ptr<Edge> ptr = make_shared<Edge>();
		ptr->origin = start ; 
		ptr->dest = end ; 
		ptr->weight = weight ; 
		graph[static_cast<int>(start - 'A')].push_back(ptr) ; 
		


	}
	else 
	{ 
		shared_ptr<Edge> ptr = make_shared<Edge>();
		ptr->origin = start ; 
		ptr->dest = end ; 
		ptr->weight = weight ;
        graph[static_cast<int>(start - 'A')].push_back(ptr);
		
		shared_ptr<Edge> ptr2 = make_shared<Edge>();
        ptr2->origin = end;
        ptr2->dest = start;
        ptr2->weight = weight;
		graph[static_cast<int>(end - 'A')].push_back(ptr2);
       
	}
	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	string output = "";
	int graph_length = graph.size() ; 
    for (int i = 0 ; i < graph.size() ; i++) 
	{
		int length ; 
		length = graph[i].size() ; 
		//cout << length ; 


        for(int j = 0 ; j < length ; j++) 
		{ 
			
			shared_ptr<Edge> a ;
			a = graph[i].front()  ;
			graph[i].pop_front() ; 
			output = output + "(" ; 
			output = output + a->origin ; 
			output = output + "," ; 
			output = output + a->dest ; 
			output = output + "," ; 
			output = output + to_string(a->weight) ; 
			output = output + ")" ; 
		
			output = output + " " ;

			
			 
			
			

		}
		 
    }
	//cout << output ; 
    return output;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
    if (start == end) {
        return true;
    }

    set<char> visitedNodes;
    queue<char> q;
    q.push(start);

    while (!q.empty()) {
        char currentNode = q.front();
        q.pop();

        if (currentNode == end) {
            return true;
        }

        visitedNodes.insert(currentNode);

    }

    return false;
}








//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	set<char> visitedNodes;
    queue<char> q;
    q.push(start);

    while (!q.empty()) {
        char currentNode = q.front();
        q.pop();
	} 
   return 0 ; 
}








//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
    string result ; 
    return result;
}








		
	

#endif
