#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <stack>
#include <queue>
#include <climits>


Graph::Graph(string filename, bool flag)
{
    ifstream file(filename);

    int num_nodes, num_edges;
    char ch;
    file >> ch >> num_nodes;
    file >> ch >> num_edges;

    graph.resize(num_nodes);
    for (auto& row : graph) 
	{
        row.resize(num_nodes);
    }

    char source, dest;
    int weight;

    for (int i = 0; i < num_edges; i++) 
	{
        file >> source >> dest >> weight;
        addEdge(source, dest, weight, flag);
    }

    file.close();
}



void Graph::addEdge(char start, char end, int weight, bool flag)
{
    int s = start - 'A';
    int e = end - 'A';

    auto forward_edge = make_shared<Edge>(start, end, weight);
    graph[s][e] = forward_edge;

    if (!flag) 
	{
        auto reverse_edge = make_shared<Edge>(end, start, weight);
        graph[e][s] = reverse_edge;
    }
}



string Graph::display()
{
    string output = "";

    for (const auto& row : graph) 
	{
        string a = "";
        for (const auto& edge : row) 
		{
            if (edge) 
			{
                if (a.size() != 0) 
				{
                    a += " ";
                }
                a += "(" + string(1, edge->origin) + "," + string(1, edge->dest) + "," + to_string(edge->weight) + ")";
            }
        }

        if ((output.size() != 0) && (a.size() != 0)) 
		{
            output = output + " ";
        }
        output = output + a;
    }

    return output;
}



bool Graph::Reachable(char start, char end) 
{

    vector<char> visited;
    stack<char> stack;

    int s = start - 'A';
    int e = end - 'A';

    stack.push(start);
    visited.push_back(start);

    while (!stack.empty()) 
	{
        char curr = stack.top();
        stack.pop();
        int current_index = curr - 'A';

        if (current_index == e) 
		{
            return true;
        }

        for (int i = 0; i < graph.size(); i++) 
		{
            if (graph[current_index][i] != NULL) 
			{
                char dest = graph[current_index][i]->dest;
                if (find(visited.begin(), visited.end(), dest) == visited.end()) 
				{
                    visited.push_back(dest);
                    stack.push(dest);
                }
            }
        }
    }

    return false;

}




int Graph::Dijkstra(char start, char dest) 
{
    if (!Reachable(start, dest)) 
	{
        return -1;
    }

    int num_vertices = graph.size();
    int start_index = start - 'A';
    int dest_index = dest - 'A';

    vector<int> distances(num_vertices, INT_MAX);
    vector<int> parents(num_vertices, -1);
    vector<bool> visited(num_vertices, false);

    distances[start_index] = 0;

    // Dijkstra's:
    for (int i = 0; i < num_vertices - 1; i++) 
	{
        int current_index = -1;
        int current_distance = INT_MAX;
        
        for (int j = 0; j < num_vertices; j++) 
		{
            if ((!visited[j]) && (distances[j] < current_distance)) 
			{
                current_index = j;
                current_distance = distances[j];
            }
        }

        if (current_index == -1) 
		{
            break;
        }

        visited[current_index] = true;

        for (int neighbor_index = 0; neighbor_index < num_vertices; neighbor_index++) 
		{
            if (graph[current_index][neighbor_index] != NULL) 
			{
                int neighbor_distance = distances[current_index] + graph[current_index][neighbor_index]->weight;
                if (neighbor_distance < distances[neighbor_index]) 
				{
                    distances[neighbor_index] = neighbor_distance;
                    parents[neighbor_index] = current_index;
                }
            }
        }
    }

    if (distances[dest_index] == INT_MAX) 
	{
		return -1;
	} 
	else 
	{
		return distances[dest_index];
	}

}





string Graph::topoSort()
{

    vector<int> sorted;

    vector<int> in_degree(graph.size(), 0);

    for (int i = 0; i < graph.size(); i++) 
	{
		for (int j = 0; j < graph[i].size(); j++) 
		{
			if (graph[i][j] != NULL) 
			{
				in_degree[graph[i][j]->dest - 'A']++;
			}
		}
	}

    queue<int> q;
    for (int i = 0; i < in_degree.size(); i++) 
	{
        if (in_degree[i] == 0) 
		{
            q.push(i);
        }
    }

    while (!q.empty()) 
	{
        int u = q.front();
        q.pop();
        sorted.push_back(u);

        for (int i = 0; i < graph.size(); i++) 
		{
            if (graph[u][i]) 
			{
                in_degree[i]--;
                if (in_degree[i] == 0) 
				{
                    q.push(i);
                }
            }
        }
    }

	
    string res;
    for (int i = 0; i < sorted.size(); i++) 
	{
		res += (char)('A' + sorted[i]);
	}

    return res;
	
}


#endif