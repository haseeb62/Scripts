#ifndef GRAPH__H
#define GRAPH__H
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <limits>
#include <set>
#include <algorithm>
#include <queue>
#include <list>
#include <sstream>
#include <memory>

using namespace std;

class Edge
{
public:
	char origin;
	char dest;
	int weight;

	Edge() : Edge{-1, -1, 0} {}
	
    Edge(char o, char d, char w) : origin{o}, dest{d}, weight{w} {}
};

class Graph
{

public:
	
	vector<vector<shared_ptr<Edge>>> graph;

	int size = 0;
	Graph(string filename, bool flag);

	void addEdge(char start, char end, int weight, bool flag);
	string display(); // displays the graph
	bool Reachable(char start, char dest);
	int Dijkstra(char start, char dest);
	string topoSort();

};

#endif