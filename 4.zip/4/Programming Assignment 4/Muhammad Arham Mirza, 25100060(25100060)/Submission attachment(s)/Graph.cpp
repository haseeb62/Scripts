#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
using namespace std;
#include <string>
#include <iostream>
#include <stack>

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	 ifstream file(filename); 


	string line;
	int line_no = 0;
    while (getline(file, line)) 
	{
		if(line_no == 0)
		{
			size = line[2]-'0';
			graph.resize(size);
			vector<list<shared_ptr<Edge>>> new_graph(size);
			graph = new_graph;

		}
		else if (line_no >1)
		{
			int w = line[4] - '0';
			addEdge(line[0],line[2],w,flag);	
		}
		line_no++;
        
    }

   
    file.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	int index;
	shared_ptr<Edge> new_edge = make_shared<Edge>();
	new_edge->origin = start;
	new_edge->dest = end;
	new_edge->weight = weight;
	index = int(start)-65;
	graph[index].push_back(new_edge);
	list<shared_ptr<Edge>>::iterator j = graph[index].begin(); 
		


	if(!flag)
	{
		shared_ptr<Edge> new_edge2 = make_shared<Edge>();
		new_edge2->origin = end;
		new_edge2->dest = start;
		new_edge2->weight = weight;
		index = int(end)-65;
		graph[index].push_back(new_edge2);

	}
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	string g = "";
	for(int i = 0;i<size;i++)
	{
		if(graph[i].empty())
		{
			continue;
		}
		list<shared_ptr<Edge>>::iterator j = graph[i].begin();  
    	while (j != graph[i].end()) 
		{  
        
			g = g+"("+(*j)->origin+","+(*j)->dest+","+to_string((*j)->weight)+")"+" ";
        	j++;  
    	}
    }
	return g;
}
	


// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	stack<int> s;
	int start_index = int(start) - 65;
    int end_index = int(end) - 65;
	int current_index;

    vector<bool> visited(size,false);

    visited[start_index] = true;
    s.push(start_index);

    while (!s.empty())
    {
        current_index = s.top();
        s.pop();

        if (current_index == end_index)
		{
			return true;
		}
            
        list<shared_ptr<Edge>>::iterator i = graph[current_index].begin();

        while (i != graph[current_index].end())
        {
            if (!visited[int((*i)->dest) - 65])
            {
                s.push(int((*i)->dest) - 65);
				visited[int((*i)->dest) - 65] = true;
            }
            i++;
        }
    }

    return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	int start_index = int(start) - 65;
	int dest_index = int(dest) - 65;
	stack<int> path;

	vector<int> distance(size,999); 
	
	distance[start_index] = 0;

	int i = 1;

	vector<int> back_track(size, 999);

	vector<bool> visited(size, false); 

	while (i < size)
	{
		int min_distance = 999;
		int min_i = 0;
		for (int j = 0; j < size; j++)
		{
			if (!(visited[j] || distance[j] > min_distance))
			{
				min_distance = distance[j];
				min_i = j;
			}
		}

		visited[min_i] = true;

		list<shared_ptr<Edge>>::iterator j = graph[min_i].begin();

		while (j != graph[min_i].end())
		{
			int weight = (*j)->weight;
			int dest = int((*j)->dest) - 65;
			int computed_dist = distance[min_i] + weight;

			if (!(visited[dest] || distance[min_i] == 999) && distance[dest]> computed_dist)
			{
				distance[dest] = computed_dist;
				back_track[dest] = min_i; 
			}
			j++;
		}
		i++;
	}

	if (distance[dest_index] == 999)
	{
		cout<<"NO PATH FROM "<<start<<" TO "<<dest<<endl;
		return -1;
	}
	else
	{
		int current = dest_index;
		while (current != 999)
		{
			path.push(current);
			current = back_track[current];
		}

		cout<<"SHORTEST PATH FROM "<<start<<" TO "<<dest<<": ";
		int i = path.size();

		while (!path.empty())
		{
			cout << char(path.top() + 65);
			path.pop();
		}
		cout << endl;
		return distance[dest_index];
	}
}
	

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	vector<int> no_in_degree(size, 0);
	stack<int> s;
	vector<bool> traversed(size,false);
	int traversed_no = 0;
	int current =0;
	string top_sort = "";

    for (int i = 0; i < size; i++)
    {
        list<shared_ptr<Edge>>::iterator j = graph[i].begin();

        while (j != graph[i].end())
        {
            int dest_index = int((*j)->dest) - 65;
            no_in_degree[dest_index]+=1; 
            j++;
        }
	
    }

    while(traversed_no < size)
	{
		if(! traversed[current])
		{
			if (no_in_degree[current] == 0)
			{
				traversed[current] = true;
				top_sort = top_sort + char(current + 65); 
				traversed_no+=1;
				list<shared_ptr<Edge>>::iterator j = graph[current].begin();
				while (j != graph[current].end())
				{
					int dest_index = int((*j)->dest) - 65;
					no_in_degree[dest_index]-=1; 

					j++;
				}
			}	
			
		}
		current+=1;
		current%=size;
			
	}

    
    return top_sort;
}

// int main()
// {
// 	Graph graph("test1.txt",true);
// 	cout<<graph.topoSort();
// }
#endif
