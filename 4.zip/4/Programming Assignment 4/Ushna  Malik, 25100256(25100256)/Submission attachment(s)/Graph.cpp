#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <deque>
#include <algorithm>
#include <unordered_map>

Graph::Graph(string filename, bool flag)
{
    ifstream file(filename);
    int number_of_nodes;
    string label;
    file >> label >> number_of_nodes;
    int number_of_edges;
    string edges;
    file >> edges >> number_of_edges;
	size = number_of_nodes;
	vector<shared_ptr<Edge>> Graph_Vector(size, 0);
	graph.resize(size, Graph_Vector);
    for (int i = 0; i < number_of_edges; i++) 
    {
        char node1, node2;
        int cost;
        file >> node1 >> node2 >> cost;
        addEdge(node1, node2, cost, flag);
		if (!flag)
		{
			addEdge(node2, node1, cost, flag);
		}
    }

    file.close();
}


void Graph::addEdge(char start, char end, int weight, bool flag)
{
	int start_index = getNodeIndex(start);
    int end_index = getNodeIndex(end);
	shared_ptr<Edge> edge = make_shared<Edge>();
    edge->origin = start;
    edge->dest = end;
    edge->weight = weight;
	graph[start_index][end_index] = edge;
	if (!flag) 
	{
		int start_index = getNodeIndex(end);
    	int end_index = getNodeIndex(start);
		shared_ptr<Edge> opposite_edge = make_shared<Edge>();
		opposite_edge->origin = end;
		opposite_edge->dest = start;
		opposite_edge->weight = weight;
		graph[end_index][start_index] = edge;
	}  

}

string Graph::display()
{
 	string output_string = "";
	string commas = ",";
    int i = 0;
    do {
        int j = 0;
        do {
            if (graph[i][j]) 
			{
				shared_ptr<Edge> edge_ptr = graph[i][j];
				char origin = edge_ptr->origin;
				char destination = edge_ptr->dest;
				int weight=edge_ptr->weight;
				string weight_cast=to_string(weight);
				output_string.append("(");
                output_string = output_string + origin;
                output_string.append(commas);
                output_string = output_string + destination;
                output_string.append(commas);
                output_string.append(weight_cast);
				output_string.append(") ");
            }
            j++;
        } while (j < graph[i].size());
        i++;
    } while (i < graph.size());

    return output_string;
}


int Graph::getNodeIndex(char node)
{
	int index = node - 'A';
	return index;
}


bool Graph::Reachable(char start, char dest)
{
  	int start_node = getNodeIndex(start);
    int destination_node = getNodeIndex(dest);
    queue<unsigned int> traversal_queue;
    traversal_queue.push(start_node);
	bool* visited= new bool[size]();
	queue<unsigned int> node_present;
	for(int i=0;i<size;i++)
	{
		visited[i]=false;
	}
    while (traversal_queue.size()>0)
	{
        unsigned int current_node = traversal_queue.front();
        traversal_queue.pop();
		node_present.push(current_node);
		for (int i=0;i<(node_present.size());i++)
		{
			unsigned int node = node_present.front();
        	node_present.pop();
			if (node!=current_node)
			{
				node_present.push(current_node);
			}
		}
		visited[current_node] = 1;
		unsigned int j=0;
		do
		{	
			shared_ptr<Edge> edge_ptr = graph[current_node][j];
			if (edge_ptr)
			{
				if(visited[j]<1)
					traversal_queue.push(j);
			}
			j++;
		} while(j<size);
    }
	if(visited[destination_node]==1)
	{
		while(node_present.size()>0)
		{
			if (node_present.front()==destination_node)
			{
				return true;
			}	
			node_present.pop();
		}
		return true;
	}
	return false;
}



int Graph::Dijkstra(char start, char dest)
{
    int starting_node = getNodeIndex(start);
    int destination_node = getNodeIndex(dest);
    unsigned int distance_vector[size];
    for(int i=0;i<size;i++)
	{
		distance_vector[i]=-1;
	}
	vector<int> predecessor_node;
	predecessor_node.resize(size);
	int k=0;
	while(k<=size)
	{
		predecessor_node[k]=-1;
		k++;
	}
    unordered_map<int, bool> visited_set;
    distance_vector[starting_node] = 0;
	deque<pair<unsigned int, int>> priority_queue;
	priority_queue.emplace_back(0, starting_node);
    while (priority_queue.size()>0)
	{
        for (int i =0; i <priority_queue.size()-1; i++)
		{
			for (int j =i+1; j <priority_queue.size(); j++) 
			{
				if (priority_queue[i] >priority_queue[j]) 
				{
					auto temp = priority_queue[i];
					priority_queue[i] = priority_queue[j];
					priority_queue[j] = temp;
				}
			}
		}
       	int present_node = get<1>(priority_queue.front());
        priority_queue.pop_front();
		if (visited_set[present_node])
			continue;
        visited_set[present_node] = 1;
		int i=0;
		do {
			shared_ptr<Edge> edge_ptr = graph[present_node][i];
			if (edge_ptr) 
			{
				int weight = edge_ptr->weight;
				unsigned int distance = distance_vector[present_node];
				unsigned int total_distance =distance+weight;
				unsigned int previous_distance=distance_vector[i];
				if(total_distance > previous_distance)
					distance_vector[i] = distance_vector[i];
				if (total_distance <= previous_distance)
				{
					predecessor_node[i] = present_node;
					distance_vector[i] = total_distance;
					priority_queue.emplace_back(total_distance, i); 
				}

			}
			i++;
		} while(i < size);
    }
	vector<char> final_path_list;
    int current = destination_node;
    for (int i = destination_node; i!= starting_node; i = predecessor_node[i])
	{
    	if (predecessor_node[i] <0) 
		{
			return (predecessor_node[i]);
    	}
		char to_add=i+ 'A';
    	final_path_list.push_back(to_add);
	}
	char to_add=starting_node + 'A';
	final_path_list.push_back(to_add);
    cout << "Path from " <<start << " to " <<dest << ": ";
	int size=final_path_list.size();
	reverse(final_path_list.begin(), final_path_list.end()); 
	int i=0;
	while(i<size)
	{
		cout << final_path_list[i]<<" ";
		i++;
	}
	cout<<endl;
    return distance_vector[destination_node];
}

string Graph::topoSort()
{
	stack<unsigned int> top_stack;
    string sorting_order;
    bool* visited_nodes = new bool[size]();
    unsigned int i = 0;
	queue<unsigned int> node_present;
    while (i < size||top_stack.size()>0) 
    {
        if (i < size) 
        {
			node_present.push(i);
			if(visited_nodes[i]<1)
				dfs_traversal(visited_nodes, i, top_stack,node_present);
				while(node_present.size()>0)
				{
					unsigned int node=node_present.front();
					if (node==i)
					{
						node_present.pop();
					}
				}
        }
        else if (top_stack.size()>0)
        {
			char ascii='A';
            sorting_order.append(1, top_stack.top() + ascii);
            top_stack.pop();
        }
        i++;
    }
    return sorting_order;
}


void Graph::dfs_traversal(bool* visited_node,int node, stack<unsigned int>& top_stack,queue<unsigned int>& visited_queue)
{
	visited_node[node] = 1;
	unsigned int i = 0;
	do {
		shared_ptr<Edge> edge_ptr = graph[node][i];
		if (edge_ptr)  
		{
			if(visited_node[i]<1)
				dfs_traversal(visited_node, i, top_stack,visited_queue);
		}
		i++;
	} while (i < size);
	unsigned int new_node=visited_queue.front();
	if(visited_node[new_node]==1)
		visited_node[new_node]=visited_node[node];
	top_stack.push(node);
}

#endif