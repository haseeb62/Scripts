#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <string>
#include <queue>


//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	string input;
	ifstream data(filename);
	getline(data,input);
	size = input[2]-'0';
	vector<shared_ptr<Edge>> dummy;
	dummy.assign(size,NULL);
	graph.assign(size,dummy);
	getline(data,input);
	while(getline(data,input)) {
		cout <<input<<endl;
		addEdge(input[0],input[2],stoi(string(1,input[4])),flag);
	}
	data.close();
	cout << "***************\n";
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	shared_ptr<Edge> curr = make_shared<Edge>(start,end,weight);
	(graph.at(start-'A')).at(end-'A') = curr; //vector of shared pointers
	if (flag == false){
		curr = make_shared<Edge>(end,start,weight);
		(graph.at(end-'A')).at(start-'A') = curr; 
	}
	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	string graphDisplay = "";
	graph.shrink_to_fit();
	for(int i = 0; i< graph.size();i++){
		for(int j = 0; j < graph[i].size();j++){
			if (graph[i][j] != NULL){
				graphDisplay += string("")+"("+graph[i][j]->origin+","+graph[i][j]->dest+","+to_string(graph[i][j]->weight)+") ";
			}
		}
		graphDisplay += "\n";
	}
	return graphDisplay;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end) //bfs
{
	if(graph[start-'A'][end-'A'] != NULL){
		return true;
	}
	queue<char> frontier;
	vector<bool> visited;
	visited.assign(size,false);
	char curr;
	frontier.push(start);
	while(frontier.size() > 0){
		curr = frontier.front();
		frontier.pop();
		visited[curr-'A'] = true;
		if(curr == end){
			return true;
		}else{
			//add in frontier
			for(int i = 0; i < graph[curr-'A'].size();i++){
				if(graph[curr-'A'][i]!=NULL && visited[(graph[curr-'A'][i]->dest)-'A'] == false){
					frontier.push(graph[curr-'A'][i]->dest);
				}
			}
		}
	} 
	return false;
}

struct node{
	char data;
	node* parent;
	int curr_cost;
	node(){
	}
	node(char d,node* p, int c){
		data = d;
		parent = p;
		curr_cost = c;
	}
	bool operator <(const node& n) {
        return true;
	}
};

void print(list<char> const &list)
{
    for (auto const &i: list) {
        cout << i << " ";
    }
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// cout << "Finding shortest path from "<<start <<" to "<<dest <<endl;
	node* start_node = new node(start,NULL,0);
	priority_queue<pair<int,node*>, vector<pair<int,node*>>, greater<pair<int,node*>> > frontier;
	vector<bool> visited;
	visited.assign(size,false);
	node* curr;
	// frontier.push(make_pair(0,start_node));
	frontier.push(make_pair(0,start_node));
	while(frontier.size() > 0){
		curr = frontier.top().second;
		// cout << "removing "<<curr->data<<endl;
		frontier.pop();
		visited[curr->data-'A'] = true;
		if(curr->data == dest){
			// cout << "destination found!!\n";
			list<char> path;
			int path_cost = curr->curr_cost;
			while(curr->parent != NULL){
				path.push_front(curr->data);
				curr = curr->parent;
			}
			path.push_front(start);
			print(path);
			cout <<path_cost<<endl;
			return path_cost;
		}else{
			//add in frontier
			for(int i = 0; i < graph[curr->data-'A'].size();i++){
				if(graph[curr->data-'A'][i]!=NULL && visited[(graph[curr->data-'A'][i]->dest)-'A'] == false){
					start_node = new node(i+'A',curr,curr->curr_cost+graph[curr->data-'A'][i]->weight);
					frontier.push(make_pair(curr->curr_cost+graph[curr->data-'A'][i]->weight,start_node));
					// cout << "adding "<<char(i+'A')<< " with weight "<<curr->curr_cost+graph[curr->data-'A'][i]->weight<<endl;
				}
			}
			// cout << "\n";
		}
	}
	return -1;
}

void Graph::dfs(char start, int& time, priority_queue<pair<int,char>>& finish_times,vector<bool> &visited){
	visited[start-'A'] = true;
	time++;
	for(int i = 0; i < graph[start-'A'].size();i++){
		if(graph[start-'A'][i]!=NULL && visited[graph[start-'A'][i]->dest-'A'] == false){
			dfs(graph[start-'A'][i]->dest,time,finish_times,visited);
		}
	}
	time++;
	finish_times.push(make_pair(time,start));
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	priority_queue<pair<int,char>> finish_times;
	vector<shared_ptr<Edge>> dummy;
	dummy.assign(size,NULL);
	graph.push_back(dummy);
	for(int i = 0; i < size;i++){
		addEdge(char(size+65), char('A'+i), 1, true);
	}
	int time = 0;
	vector<bool> visited;
	visited.assign(size,false);
	dfs(char(size+65),time,finish_times,visited);
	string toposort ="";
	finish_times.pop();
	while(!finish_times.empty()){
		toposort += finish_times.top().second;
		finish_times.pop();
	}
	// cout << toposort<<endl;
	graph.pop_back();
	return toposort;
}

#endif
