#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
//  Add your constructor code here. It takes the filename and loads
//  the graph from the file, storing into your representation of the
//  graph. MAKE SURE you use the addEdge function here, and pass the
//  flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	string array_new[100];
	string statement;
	ifstream MyFile(filename);
	int f = 0;
	while (getline(MyFile, statement))
	{
		array_new[f] = statement;
		f++;
	}
	string number_of_flights_1 = "";
	for (int i = 2; i < array_new[1].length(); i++)
	{
		number_of_flights_1 = number_of_flights_1 + array_new[1][i];
	}
	string number_of_cities_1 = "";
	for (int i = 2; i < array_new[0].length(); i++)
	{
		number_of_cities_1 = number_of_cities_1 + array_new[0][i];
	}
	int number_of_flights = stoi(number_of_flights_1);
	int number_of_cities = stoi(number_of_cities_1);
	string array_final[number_of_flights];
	for (int i = 2; i < 2 + number_of_flights; i++)
	{
		array_final[i - 2] = array_new[i];
	}
	vector<vector<shared_ptr<Edge>>> temp(number_of_cities, vector<shared_ptr<Edge>>(number_of_cities));
	graph = temp;
	for (int i = 0; i < number_of_cities; i++)
	{
		for (int j = 0; j < number_of_cities; j++)
		{
			graph[i][j] = nullptr;
		}
	}
	size = number_of_cities;
	//adding the first edge to the graph
	string x = "";
	x += array_final[0][4];
	shared_ptr<Edge> new_node = make_shared<Edge>(array_final[0][0], array_final[0][2], stoi(x));
	char array[26] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	char start_index;
	for (int i = 0; i < 26; i++)
	{
		if (array[i] == array_final[0][0])
		{
			start_index =i;
		}
	}
	char end_index;
	for (int i = 0; i < 26; i++)
	{
		if (array[i] == array_final[0][2])
		{
			end_index =i;
		}
	}
	graph[0][end_index-start_index] = new_node;

	if(flag == false)
	{
		new_node = make_shared<Edge>(array_final[0][2], array_final[0][0], stoi(x));
		graph[end_index-start_index][0] = new_node;
	}
	for (int i = 1; i < number_of_flights; i++) //adding remaining edges 
	{
		string a = "";
		a += array_final[i][4];
		addEdge(array_final[i][0], array_final[i][2], stoi(a), flag);
	}
}
int Graph::returnindex(char x)
{
	char array[26] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	char start_char; //extracting the first city in the graph; rest of the cities appear in alphabetical order as stated in piazza comment by instructor
	for(int j=0; j<size;j++)
	{
		if (graph[0][j] != nullptr)
		{
			start_char = graph[0][j]->origin;
			break;
		}
	}
	int start_index =0; //index in the array that corresponds to first city in the graph
	for(int j=0;j<26;j++)
	{
		if(array[j] == start_char)
		{
			start_index = j;
		}
	}
	for (int i = 0; i < size; i++)
	{
		if (array[start_index + i] == x)
		{
			return start_index + i;
		}
	}
}
char Graph ::returnChar(int i)
{
	char array[26] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	char start_char; //extracting the first city in the graph; rest of the cities appear in alphabetical order as stated in piazza comment by instructor
	for(int j=0; j<size;j++)
	{
		if (graph[0][j] != nullptr)
		{
			start_char = graph[0][j]->origin;
			break;
		}
	}
	int start_index =0; //index in the array that corresponds to first city in the graph
	for(int j=0;j<26;j++)
	{
		if(array[j] == start_char)
		{
			start_index = j;
		}
	}
	return array[start_index+i];
}
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	if (flag == true) // this is when the graph is directed
	{
		int start_index = returnindex(start);
		int end_index = returnindex(end);
		shared_ptr<Edge> new_node = make_shared<Edge>(start, end, weight);
		graph[start_index][end_index] = new_node;
	}
	if (flag == false)
	{
		int start_index = returnindex(start);
		int end_index = returnindex(end);
		shared_ptr<Edge> new_node = make_shared<Edge>(start, end, weight);
		graph[start_index][end_index] = new_node;
		int temp = start_index; // swapping the indices
		start_index = end_index;
		end_index = temp;
		shared_ptr<Edge> new_node_reverse = make_shared<Edge>(end, start, weight);
		graph[start_index][end_index] = new_node_reverse;
	}
}

// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string output = "";
	for (int i = 0; i < size; i++)
	{
		bool is_empty = false;
		for (int j = 0; j < size; j++)
		{
			if (graph[i][j] != nullptr)
			{
				is_empty = true;
				output += "(";
				output += graph[i][j]->origin;
				output += ",";
				output += graph[i][j]->dest;
				output += ",";
				output += to_string(graph[i][j]->weight);
				output += ") ";
			}
		}
		if (is_empty == true)
		{
			output += "\n";
		}
	}
	return output;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end) //run depth first search and if destination node is reached you return true; else return false
{
	stack<char> stack;
	stack.push(start);
	vector<shared_ptr<Edge>> visited_edges;
	vector<char> visited_nodes;
	char currState;
	while (stack.empty() == false)
	{
		currState = stack.top();
		stack.pop();
		if (find(visited_nodes.begin(), visited_nodes.end(), currState) != visited_nodes.end()) // node already present in visited nodes
		{
			continue;
		}
		else
		{
			// is not present in visited nodes
			if (currState == end)
			{
				return true;
			}
			visited_nodes.push_back(currState);
			int current_state_index = returnindex(currState);
			for (int i = 0; i < size; i++)
			{
				if (graph[current_state_index][i] != NULL)
				{
					stack.push(graph[current_state_index][i]->dest); //adding all its outgoing edges to the stack
				}
			}
		}
	}
	return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// TODO
	if (Reachable(start, dest) == false)
	{
		return -1;
	}
	else if (start == dest)
	{
		return 0;
	}
	else
	{
		vector<char> cloud; // list of cities whose shortest path cost is definitely known through dijkstra
		vector<tuple<char, int>> cost_list; //keeps the cities along with their shortest known costs
		vector<int> costs; //acts as a priority queue; use dto find the next element we add to cloud
		cloud.push_back(start); 
		int start_index = returnindex(start);
		int distance_1 = 1000;		   // infinity
		for (int i = 0; i < size; i++) // initialization
		{
			char city = returnChar(i);
			if (city == start)
			{
				costs.push_back(distance_1);
				cost_list.push_back(make_tuple(city, 0));
			}
			else if (graph[start_index][i] != nullptr) //setting D(v) for neighbours
			{
				costs.push_back(graph[start_index][i]->weight);
				cost_list.push_back(make_tuple(city, graph[start_index][i]->weight));
			}
			else
			{
				costs.push_back(distance_1);
				cost_list.push_back(make_tuple(city, distance_1));
			}
			distance_1 = distance_1 + 1;
		}
		while (cloud.size() != size)
		{
			auto minimum_element = min_element(costs.begin(), costs.end());
			int min_index = distance(costs.begin(), minimum_element); 
			char next_element = returnChar(min_index); //next element with min cost
			if (next_element == dest) //if element being added to cloud is destination; return it
			{
				return costs[min_index];
			}
			// if char not in cloud; add it to cloud and relax the edges
			cloud.push_back(next_element);
			costs[min_index] = distance_1; //making it infinity so that it doesnot get popped from costs again
			char curr_state = next_element;
			int curr_state_index = returnindex(curr_state); 
			for (int i = 0; i < size; i++)
			{
				if (graph[curr_state_index][i] != NULL)
				{
					if (find(cloud.begin(), cloud.end(), graph[curr_state_index][i]->dest) != cloud.end()) 
					{
						continue;
					}
					else //relaxing the edges of neighbours of current state if not in cloud
					{
						int cost = get<1>(cost_list[i]); 
						int new_cost = graph[curr_state_index][i]->weight + get<1>(cost_list[min_index]);
						if (new_cost < cost)
						{
							get<1>(cost_list[i]) = new_cost;
							costs[i] = new_cost;
						}
					}
				}
			}
		}
	}
}

// Implement topological sort on the graph and return the string of the sorted cities
string Graph::topoSortHelper(string sorted_order,vector<vector<shared_ptr<Edge>>> graph)
{
	if (sorted_order.length() == size)
	{
		return sorted_order;
	}
	int index;
	char city_to_add;
	for (int i = 0; i < size; i++) // column number
	{
		if (graph[0][i] != nullptr)
		{
			if (graph[0][i]->weight == 1000)
			{
				continue;
			}
		}
		int in_degree = 0;
		for (int j = 0; j < size; j++) // row number
		{
			if (graph[j][i] != nullptr)
			{
				in_degree++;
			}
		}
		if (in_degree == 0)
		{
			index = i;
			break;
		}
	}
	sorted_order += returnChar(index);
	for (int i = 0; i < size; i++)
	{
		graph[index][i] = nullptr;
	}
	shared_ptr<Edge> new_node = make_shared<Edge>('Z', 'Z', 1000); // random node that never exists added so that this column is never visited again; has already been added to the topological sort
	graph[0][index] = new_node;
	return topoSortHelper(sorted_order,graph);
}
string Graph::topoSort() //calculate the in degree; remove the one with in degree is 0; continue applying 
{
	// TODO
	vector<vector<shared_ptr<Edge>>> graph_2 = graph; //creating a temp variable because do not want to make changes to actual grpah variable
	string sorted_order = "";
	sorted_order = topoSortHelper(sorted_order,graph_2);
	return sorted_order;
}

#endif
