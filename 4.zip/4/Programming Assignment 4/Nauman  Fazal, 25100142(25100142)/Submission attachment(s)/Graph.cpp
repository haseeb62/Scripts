#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
  
	ifstream file(filename);
    string line;
    int i = 0;
    if (!file.is_open()) 
    {
        cout << "Unable to open file\n";
        return;
    }
    else
    {
        while (getline(file, line))
        {
            char start = line[0];
            char end = start;
            int weight = 0;
            string cost = "";

            if (i == 0)
            {
                cost = line.substr(2);
                weight = stoi(cost);
                size = weight;
                i++;
                continue;
            }

            if (i == 1)
            {
                i++;
                continue;
            }

            end = line[2];
            cost = line.substr(4);
            weight = stoi(cost);

            addEdge(start, end, weight, flag);
        }
    }
    file.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
struct funct
{
	bool operator()(shared_ptr<Edge>& object1, shared_ptr<Edge>& object2)
	{
		string first="";
		first=first+object1->dest;
		string second="";
		second=second+object2->dest;

		if(first.compare(second) < 0 )
		{
			return(0);
		}
		else
		{
			return(1);
		}
    	
	}

};
struct funct2
{
	bool operator()(list<shared_ptr<Edge>>& object1, list<shared_ptr<Edge>>& object2)
	{
		string first="";
		first=first+object1.front()->origin;
		string second="";
		second=second+object2.front()->origin;

		if(first.compare(second) < 0 )
		{
			// ////cout<<first<<" > "<<second<<first.compare(second)<<endl;
			return(1);
		}
		else
		{
			// ////cout<<first<<" > "<<second<<first.compare(second)<<endl;
			return(0);
		}
    	
	}

};

void Graph::addEdge(char start, char end, int weight, bool flag)
{
	if(flag==true)
	{
		shared_ptr<Edge> newEdge( new Edge(start,end,weight));

		for(int i=0;i<graph.size();i++)
		{
			if(graph[i].front()->origin==start) 
			{
				graph[i].push_back(newEdge);
				
				vector <shared_ptr<Edge>> temp;
				while (!graph[i].empty())
				{
					temp.push_back(graph[i].front());
					graph[i].pop_front();
				}
				sort(temp.begin(),temp.end(),funct());
				
				while(!temp.empty())
				{
					graph[i].push_back(temp.back());
					temp.pop_back();
				}

			
				sort(graph.begin(),graph.end(),funct2());
				return;
			}
		}
		
		list<shared_ptr<Edge>> newList;
                                        
		newList.push_back(newEdge);

		graph.push_back(newList);

	}
	else
	{
		
		shared_ptr<Edge> newEdge( new Edge(start,end,weight));
		shared_ptr<Edge> newEdge2( new Edge(end,start,weight));

		bool srcfound=false;
		bool dstfound=false;

		for(int i=0;i<graph.size();i++)
		{
			if(graph[i].front()->origin==newEdge->origin) 
			{
				srcfound=true;
				graph[i].push_back(newEdge);

				
				vector <shared_ptr<Edge>> temp;
				while (!graph[i].empty())
				{
					temp.push_back(graph[i].front());
					graph[i].pop_front();
				}
				sort(temp.begin(),temp.end(),funct());
				
				while(!temp.empty())
				{
					graph[i].push_back(temp.back());
					temp.pop_back();
				}

				
			}

			if(graph[i].front()->origin==newEdge2->origin) 
			{
				dstfound=true;
				
				list<shared_ptr<Edge>>::iterator it;
				bool found =false;
				for (it = graph[i].begin(); it != graph[i].end(); it++)
				{
					if((*it)->dest==newEdge2->dest)
					{
						
						found=true;
						break;
					}
				}
				if(found==false)
				{
					graph[i].push_back(newEdge2);
					
					vector<shared_ptr<Edge>> temp;
					while (!graph[i].empty())
					{
						temp.push_back(graph[i].front());
						graph[i].pop_front();
					}
					sort(temp.begin(), temp.end(), funct());

					while (!temp.empty())
					{
						graph[i].push_back(temp.back());
						temp.pop_back();
					}
				}
			}
		}

		
		if(srcfound==false)
		{
			list<shared_ptr<Edge>> newList;
			newList.push_back(newEdge);

			graph.push_back(newList);

		}
	
		if(dstfound==false)
		{
			list<shared_ptr<Edge>> newList;
			newList.push_back(newEdge2);

			graph.push_back(newList);
		}
		
	}
	
	sort(graph.begin(),graph.end(),funct2());
	return;
}


//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string outputstr = "";
	for (int i = 0; i < graph.size(); i++)
	{
		list<shared_ptr<Edge>>::iterator it;
		int j = 0;
		for (it = graph[i].begin(); it != graph[i].end(); it++)
		{
			char o = (*it)->origin;
			char d = (*it)->dest;
			string w = to_string((*it)->weight);
			string curr = "";
			curr = curr + '(' + o + ',' + d + ',' + w + ')';

			if (outputstr == "" || j == 0)
			{
				outputstr += curr;
			}
			else
			{
				outputstr = outputstr + " " + curr;
			}
			j++;
		}
		if (i != graph.size() - 1)
		{
			outputstr += " ";
		}
		outputstr += "\n";
	}
	outputstr += "\n";
	// ////cout<<"END------------------"<<endl;
	////cout<<outputstr<<endl;

	return outputstr;
	// return "";
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	int source = start - 'A';
    int dest = end - 'A';
    vector<bool> visited(size, false);
    queue<int> q;
    q.push(source);
    visited[source] = true;

    while (!q.empty())
    {
        int u = q.front();
        q.pop();

        for (auto edge : graph[u])
        {
            int v = edge->dest - 'A';
            if (!visited[v])
            {
                if (v == dest)
                {
                    return true;
                }
                visited[v] = true;
                q.push(v);
            }
        }
    }

    return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
    const int INF = numeric_limits<int>::max();
    vector<int> dist(size, INF);
    vector<bool> visited(size, false);
    dist[start - 'A'] = 0;

    for (int i = 0; i < size - 1; i++) 
    {
        int minDist = INF;
        int minNode = -1;
        for (int j = 0; j < size; j++) 
        {
            if (!visited[j] && dist[j] < minDist) 
            {
                minDist = dist[j];
                minNode = j;
            }
        }

        if (minNode == -1) break;
        visited[minNode] = true;

        for (auto& edge : graph[minNode]) 
        {
            int neighbor = edge->dest - 'A';
            int newDist = dist[minNode] + edge->weight;
            if (newDist < dist[neighbor]) 
            {
                dist[neighbor] = newDist;
            }
        }
    }

    return (dist[dest - 'A'] == INF) ? -1 : dist[dest - 'A'];
}

string Graph::topoSort()
{
// Initialize the in-degree array and queue
vector<int> inDegree(size, 0);
queue<char> q;
int a = int('A');
// Calculate the in-degree of each vertex
for (auto &list : graph)
{
	for (auto &edge : list)
	{
		inDegree[edge->dest - 'A']++;
	}
}

// Add all vertices with in-degree 0 to the queue
for (int i = 0; i < 5; i++)
{
	if (inDegree[i] == 0)
	{
		q.push(i + a);
	}
}

// Process vertices in the queue and update their adjacent vertices
string result = "";
while (!q.empty())
{
	char currVertex = q.front();
	q.pop();
	result += currVertex;

	for (auto edge : graph[currVertex - 'A'])
	{
		char adjVertex = edge->dest;
		inDegree[adjVertex - 'A']--;
		if (inDegree[adjVertex - 'A'] == 0)
		{
			q.push(adjVertex);
		}
	}
}

return result;
}




#endif
