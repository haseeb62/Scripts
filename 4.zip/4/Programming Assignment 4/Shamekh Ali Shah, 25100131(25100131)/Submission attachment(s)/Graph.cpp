#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <stack>
//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
    ifstream file(filename);
    int vertices = 0;
    string s;

    file >> s >> vertices;

    graph.resize(vertices);
    size = vertices;

    string temp;
    getline(file, temp);
    getline(file,temp);



   while (getline(file, temp))
    {

        char src = temp[0];
        char dest = temp[2];
        int weight = static_cast<int>(temp[4] - '0');
        if (flag)
        {
            addEdge(src, dest, weight, true);
        }
        else
        {
            addEdge(src, dest, weight, false);
        }
    }
}


//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
    shared_ptr<Edge> temp(new Edge);
    temp->dest=end;
    temp->origin=start;
    temp->weight=weight;

    shared_ptr<Edge> temp2(new Edge);
    temp2->dest=start;
    temp2->origin=end;
    temp2->weight=weight;

    if (flag)
        {
            graph[static_cast<int>(start - 'A')].push_back(temp);
        }
        else
        {
            graph[static_cast<int>(start - 'A')].push_back(temp);
            graph[static_cast<int>(end - 'A')].push_back(temp2);
        }
    
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
    string concatenate;
	for(int i=0;i<graph.size();i++)
    {
        int size=graph[i].size();
        for(int j=0;j<size;j++)
        {
            shared_ptr<Edge> temp(new Edge);
            temp=graph[i].front();
            concatenate=concatenate+"("+temp->origin+","+temp->dest+","+to_string(temp->weight)+")"+" ";
            graph[i].pop_front();
        }
    }

    return concatenate;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
    bool visited[size] = {false}; 
    return dfs(start, end, visited); 
}

bool Graph::dfs(char node, char end, bool visited[])
{
    visited[static_cast<int>(node - 'A')] = true;

    if (node == end)
        return true;

    int length = graph[static_cast<int>(node - 'A')].size();

    for (int i = 0; i < length; i++)
    {
        char dest = graph[static_cast<int>(node - 'A')].front()->dest;

        if (!visited[static_cast<int>(dest - 'A')])
        {
            if (dfs(dest, end, visited))
                return true;
        }

        shared_ptr<Edge> temp = graph[static_cast<int>(node - 'A')].front();
        graph[static_cast<int>(node - 'A')].pop_front();
        graph[static_cast<int>(node - 'A')].push_back(temp);
    }

    return false;
}

// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
    vector<int> parent(size, -1);
    vector<int> distance(size, 9999);

    distance[start-'A'] = 0;

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, start-'A'});

    while(!pq.empty()) 
	{
        int u = pq.top().second;
        if (u == dest-'A') 
		{
            break;
        }
        list<shared_ptr<Edge>> temp = graph[u];
        pq.pop();
        for(int i = 0; i < graph[u].size(); i++) 
		{
			shared_ptr<Edge> curr_edge(new Edge);
			curr_edge = temp.front();

            if(distance[u] != 9999) 
			{
                if(distance[curr_edge->dest - 'A'] > distance[u] + curr_edge->weight)
                {
                    distance[curr_edge->dest - 'A'] = distance[u] + curr_edge->weight;
                    parent[curr_edge->dest - 'A'] = u;
                    pq.push({distance[curr_edge->dest - 'A'], curr_edge->dest - 'A'});
                }
            }
			temp.pop_front();
        }
    }

    int sum_cost = distance[dest-'A'];
    if(sum_cost == 9999) 
	{
        cout << "Path not found" << endl;
        return -1;
    }

    cout << "Dijkstra shortest path from " << start << " to " << dest << ": ";

    stack<int> path;
    int node = dest-'A';
    while(node != -1) 
	{
		path.push(node);
		node = parent[node];
	}

    cout<<"[ ";
	while (!path.empty())
	{
		int node = path.top();
		path.pop();
		cout <<static_cast<char>(node + 'A') << " ";
	}
	cout << "]" << endl;

	return sum_cost;
}
//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
    vector<char> result;
    vector<int> inDegree(size, 0);

    stack<int> s;
    s.push(0);

    int i = 0;
    while (i < graph.size())
    {
        list<shared_ptr<Edge>> adjList = graph[i];
        int length = adjList.size();

        int j = 0;

        while (j < length)
        {
            shared_ptr<Edge> adjacentEdge = adjList.front();
            inDegree[adjacentEdge->dest - 'A']++;
            adjList.pop_front();
            j++;
        }

        i++;
    }
    queue<int> q;
    for (int i = 0; i < graph.size(); i++)
    {
        if (inDegree[i] == 0)
        {
            q.push(i);
        }
    }

    while (!q.empty())
    {
        int curr_node = q.front();
        list<shared_ptr<Edge>> temp = graph[curr_node];
        q.pop();
        result.push_back(curr_node + 'A');
        int length = temp.size();

        int i = 0; 

        while (i < length)
        {
            shared_ptr<Edge> adjacentEdge = temp.front();
            inDegree[adjacentEdge->dest - 'A']--;
            if (inDegree[adjacentEdge->dest - 'A'] == 0)
            {
                q.push(adjacentEdge->dest - 'A');
            }
            temp.pop_front();
            i++; 
        }
    }

    string answer(result.begin(), result.end());

    return answer;
}



#endif
