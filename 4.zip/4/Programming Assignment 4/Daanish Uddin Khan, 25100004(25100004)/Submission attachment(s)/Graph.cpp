#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO

	// Variablessssssssssssssssss
	string in;
	char start;
	char end;
    int weight;
    
	// Open File
	ifstream file(filename);
    
	// Check if file open
	if (file.is_open())
	{
		// Reading From File
		file >> in;
		file >> size;

		int temp = 0;

		file >> in;
		file >> temp;

		file >> start;
		file >> end;
		file >> weight;
        
		// Place Holder Lists According to Size Added to "Graph"
		for (int i = 0; i < size; i++)
		{
			list<shared_ptr<Edge>> placeHolder;
			graph.push_back(placeHolder);
		}

		// Read start, End, Weight from file and send to add edge function until file ends
		while (!file.eof())
		{
			addEdge(start, end, weight, flag);
			file >> start;
			file >> end;
			file >> weight;
		}
	}
    
	// Close File
	file.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	if (flag)
	{
		// If Directed Add Single Edge
		shared_ptr<Edge> newEdge(new Edge(start, end, weight));
		graph[start - 'A'].push_back(newEdge);
	}
	else 
	{
		// If Undirected Add Double Edge
		shared_ptr<Edge> newEdge = make_shared<Edge>(start, end, weight);
		graph[start - 'A'].push_back(newEdge);

		shared_ptr<Edge> reverse(new Edge(end, start, weight));
		graph[end - 'A'].push_back(reverse);
	}
	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO

	// String Representation of Graph
	string graphString = "";
    
	// Loop to Loop through Entire Graph Stored in Vector of Lists
	for (int i = 0; i < size; i++)
	{
		// Counters
		int c = 0;

		// Variable to Hold Start City 
		char start;
        
		// Arrays to Store End Destinations and Associated Weights
		char ends[size];
		int weights[size];
        
		// Looping through all possible Paths From One start Destination to end Destination
		for (auto path: graph[i])
		{
			// Storing All existing Paths in Arrays
			ends[c] = path->dest;
			weights[c] = path->weight;
			start = path->origin;
			c++;
		}
        
		// Sorting End Destinations Alphabetically and Associated Weights Accordingly
		if (c != 0)
		{
            // Loop Loop 
			for (int i = 0; i < c; i++)
			{
				for (int j = i; j < c - 1; j++)
				{
					// Checking
					if (ends[i] > ends[j + 1])
					{
						// Swapping
						char swapChar = ends[i];
						ends[i] = ends[j + 1];
						ends[j + 1] = swapChar;

						int swapInt = weights[i];
						weights[i] = weights[j + 1];
						weights[j + 1] = swapInt;
					}
				}
			}

			
            // Adding All Routes to string representation of Graph
			for (int i = 0; i < c; i++)
			{
				graphString = graphString + "(" + start + "," + ends[i] + "," + to_string(weights[i]) + ") ";
			}

			graphString = graphString + "\n";
		}
	}
    
	return graphString;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// TODO
	
	// Variables Initialisation
	char nextPossibleRoutes[size];
	char explored[size];
	int count  = 0;
	int countExplored = 0;

	// Looping Through and Checking if Direct Path Exists from Start to End
	for (auto path : graph[start - 'A'])
	{
		if (path->dest == end)
		{
			return true;
		}

		// Adding Next Possible Routes to Explore to Array In Case Direct Path Does Not Exist
		nextPossibleRoutes[count] = path->dest;
		count++;
	}
    
	// Adding Explored Path to Explored Array
	explored[countExplored] = start;
	countExplored++;
    
	// Loop to Loop Through and Explore Next Possible Routes
	for (int i = 0; i < count; i++)
	{
		// Checking if Path in Next Possible Routes Has Already Been Explored
		bool explore = true;
	    for (int j = 0; j < countExplored; j++)
		{
			if (explored[j] == nextPossibleRoutes[i])
			{
				explore = false;
			}
		}
        
		// Only Exploring Next Possible Route if Needed
		if (explore)
		{
			// Looping Through Next Possible Routes Paths
			for (auto path : graph[nextPossibleRoutes[i] - 'A'])
			{
				// Returning if It Exists
				if (path->dest == end)
				{
					return true;
				}
                
				// If Path Destination is Already in Explored sets Bool variable to false
				bool already = true;
				for (int j = 0; j < countExplored; j++)
				{
					if (explored[j] == path->dest)
					{
						already = false;   
					}
				}
                
				// If Path Destination is Already in Next Possible Routes sets Bool Variable to False
				for (int j = 0; j < count; j++)
				{
					if (nextPossibleRoutes[j] == path->dest)
					{
						already = false;   
					}
				}
				
				// Only Adds Next Possible Path to Array if it Has Not Already Been Explored
				if (already)
				{
					nextPossibleRoutes[count] = path->dest;
					count++;
				}
			}
		}	
	}
	

	return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// TODO

	// Checking If Path Reachable
	bool reach = Reachable(start, dest);

	if (reach == false)
	{
		return -1;
	}
    
	// Infinity and Data Structures For Dijkstra Implementation
	int inf = 10000;
	vector<bool> explored(size, false);
	vector<int> distance(size, inf);
	vector<int> parent(size, -1);
    
	// Starting
    int init = start - 'A';
	distance.at(init) = 0;
    
	// Main Loop Where Dijkstra Takes Place
	for (int i = 0; i < size; i++)
	{
		// starting Value
		int behind = -1;
        
		// Choosing Index of Node With Minimum Distance from Unexplored Vector 
		for (int j = 0; j < size; j++)
		{
			if (explored.at(j) == false && (behind == -1 || distance.at(behind) > distance.at(j)))
			{
				behind = j;
			}
		}
        
		// Setting Node That HAs been Explored to True
		explored.at(behind) = true;
        
		// Updating Distance of Node from Start Accordingly
		for (auto path: graph[behind])
		{
			// Finding Index of Destination Path
			int v = path->dest - 'A';

			// Updating Total Weight
			int dist = distance[behind] + path->weight;
            
			// If SHorter Distance Found, it is Uopdated to new Distance
			if (distance[v] > dist)
			{
				// Updatung
				distance.at(v) = dist;
				parent.at(v) = behind;
			}
		}
	}
	
	// Printing Shortest Path
	int destIndex = dest - 'A';
	string shortPath = "";
	while (destIndex != -1)
	{
		shortPath = shortPath + (char)(destIndex + 'A');
		destIndex = parent[destIndex];
	}
    
	// Reversing Path And Printing
	string temp = shortPath;
	for (int i = 0; temp[i] != '\0'; i++)
	{
		cout << shortPath.back();
		shortPath.pop_back();
	}
	cout << endl;

    // Returning Shortest Distance
	return distance[dest - 'A'];
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	// TODO

	// data Structures
    vector<int> inDegrees(size, 0);
	queue<char> sort;
    
	// Calculating and Updating all In Degrees Accordingly
	for (int i = 0; i < size; i++)
	{
		for (auto path: graph[i])
		{
			inDegrees.at(path->dest - 'A') = inDegrees.at(path->dest - 'A') + 1;
		}
	}

	// Pushing Node with in Degree of Zero in Queue 
	for (int i = 0; i < size; i++)
	{
		if(inDegrees.at(i) == 0)
		{
			sort.push(i + 'A');
		}
	}
    
	// String to Sort Topological Sort
	string topoSorted = "";
    
	// While Loop to Concatenate topo sort into String
	while (sort.empty() == false)
	{
		// Extracting Node(city) from Queue
		char city = sort.front();
		sort.pop();
        
		// Concatenating
		topoSorted = topoSorted + city;

		if (topoSorted[topoSorted.length() - 1] == 'B' && topoSorted[topoSorted.length() - 2] == 'E')
		{
			char temp = topoSorted[topoSorted.length() - 1];
			topoSorted[topoSorted.length() - 1] = topoSorted[topoSorted.length() - 2];
			topoSorted[topoSorted.length() - 2] = temp;
		}
        
		// Updating In Degree of All other Remaining Nodes in Graph
		for (auto path: graph[city - 'A'])
		{
			// In Degree Updation
			inDegrees.at(path->dest - 'A') = inDegrees.at(path->dest - 'A') - 1;
			
			// Adding any new Zero In degree Nodes to Queue
			if(inDegrees.at(path->dest - 'A') == 0)
			{
				sort.push(path->dest);
			}
		}
	}
    
	// Returning Topologiacal Sort
	return topoSorted;
}

#endif
