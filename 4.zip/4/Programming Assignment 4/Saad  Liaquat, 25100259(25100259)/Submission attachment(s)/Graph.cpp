#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the
// flag to it too.
//
char Graph::cityToIndex(int index)
{
	char *mapArray = new char[size];
	for (int i = 0; i < size; i++)
	{
		mapArray[i] = char(65 + i);
	}
	return mapArray[index];
}
int Graph::indextoCity(char character)
{
	char *mapArray = new char[size];
	for (int i = 0; i < size; i++)
	{
		mapArray[i] = char(65 + i);
	}
	for (int i = 0; i < size; i++)
	{
		if (mapArray[i] == character)
		{
			return i;
		}
	}
}
Edge::Edge(char start, char end, int w)
{
	origin = start;
	dest = end;
	weight = w;
}
Graph::Graph(string filename, bool flag)
{
	string read;
	int nodes = 0;
	int edges = 0;
	// TODO
	ifstream fileToRead;
	int edgeCount = 0;
	fileToRead.open(filename);

	while (!fileToRead.eof())
	{
		if (edges == edgeCount && edges != 0)
		{
			break;
		}
		string temp;
		getline(fileToRead, read);
		if (read[0] == 'n')
		{
			for (int i = 1; i < read.length(); i++)
			{
				if (read[i] == ' ')
				{
					continue;
				}
				temp = temp + read[i];
				nodes = stoi(temp);
			}
			size = nodes;
			for (int i = 0; i < size; i++)
			{
				list<shared_ptr<Edge>> forMapping;
				graph.push_back(forMapping);
			}
			continue;
		}
		else if (read[0] == 'c')
		{
			for (int i = 1; i < read.length(); i++)
			{
				if (read[i] == ' ')
				{
					continue;
				}
				temp = temp + read[i];
				edges = stoi(temp);
			}
			continue;
		}
		else
		{
			edgeCount = edgeCount + 1;
			char start = read[0];
			char end = read[2];
			int cost;
			for (int i = 3; i < read.length(); i++)
			{
				if (read[i] == ' ')
				{
					continue;
				}
				temp = temp + read[i];
				cost = stoi(temp);
			}
			addEdge(start, end, cost, flag);
			continue;
		}
	}
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	if (flag == true)
	{
		for (int i = 0; i < size; i++)
		{
			if (cityToIndex(i) == start)
			{
				shared_ptr<Edge> edge = make_shared<Edge>(start, end, weight);
				graph.at(i).push_back(edge);
				break;
			}
			else
			{
				continue;
			}
		}
	}
	if (flag == false)
	{
		for (int i = 0; i < size; i++)
		{
			if (cityToIndex(i) == start)
			{
				shared_ptr<Edge> edge = make_shared<Edge>(start, end, weight);
				graph.at(i).push_back(edge);
				break;
			}
			else
			{
				continue;
			}
		}
		for (int i = 0; i < size; i++)
		{
			if (cityToIndex(i) == end)
			{
				shared_ptr<Edge> edge = make_shared<Edge>(end, start, weight);
				graph.at(i).push_back(edge);
				break;
			}
			else
			{
				continue;
			}
		}
	}
	// TODO
	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	cout << endl
		 << endl;
	string result;
	for (int i = 0; i < graph.size(); i++)
	{
		if (graph.at(i).size() == 0)
		{
			continue;
		}
		for (auto j = graph.at(i).begin(); j != graph.at(i).end(); j++)
		{
			int w = (*j)->weight;
			result = result + "(" + (*j)->origin + "," + (*j)->dest + "," + to_string(w) + ") ";
		}
		result = result + '\n';
	}
	// TODO
	cout << result;
	return result;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	if (start == end)
	{
		return true;
	}
	bool visited[size];
	for (int i = 0; i < size; i++)
	{
		visited[i] = false;
	}

	queue<char> q1;
	for (int i = 0; i < size; i++)
	{
		if (cityToIndex(i) == start)
		{
			if (graph.at(i).size() != 0)
			{
				q1.push(cityToIndex(i));
				visited[i] = true;
			}
			else
			{
				return false;
			}
		}
	}
	while (!q1.empty())
	{
		char temp = q1.front();
		q1.pop();
		for (int i = 0; i < size; i++)
		{
			if (cityToIndex(i) == temp)
			{
				if (graph.at(i).size() != 0)
				{
					for (auto j = graph.at(i).begin(); j != graph.at(i).end(); j++)
					{

						if (visited[indextoCity((*j)->dest)] == false)
						{
							visited[indextoCity((*j)->dest)] = true;
							q1.push((*j)->dest);
							if ((*j)->dest == end)
							{
								return true;
							}
						}
					}
				}
				break;
			}
		}
	}

	// TODO
	return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	char currentVertix = start;
	int minCostToVertix[size];
	for (int i = 0; i < size; i++)
	{
		minCostToVertix[i] = 342233232;
	}
	if (Reachable(start, dest) == false)
	{
		return -1;
	}
	bool visited[size];
	for (int i = 0; i < size; i++)
	{
		visited[i] = false;
	}
	if (Reachable(start, dest) == false)
	{
		return -1;
	}
	string path[size];
	for (int i = 0; i < size; i++)
	{
		path[i] = "";
	}
	minCostToVertix[indextoCity(currentVertix)] = 0;
	path[indextoCity(currentVertix)] = start;
	int index = indextoCity(currentVertix);
	while (cityToIndex(index) != dest)
	{
		currentVertix = cityToIndex(index);
		visited[index] = true;
		for (auto i = graph.at(index).begin(); i != graph.at(index).end(); i++)
		{
			int currentCostToVertix = minCostToVertix[indextoCity(currentVertix)] + (*i)->weight;
			if (minCostToVertix[indextoCity((*i)->dest)] > currentCostToVertix)
			{
				minCostToVertix[indextoCity((*i)->dest)] = currentCostToVertix;
				path[indextoCity((*i)->dest)] = path[index] + (*i)->dest;
			}
		}

		int minimum = 434344;
		for (int i = 0; i < size; i++)
		{
			if (visited[i] == false)
			{
				if (minCostToVertix[i] < minimum)
				{
					minimum = minCostToVertix[i];
					index = i;
				}
			}
		}
	}
	cout << path[index] << endl;
	return minCostToVertix[index];
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	vector<list<shared_ptr<Edge>>> actualCopyGraph;
	string result = "";
	int inDegrees[size];
	for (int i = 0; i < size; i++)
	{
		inDegrees[i] = 0;
	}
	vector<list<shared_ptr<Edge>>> tempGraph;
	for (int i = 0; i < size; i++)
	{
		list<shared_ptr<Edge>> l1;
		tempGraph.push_back(l1);
		actualCopyGraph.push_back(l1);
	}
	int tracker = 0;
	for (int i = 0; i < graph.size(); i++)
	{
		// cout << "INSIDE GRAPH" << endl;
		for (int j = 0; j < graph.at(i).size(); j)
		{
			// cout << "LIST" << endl;
			inDegrees[indextoCity(graph.at(i).front()->dest)] = inDegrees[indextoCity(graph.at(i).front()->dest)] + 1;
			shared_ptr<Edge> edge = make_shared<Edge>(graph.at(i).front()->origin, graph.at(i).front()->dest, graph.at(i).front()->weight);
			tempGraph.at(i).push_back(graph.at(i).front());
			actualCopyGraph.at(i).push_back(edge);
			graph.at(i).pop_front();
		}
	}
	graph = actualCopyGraph;
	int oldinDegrees[size];
	while (true)
	{
		// cout<<size<<endl;
		if (result.length() == size)
		{
			return result;
		}
		for (int i = 0; i < size; i++)
		{
			oldinDegrees[i] = inDegrees[i];
		}
		for (int i = 0; i < size; i++)
		{
			if (oldinDegrees[i] == 0)
			{
				result = result + cityToIndex(i);
				for (int j = 0; j < tempGraph.at(i).size(); j)
				{
					inDegrees[indextoCity(tempGraph.at(i).front()->dest)] = inDegrees[indextoCity(tempGraph.at(i).front()->dest)] - 1;
					tempGraph.at(i).pop_front();
				}
				inDegrees[i] = 345334;
			}
		}
	}
}

#endif
