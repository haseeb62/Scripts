#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	ifstream readFile;
	string readLine;
	readFile.open(filename);
	getline(readFile, readLine);
	int numVertices = stoi(readLine.substr(2));
	getline(readFile, readLine);
	int numEdges = stoi(readLine.substr(2));
	graph = vector<list<shared_ptr<Edge>>>(numVertices); 
	while(!readFile.eof())
	{
		getline(readFile, readLine);
		if (readLine == "")
			break;
		addEdge(readLine[0], readLine[2], stoi(readLine.substr(4, readLine.length() - 1)), flag);
	}
	readFile.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	shared_ptr<Edge> tempEdge = make_shared<Edge>(start, end, weight);
	graph[findKey(start)].push_back(tempEdge);
	if (!flag)
	{
		tempEdge = make_shared<Edge>(end, start, weight);
		graph[findKey(end)].push_back(tempEdge);
	}
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string str;
	for (auto i = graph.begin(); i != graph.end(); i++)
	{
		if (!(*i).size())
			continue;
		sortList(*i);
		for (auto j = (*i).begin(); j != (*i).end(); j++)
			str += (*j)->dumps() + " ";
		str += "\n";
	}
	return str;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// TODO
	static vector<char> soFar;
	soFar.push_back(start);
	if (start == end)
	{
		soFar.pop_back();
		return true;
	}
	list<shared_ptr<Edge>> gList = graph[findKey(start)];
	for (auto i = gList.begin(); i != gList.end(); i++)
	{
		if (std::count(soFar.begin(), soFar.end(), (*i)->dest))
			continue;
		bool flag = Reachable((*i)->dest, end);
		if (flag)
		{
			soFar.pop_back();
			return true;
		}
	}
	soFar.pop_back();
	return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// TODO
	if (!Reachable(start, dest))
		return -1;

	char startNode = start, goalNode = dest;
	vector<char> visitedNodes;
	vector<shared_ptr<Edge>> frontier;
	vector<vector<char>> path(graph.size());
	path[findKey(start)].push_back(startNode);
	frontier.push_back(make_shared<Edge>(startNode, ' ', 0));

	while (frontier.size())
	{

		shared_ptr<Edge> currentNode = getMin(frontier);

		visitedNodes.push_back(currentNode->origin);

		if (currentNode->origin == goalNode)
		{
			cout << computePath(path[findKey(currentNode->origin)]);
			return currentNode->weight;
		}
		vector<shared_ptr<Edge>> neighbors = getNeighbors(graph[findKey(currentNode->origin)]);
		for (auto i = neighbors.begin(); i != neighbors.end(); i++)
		{
			bool flag = false;
			if (std::count(visitedNodes.begin(), visitedNodes.end(), (*i)->origin))
				continue;
			int newCost = currentNode->weight + (*i)->weight;
			for (auto j = frontier.begin(); j != frontier.end(); j++)
			{
				if ((*i)->origin == (*j)->origin)
				{
					if (newCost < (*j)->weight)
					{
						(*j)->weight = newCost;
						path[findKey((*i)->origin)] = path[findKey(currentNode->origin)];
						path[findKey((*i)->origin)].push_back((*i)->origin);
					}
					flag = true;
					break;
				}
			}
			if (flag)
				continue;
			frontier.push_back(make_shared<Edge>((*i)->origin, ' ', newCost));
			path[findKey((*i)->origin)] = path[findKey(currentNode->origin)];
			path[findKey((*i)->origin)].push_back((*i)->origin);
		}
	}
	

	return 0;
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	//TODO
	vector<char> vertices;
	for (int i = 0; i < graph.size(); i++)
		vertices.push_back(65+ i);

	vector<char> path;
	string str;
	DFS('A', graph, 0, path);
	for (auto i = path.begin(); i != path.end(); i++)
		str = *i + str;
	path.clear();
	while (str.length() != graph.size())
	{
		for (auto j = vertices.begin(); j != vertices.end(); j++)
		{
			bool flag = false;
			for (int i = 0; i != str.length(); i++)
			{
				if (*j == str[i])
				{
					flag = true;
					break;
				}
			}
			if (flag)
				continue;
			else
			{
				DFS(*j, graph, 0, path);
				for (auto i = path.begin(); i != path.end(); i++)
					str = *i + str;
				path.clear();
				break;
			}
		}
	}
	DFS(' ', graph, -1, path);
	return str;
}

Edge::Edge(char start, char end, int cost)
{
	origin = start;
	dest = end;
	weight = cost;
}

int Graph::findKey(char value)
{
	int key = value - 65;
	return key;
}

string Edge::dumps()
{
	string str = "(";
	str.push_back(origin);
	str += ",";
	str.push_back(dest);
	str += "," + to_string(weight) + ")";
	return str;
}

void Graph::sortList(list<shared_ptr<Edge>>& gList)
{
	for (auto i = gList.begin(); i != gList.end(); i++)
	{
		for (auto j = i; j != gList.end(); j++)
		{
			if ((*i)->dest > (*j)->dest)
			{
				shared_ptr<Edge> temp = *i;
				*i = *j;
				*j = temp;
			}
		}
	}
}

shared_ptr<Edge> Graph::getMin(vector<shared_ptr<Edge>>& frontier)
{
	for (auto i = frontier.begin(); i != frontier.end(); i++)
	{
		for (auto j = frontier.begin(); j != frontier.end(); j++)
		{
			if ((*i)->weight > (*j)->weight)
			{
				shared_ptr<Edge> temp = *i;
				*i = *j;
				*j = temp;
			}
		}
	}
	
	shared_ptr<Edge> ret = *(frontier.end() - 1);
	frontier.pop_back();
	return ret;
}

vector<shared_ptr<Edge>> Graph::getNeighbors(list<shared_ptr<Edge>> gList)
{
	vector<shared_ptr<Edge>> neighbors;
	for (auto i = gList.begin(); i != gList.end(); i++)
		neighbors.push_back(make_shared<Edge>((*i)->dest, ' ', (*i)->weight));

	return neighbors;
}

string Graph::computePath(vector<char> node)
{
	string str;
	for (auto i = node.begin(); i != node.end(); i++)
	{
		str.push_back(*i);
		str += " ";
	}
	str += "\n";
	return str;
}

void Graph::DFS(char start, vector<list<shared_ptr<Edge>>> graph, int count, vector<char>& path)
{
	static vector<char> visitedNodes;
	if (count == -1)
	{
		visitedNodes.clear();
		return;
	}
	if (std::count(visitedNodes.begin(), visitedNodes.end(), start))
		return;
	vector<shared_ptr<Edge>> neighbors = getNeighbors(graph[findKey(start)]);

	for (auto i = neighbors.begin(); i != neighbors.end(); i++)
		DFS((*i)->origin, graph, ++count, path);
	visitedNodes.push_back(start);
	path.push_back(start);
}

// int main()
// {
// 	Graph g1("test4a.txt", true);
// 	// cout << g1.display();
// 	cout << g1.topoSort() << endl;

// 	// cout << g1.Dijkstra('F', 'D');
// 	// cout << g1.Reachable('E', 'B') << endl;
// 	// cout << g1.Reachable('A', 'F') << endl;
// 	// cout << g1.Reachable('D', 'F') << endl;
// 	// cout << g1.Reachable('B', 'D') << endl;
// }
#endif
