#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <fstream>
#include <string>

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	char c;
	string text;
	ifstream file;
	int count = 0;
	file.open(filename);
	if(file.is_open())
	{
		while (file.get(c))
		{
			if(c == '\n')  //count incremented to skip first two lines of the text file
			count++;

			if( count >= 2) 
			{
				if(c!= ' ' && c!= '\n') // all spaces and endlines removed and text is concatenated in a string
				text += c; 
			}
		}
	}

	for (int i = 0; i < text.length()-1; i+=3)
	{
		addEdge(text[i],text[i+1],int(text[i+2] - '0'),flag); //all edges added into graph
	}

	file.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	bool added1 = false; 
	bool added2 = false;
	
	for(int i= 0; i < graph.size(); i++) //if node already exists in graph, append extra edges connected to that node 
	{
		if(graph[i][0]->origin == start)
		{
			added1 = true; 
			graph[i].push_back(make_shared<Edge>(start, end, weight));
			break;
		}
	}
	
	if (!flag) // if the graph is undirected, the reverse edges are also added
	{
		for(int i= 0; i < graph.size(); i++)
		{
			if(graph[i][0]->origin == end)
			{
				graph[i].push_back(make_shared<Edge>(end, start, weight));
				added2 = true;
				break;
			}
		}
	}

	if(added1 == false) // false value indicates the node didnt exist already in the graph
	{
		vector<shared_ptr<Edge>> g; // make new new 
		g.push_back(make_shared<Edge>(start, end, weight)); //add edges for that node
		graph.push_back(g);
		added1 = true;
	}

	if(added2 == false && !flag) //if the graph is undirected and the node didnt already exist in the graph, create the node and add corresponding edges
	{
		vector<shared_ptr<Edge>> g;
		g.push_back(make_shared<Edge>(end, start, weight));
		graph.push_back(g);
	}

	return;
}
//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
    string output = "";
    
    for (int i=0; i < graph.size(); i++)
    {
        for(int j =0; j < graph[i].size(); j++)
        {
            output += "(" + string(1,(char)graph[i][j]->origin) + ',' + string(1,(char)graph[i][j]->dest) + ',' + to_string(graph[i][j]->weight) + ')' + ' ';
        }

        output += '\n';
    }
    return output;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
    int index = 0;
    vector<char> v;
	vector<char> visited;
    bool reachable = false;
    int st_idx = findidx(start); //return index of source node in the graph
         
	for (int j = 0; j < graph[st_idx].size(); j++)
	{
		v.push_back(graph[st_idx][j]->dest);  // stores all neighbours of source node
	}
	
    while (!v.empty()) // exploring neighbours vector
    {
        if (v[0] == end) // check if the first node is the goal node and return true
        {
			return true; 
        }

		visited.push_back(v[0]); //the first node is marked as visited

        int idx = findidx(v[0]); 
		
		
		for (int i = 0; i < graph[idx].size(); i++) //neighbours of first node are added to the neighbours vector if not already visited
		{
			bool present = false;
			for (int j = 0; j < visited.size(); j++)
			{
				if (graph[idx][i]->dest == visited[j])
				present = true;
			}
			if(!present)

			v.push_back(graph[idx][i]->dest);
		}
		
        v.erase(v.begin()); //removing first node from the vector
    }

    return false; //if whole graph checked and node not found, return false
}

int Graph:: findidx(char c) // function to return the index of the vector whoch stores all neighbours with that node as source node
{
	int index;
	for (int i = 0; i < graph.size(); i++)
	{
		if (graph[i][0]->origin == c)
		{
			index = i;
			return index;
		}
	}
	return -1;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//

int Graph::Dijkstra(char start, char dest)
{
	int ans;
	if(!Reachable(start,dest)) //if a node isnt reachable, set cost as -1
	return -1;

	//making a min-heap priority queue with a 3 tuple consisting of cost to reach a node, the node itself, and the path taken
	priority_queue<tuple<int, char, string>, vector<tuple<int, char, string>>, greater<tuple<int, char, string>>> pq;
	pq.push(make_tuple(0, start, string(1,start))); // source node added to queue
	vector<char> visited;
	
	while(!pq.empty())
	{
		tuple<int,char,string> top_element = pq.top(); //dequeueing element with min cost
		pq.pop();
		
		 //parsing the tuple
		int costn = get<0>(top_element);
		char next_node = get<1>(top_element);
		string s = get<2>(top_element);

		bool p = present(next_node, visited); //cheking if node already visited
		
		if (next_node == dest) //checking if node is the goal
		{
			cout << s << endl;
			ans = costn;
			return costn;
		}
		else
		{
			if(p) //if node already visited, continue the while loop and dequeue the next node
			continue;

			if (!p) // if not visited, add neighbouring nodes to the queue with updated costs and paths
			{
				int idx1 = findidx(next_node);
				for(int m = 0; m < graph[idx1].size(); m++)
				{
					pq.push(make_tuple(costn+graph[idx1][m]->weight, graph[idx1][m]->dest, s+string(1,graph[idx1][m]->dest)));
				}
			}
			visited.push_back(next_node);
		}
	}
	return ans;
}

bool Graph:: present(char c, vector<char> list) // returns true if a node is present in a vector
{
	for (int i= 0; i <list.size();i++)
	{
		if(list[i] == c)
		{
			return true;
		}
	}
	return false;
}

// Implement how to make a priority queue in c sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
    string sort = "";
    vector<vector<shared_ptr<Edge>>> copy = graph; //copying the graph
	
	vector<char> nodes;
	bool present = false;
	// adding all unique node to a vector

	for (int i = 0; i < graph.size(); i++) //adding all source nodes to the node vector
	{
		nodes.push_back(graph[i][0]->origin);
	}

	for(int i=0; i<graph.size();i++) // adding any dest node to the node vector if it never occurs as a source (has in degree 0)
	{
		for(int j=0; j < graph[i].size();j++)
		{
			for(int m=0; m<nodes.size(); m++)
			{
				if (graph[i][j]->dest == nodes[m])
				{
					present = true;
					break;
				}
			}

			if (!present)
			{
				nodes.push_back(graph[i][j]->dest);
			}
			present = false;
		}
	}
	
    while (!nodes.empty()) //loop goes on until all nodes have been topologically sorted and graph is empty
    {
		vector<int> v;
		for (int i = 0; i < nodes.size(); i++) // calculating in-degrees of all nodes
		{
			v.push_back(inDegree(nodes[i]));
		}
	
        vector<int> min = minIdx(v); //returns the indices of nodes which have in degree 0

        for (int i = 0; i < min.size(); i++) // these node are adding to the topological sort string
        {
            sort += nodes[min[i]];
        }

		for (int i = 0 ;i < min.size();i++) // then these nodes are removed from the graph and the node vector
		{
			nodes.erase(nodes.begin()+min[i]-i);
			removeVertex(graph[min[i]-i][0]->origin);
		}
    }

    graph = copy; //remaking the graph
    return sort;
}

void Graph::removeVertex(char c) //removes all edge of a given vertex from the graph
{
    for (int i = 0; i < graph.size(); i++)
    {
        if (graph[i][0]->origin == c)
        {
            graph.erase(graph.begin() + i);
            break;
        }
    }
}

vector<int> Graph:: minIdx(vector<int> v) //returns the indices of nodes which have in degree 0
{ 
	vector <int> v2;
	
	for(int i=0; i < v.size(); i++)
	{
		if(v[i]==0)
		v2.push_back(i);
	}
	return v2;
}

int Graph:: inDegree(char c)
{
	int indegree = 0;
	for(int i=0; i< graph.size(); i++)
	{
		for(int j=0; j<graph[i].size(); j++)
		{
			if(graph[i][j]->dest == c)
			{
				indegree++;
			}
		}
	}

	return indegree;
}



#endif
