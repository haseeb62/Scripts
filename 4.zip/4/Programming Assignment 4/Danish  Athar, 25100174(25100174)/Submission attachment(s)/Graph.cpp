#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the
// flag to it too.
//
Edge::Edge()
{
	this->origin = ' ';
	this->dest = ' ';
	this->weight = 0;
}

Edge::Edge(char origin, char dest, int weight)
{
	// constructor for making edges
	this->origin = origin;
	this->dest = dest;
	this->weight = weight;
}

int Graph::nameToIdx(char name)
{
	// helper function as suggested by comments in the header file
	//  convert ascii value of capital letter to int by subtracting value of first capital letter
	return (name - 65);
}

char Graph::idxToName(int idx)
{
	// simply do the reverse of nametoIdx and cast it to char
	return static_cast<char>(idx + 65);
}

void Graph::dfs(int node, vector<bool> &visited)
{
	// use dfs for checking reachability as given in slides
	// since my nodes dont have a visited field, i am using a separate vector keeping track of this visited field for all nodes
	visited[node] = true;

	for (int v = 0; v < graph.size(); v++)
	{
		if (graph[node][v] != NULL && !visited[v])
		{
			// continue traversal if possible
			dfs(v, visited);
		}
	}
}

Graph::Graph(string filename, bool flag)
{
	// TODO
	ifstream graphTextfile(filename);
	string line;
	char start;
	char end;

	if (graphTextfile.is_open())
	{
		while (getline(graphTextfile, line))
		{
			if (line[0] == 'n')
			{
				// if line starts with n then it is telling the no of nodes/cities
				// extract the actual size number from the end of the line
				int nodes = 0;
				for (int i = 0; i < line.size(); i++)
				{
					// take each digit(subtract ascii value of 0 from digit character in string to get actual digit)
					// and add it to number (scale by multiplying with ten for units, tens, hundreds places etc.)
					if (isdigit(line[i]))
					{
						nodes = nodes * 10 + (line[i] - 48);
					}
				}
				// initialise graph to have this many rows/columns
				// cout << "initialised graph with " << nodes << " nodes" << endl;
				vector<vector<shared_ptr<Edge>>> temp(nodes, vector<shared_ptr<Edge>>(nodes, nullptr));
				graph = temp;
			}
			if (line[0] == 'c')
			{
				// if line starts with c then it is telling the size (no of edges)
				// extract the actual size number from the end of the line
				int edges = 0;
				for (int i = 0; i < line.size(); i++)
				{
					// take each digit(subtract ascii value of 0 from digit character in string to get actual digit)
					// and add it to number (scale by multiplying with ten for units, tens, hundreds places etc.)
					if (isdigit(line[i]))
					{
						edges = edges * 10 + (line[i] - 48);
					}
				}
				size = edges;
				// double the size for undirected graphs
				if (flag == false)
				{
					size = size * 2;
				}
				// cout << "set size of graph to " << size << " with directed flag " << flag << endl;
			}
			else if (line[0] >= 65 && line[0] <= 90)
			{
				// if line starts with a capital alphabet then its giving info about an edge
				// first character of line is starting node, next after a space is dest/end
				start = line[0];
				end = line[2];

				// we have the cost at the end of the string, convert it into an actual integer
				int cost = 0;
				for (int i = 0; i < line.size(); i++)
				{
					// take each digit(subtract ascii value of 0 from digit character in string to get actual digit)
					// and add it to number (scale by multiplying with ten for units, tens, hundreds places etc.)
					if (isdigit(line[i]))
					{
						cost = cost * 10 + (line[i] - 48);
					}
				}
				addEdge(start, end, cost, flag);
				// cout << "added edge " << start << " " << end << " " << cost << endl;
			}
		}
	}
	else
	{
		cout << "No file open" << endl;
	}

	graphTextfile.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	// create edge and add to graph
	// cout << "in add edge" << endl;
	int startIdx = nameToIdx(start);
	int endIdx = nameToIdx(end);
	// cout << "create new edge" << endl;
	shared_ptr<Edge> new_edge(new Edge(start, end, weight));

	// cout << "startIdx: " << startIdx << " of node " << start << ", endIdx: " << endIdx << " of node " << end <<endl;

	graph[startIdx][endIdx] = new_edge;

	// for undirected, an edge starting from endIdx and ending at Startidx is also needed
	if (flag == false)
	{
		// cout << "adding reverse edge" << endl;
		shared_ptr<Edge> reverse_edge(new Edge(end, start, weight));
		graph[endIdx][startIdx] = reverse_edge;
	}
	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string output = "";
	for (int i = 0; i < graph.size(); i++)
	{
		for (int j = 0; j < graph[i].size(); j++)
		{
			if (graph[i][j])
			{
				shared_ptr<Edge> edge = graph[i][j];
				output += "(" + string(1, edge->origin) + "," + string(1, edge->dest) + "," + to_string(edge->weight) + ") ";
			}
		}
		output += "\n";
	}
	return output;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// TODO
	// make a vector that shows what nodes can be visited starting from start
	vector<bool> visited(graph.size(), false);

	// run graph traversal from starting node, im using dfs like sir's slides
	// start is a char, to convert it into a graph index, use the helper function nameToIdx
	dfs(nameToIdx(start), visited);

	// if ending node (corresponding index of end) was visited starting from starting node (corresponding index of start)
	// then its reachable
	if (visited[nameToIdx(end)])
	{
		return true;
	}
	// otherwise its not
	else
	{
		return false;
	}
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// if this fails, pls rerun on Haseeb-ur-Rehman TA's mac (or any mac i think), i emailed him this code
	// and it works for him. he said i will get marks for this cus it works fine there.
	//update: nvm fixed it

	// TODO
	// setting initial distances to a high value instead of infinity as given in slides
	vector<int> distances(graph.size(), 9999);
	// find the indices of the starting and destination nodes
	int start_index = nameToIdx(start);
	int dest_index = nameToIdx(dest);

	// initialize visited array to false
	bool visited[26];
	for (int i=0; i<26; i++)
	{
		visited[i] = false;
	}
	// store parents' index of each node (max 26)
	int parent[26];
	// initialise to -1
	for (int i = 0; i < 26; i++)
	{
		parent[i] = -1;
	}

	// set distance to starting node to 0
	distances[start_index] = 0;

	// cout << "start dijkstra for " << start << " to " << dest << endl;
	// run Dijkstra's algorithm from the starting node
	for (int i = 0; i < graph.size() - 1; i++)
	{
		// find the vertex with minimum distance from the starting node
		int min_distance = 9999;
		int min_index = -1;
		for (int j = 0; j < graph.size(); j++)
		{
			if (!visited[j] && distances[j] < min_distance)
			{
				min_distance = distances[j];
				min_index = j;
			}
		}

		// mark the minimum distance vertex as visited
		visited[min_index] = true;
		// cout << min_index << " visited" << endl;

		// cout << graph[min_index].size() << " size" << endl;
		for (int j = 0; j < graph[min_index].size(); j++)
		{
			// cout << "Checking edge " << j << " of vertex " << min_index << endl;
			if (graph[min_index][j])
			{
				int neighbor_index = nameToIdx(graph[min_index][j]->dest);
				int edge_weight = graph[min_index][j]->weight;
				int new_distance = distances[min_index] + edge_weight;
				if (new_distance < distances[neighbor_index])
				{
					distances[neighbor_index] = new_distance;
					parent[neighbor_index] = min_index;
				}
			}
		}
	}

	// cout << "dijkstra done" << endl;
	// return the distance of the destination node from the starting node
	if (distances[dest_index] == 9999)
	{
		// cout << "returning -1" << endl;
		return -1;
	}
	else
	{
		cout << "returning distance " << distances[dest_index] << " from " << start << " to " << dest << endl;

		// store path in an array of chars/string
		char path[26];
		int path_len = 0;

		// find parent of each node from dest to backtrack and find path
		int current = dest_index;
		while (current != -1)
		{
			path[path_len++] = idxToName(current);
			current = parent[current];
		}

		// print out said path
		cout << "Path is ";
		for (int i = path_len - 1; i >= 0; --i)
		{
			cout << path[i];
		}
		cout << endl;

		// return min distance
		return distances[dest_index];
	}
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	// TODO
	// Initialize in-degree for all vertices
	vector<int> indegrees(graph.size(), 0);
	for (int i = 0; i < graph.size(); i++)
	{
		int indegree = 0;
		for (int j = 0; j < graph[i].size(); j++)
		{
			if (graph[j][i])
			{
				indegree++;
			}
		}
		indegrees[i] = indegree;
	}
	// cout << "indegrees are" << endl;
	// for (int i = 0; i < indegrees.size(); i++)
	// {
	// 	cout << indegrees[i] << " ";
	// }
	// cout << endl;
	// get vertices with 0 in degree and add them to a queue
	queue<int> q;
	for (int i = 0; i < indegrees.size(); i++)
	{
		if (indegrees[i] == 0)
		{
			// cout << i << " has 0 indegree" << endl;
			q.push(i);
		}
	}

	// store resulting string in a variable
	string result = "";

	// take each vertex out of queue, decrease the in degree of all successor vertices to it, and continue
	while (!q.empty())
	{
		// take the vertex at the front
		int curr = q.front();
		q.pop();
		// cout << "add " << curr << " to ressult" << endl;
		// add it to result
		result += idxToName(curr);
		for (int i = 0; i < graph[curr].size(); i++)
		{
			if (graph[curr][i])
			{
				// for each of its valid successors (dests), decrease their in degree by one since this one is essentially be removed from the graph
				int dest = nameToIdx(graph[curr][i]->dest);
				indegrees[dest]--;
				// if another vertex now has indegree 0 after the decrease, add it to queue
				if (indegrees[dest] == 0)
				{
					q.push(dest);
				}
			}
		}
	}

	// once done, return
	return result;
}

#endif
