#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <queue>
#include <stack>

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	fstream f;
	f.open(filename,ios::in);
	if (f.is_open()){
		string s;
		int n=0;
		while (getline(f, s)){
		
		if (s[0]=='n'){
			n=s[2]-'0';
		}
		else if (s[0]=='c'){
		}
		else {
			char start=s[0];
			char end=s[2];
			int cost=s[4]-'0';
			graph.resize(n);
			addEdge(start,end,cost,flag);
		}
		}
	}
	f.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	if (flag==true){ // for directed
		shared_ptr<Edge> e = make_shared<Edge>();
		e->origin=start;
		e->dest=end;
		e->weight=weight;
		int index=int(start)-65;
		graph[index].push_back(e);
	}
	else{ // for undirected
		shared_ptr<Edge> e = make_shared<Edge>();
		e->origin=start;
		e->dest=end;
		e->weight=weight;
		int index=int(start)-65;
		graph[index].push_back(e);	
		shared_ptr<Edge> e1 = make_shared<Edge>();
		e1->origin=end;
		e1->dest=start;
		e1->weight=weight;
		index=int(end)-65;
		graph[index].push_back(e1);
	}
	
	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string ret="";
	for (int i=0;i<graph.size();i++){
		if (graph[i].size()!=0){
		for (int j=0;j<graph[i].size();j++){

			list<shared_ptr<Edge>>::iterator it = graph[i].begin();
    		advance(it, j);
			ret=ret+"("+(*it)->origin+","+(*it)->dest+",";
			ret=ret+to_string((*it)->weight)+")"+" ";
		}
		ret=ret+"\n";
		}
	}
	ret=ret+"\n";
	cout<<ret;
	return ret;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// TODO

	int index=int(start)-65;
	vector<bool> visited; //keeps track of the nodes that are already visited
	visited.resize(graph.size());
	queue<int> s; // queue to keep track of the nodes to be visited
	s.push(index); //pushing in the first node (starting node)
	visited[index]=true;
	while(!(s.empty())){	
		int i=s.front();
		s.pop();
	if (graph[i].size()!=0){
		for (int j=0;j<graph[i].size();j++){ // enqueueing all adjacent nodes

			list<shared_ptr<Edge>>::iterator it = graph[i].begin();
			advance(it, j);
			if ((*it)->dest==end){ // returns true if dest is found
				return true;
			}
			else{
				int new_index=int((*it)->dest)-65; 
				if (visited[new_index]!=true){ //checks to see if a node has already been visited
					s.push(new_index);
					visited[new_index]=true;
				}
			}
		}
		}
	}
	return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// TODO
	if (Reachable(start,dest)){ // checks to see if a path exists between the two nodes

		vector<int> final_cost; // keeps track of the cost of the shortest path
		final_cost.resize(graph.size());
		vector<int> temp_cost; // keeps track of the changing cost while finding cost for shortest path
		temp_cost.resize(graph.size()); 
		int index=int(start)-65;
		vector<bool> visited; //keeps track of the nodes that are already visited
		visited.resize(graph.size());
		int reps=0;
		vector<int> temp_vec; // keeps track of the cost of the shortest path
		temp_vec.resize(graph.size());
		for (int i=0;i<temp_cost.size();i++){
			
			temp_cost[i]=2147483647; // set the cost to each node to infinity
			final_cost[i]=2147483647; // set the cost to each node to infinity
			temp_vec[i]=2147483647; // set the cost to each node to infinity
			
		}
		final_cost[index]=0; // path cost to itself is 0
		temp_cost[index]=0; 
		visited[index]=true; // if the shortest path to a node has been discovered label it as visited
		while(reps<graph.size()){
			for (int j=0;j<graph[index].size();j++){
				list<shared_ptr<Edge>>::iterator it = graph[index].begin();
				advance(it, j);
				int temp_in=int((*it)->dest)-65; // finds the index corresponding the node visited
				if (visited[temp_in]!=true){ // checks too see if the shortest path for that path have been found already
					temp_cost[temp_in]=min(((*it)->weight+final_cost[index]),temp_cost[temp_in]); // assigns the minimum cost in temp_cost
					temp_vec[temp_in]=temp_cost[temp_in];
				}	
				else{

					temp_vec[temp_in]=2147483647;
				}
			}
			temp_vec[index]=2147483647; // changes cost to infinity of nodes whose shortest path have been found
			int temp_in=find_min(temp_vec);
			final_cost[temp_in]=temp_cost[temp_in];
			visited[temp_in]=true;
			index=temp_in;
			reps++;
		}
		int dest_in= int (dest)-65;
		return final_cost[dest_in];

	}
	else{ // returns -1 if path doesn't exist
		return -1;
	}

}

//
// Implement topological sort on the graph and return the string of the sorted cities
//

// find the first node to add let it be the one with zero indegree
// add to the topo sort ordering
// do this again

string Graph::topoSort()
{
    string output="";
	vector<int> in_deg;
	in_deg.resize(graph.size());
	for (int i=0;i<in_deg.size();i++){
		in_deg[i]=0; //initializing to zero
	}
	// finding the in-degree of each node
	find_in_deg(in_deg);

	// finding the node with in-degree zero to add to the topo sort
	while (output.size()!=graph.size()){
		for (int i=0;i<in_deg.size();i++){
			if (in_deg[i]==0){
				char temp= char(i+65); // finding the node with zero in-degree
				output=output+temp;
				in_deg[i]=2147483647; // changing the in-degree to a random number in this 
				change_in_deg(in_deg,i);
				break;
			}
		}
	}	
    return output;
}


// helper functions

// helper function to find the index of the min element
int Graph::find_min(vector<int> vec){
	
	// returns index of the min value in a vector
	int output=0;
	int min=vec[0]; // assigns the first element as the min initially
	for (int i=0;i<vec.size();i++){
		if (vec[i]<min){
			min=vec[i];
			output=i;
		}
	}
	return output;
}

// finds the in-degree of each node in the graph

void Graph::find_in_deg(vector<int>& vec){

	for (int i=0;i<graph.size();i++){
		for (int j=0;j<graph[i].size();j++){
			list<shared_ptr<Edge>>::iterator it = graph[i].begin();
			advance(it, j);
			int new_index=int((*it)->dest)-65;
			vec[new_index]=vec[new_index]+1; // increments the indegree of the dest
		} 
	}
}

// changes the in-degree of the target of the node removed

void Graph::change_in_deg(vector<int>& vec, int i){

	for (int j=0;j<graph[i].size();j++){
			list<shared_ptr<Edge>>::iterator it = graph[i].begin();
			advance(it, j);
			int new_index=int((*it)->dest)-65;
			vec[new_index]=vec[new_index]-1; // decrements the indegree of the dest
	}

}
#endif
