#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

Graph::Graph(string filename, bool flag)
{
	this->directed = flag;
	ifstream fin;
	fin.open(filename);

	string line;
	while(getline(fin,line))
	{
		if(line[0] == 'n' || line[0] == 'c')
		{
			continue;
		}
		
		else
		{
			int weight =  int(line[4]) - 48;
			addEdge(line[0],line[0],0,flag);
			addEdge(line[2],line[2],0,flag);

			addEdge(line[0],line[2],weight,flag);

			if(!flag)
			{
				addEdge(line[2],line[0],weight,flag);
			}
		}
	}
}

void Graph::addEdge(char start, char end, int weight, bool flag)
{
	shared_ptr<Edge> insert = make_shared<Edge>(start,end,weight);

	if(!graph.size())
	{
		vector<shared_ptr<Edge>> temp;
		temp.push_back(insert);
		graph.push_back(temp);
		return;
	}

	for(int i = 0;i<graph.size();i++)
	{
		if(graph[i][0]->origin==start)
		{
			for(int k = 0;k<graph[i].size();k++)
			{
				if(graph[i][k]->dest == end)
				{
					return;
				}
			}
			graph[i].push_back(insert);
			return;
		}
		else if(i == graph.size()-1)
		{
			vector<shared_ptr<Edge>> temp;
			temp.push_back(insert);
			graph.push_back(temp);
		}
	}
}

string Graph::display()
{
	string s1="";
	for(int i = 0;i<graph.size();i++)
	{
		for(int j = 1;j<graph[i].size();j++)
		{
			s1 = s1 + "(" + graph[i][j]->origin + "," + graph[i][j]->dest+  "," + to_string(graph[i][j]->weight)+ ")";
			s1 += '\n';
		}
		
	}
	cout<<s1<<endl;
	return s1;
}

bool Graph::Reachable(char start, char end)
{
	if(start == end)
	{
		return true;
	}

	queue<char> unvisited;
	vector<char> visited;

	char current;

	unvisited.push(start);
	visited.push_back(start);

	while(!unvisited.empty())
	{
		current = unvisited.front();
		unvisited.pop();

		for(int i = 0;i<graph.size();i++)
		{
			if(graph[i][0]->origin == current)
			{
				for(int j = 0;j<graph[i].size();j++)
				{
					if(graph[i][j]->dest ==  end)
					{
						return true;
					}

					auto index = find(visited.begin(),visited.end(), graph[i][j]->dest);
					if(index == visited.end())
					{
						unvisited.push(graph[i][j]->dest);
						visited.push_back((graph[i][j]->dest));
					}
				}
			}
		}
	}

	return false;
	
}

int Graph::Dijkstra(char start, char dest)
{

	if(!Reachable(start,dest))
	{
		return -1;
	}

	vector<int> costs;
	vector<char> visited,unvisited;
	int index = getIndex(start);

	for(int i = 0;i<graph.size();i++)
	{
		if(i == index)
		{
			costs.push_back(0);
		}
		else
		{
			costs.push_back(INT32_MAX);
		}
		unvisited.push_back(graph[i][0]->origin);
	}

	DijkstraHelper(start,costs,visited,unvisited,0);
	index = getIndex(dest);

	return costs[index];
}

void Graph::DijkstraHelper(char current, vector<int>& costs, vector<char> &visited, vector<char> &unvisited, int current_cost)
{
	if(unvisited.size() == 0)
	{
		return;
	}

	visited.push_back(current);
	unvisited.erase(remove(unvisited.begin(),unvisited.end(),current),unvisited.end());

	int index = getIndex(current);
	int dest_index = -1;

	for(int j = 1;j<graph[index].size();j++)
	{
		dest_index = getIndex(graph[index][j]->dest);
		if((graph[index][j]->weight + current_cost) < costs[dest_index])
		{
			costs[dest_index] = (graph[index][j]->weight + current_cost);
		}
	}

	int next_index = getMinIndex(costs,unvisited);
	if(next_index != -1)
	{
		current = unvisited[next_index];
		DijkstraHelper(current,costs,visited,unvisited,costs[getIndex(current)]);
	}

}

string Graph::topoSort()
{
	vector<int> costs;
	vector<char> origins;
	int cost;
	
	for(int i = 0;i<graph.size();i++)
	{	
		cost = 0;
		vector<bool> visited(graph.size(),false);
		DFS(i,cost,visited);
		costs.push_back(cost);
	}

	for(int i = 0;i<graph.size();i++)
	{
		origins.push_back(graph[i][0]->origin);
	}

	string str = "";
	while(origins.size())
	{
		int index = getMaxIndex(costs);
		str += origins[index];
		origins.erase(origins.begin() + index);
		costs.erase(costs.begin() + index);
	}

	return str;
}

void Graph::DFS(int current, int &num, vector<bool> &visited)
{

	num++;
	visited[current] = true;
	int index = -1;

	for(int i = 0;i<graph[current].size();++i)
	{
		index = getIndex(graph[current][i]->dest);

		if(index > -1)
		{
			if(!visited[index])
			{
				DFS(index, num, visited);
			}
		}
	}

}

int Graph::getIndex(char chr)
{
	for(int i = 0;i<graph.size();i++)
	{
		if(chr == graph[i][0]->origin)
		{
			return i;
		}
	}
	return -1;
}

int Graph::getMaxIndex(vector<int> vec)
{
	int max = vec[0];
	int index = 0;
	for(int i = 1;i<vec.size();i++)
	{
		if(vec[i]>max)
		{
			max = vec[i];
			index = i;
		}
	}
	return index;
}

int Graph::getMinIndex(vector<int> costs, vector<char> unvisited)
{
	int min = INT32_MAX;
	int min_index = -1 ,cost_index = 0;

	for(int i = 0;i<unvisited.size();i++)
	{	
		cost_index = getIndex(unvisited[i]);
		if(costs[cost_index] < min)
		{
			min = costs[cost_index];
			min_index = i;
		}
	}
	return min_index;
}

#endif
