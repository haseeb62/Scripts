#ifndef GRAPH__H
#define GRAPH__H
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <limits>
#include <set>
#include <algorithm>
#include <queue>
#include <list>
#include <sstream>
#include <memory>
#include <queue>
// You may include more libraries.

using namespace std;

class Edge
{
	
public:
	char origin;
	char dest;
	int weight;
	Edge()
	{
		this->origin = '\0';
		this->dest = '\0';
		this->weight = 0;
	}
	Edge(char origin,char dest,int weight)
	{
		this->origin = origin;
		this->dest = dest;
		this->weight = weight;
	}
};

class Graph
{
public:
	vector<vector<shared_ptr<Edge>>> graph;

	int size = 0;
	bool directed;

	Graph(string filename, bool flag);

	void addEdge(char start, char end, int weight, bool flag);
	string display(); // displays the graph
	bool Reachable(char start, char dest);
	int Dijkstra(char start, char dest);
	void DijkstraHelper(char current, vector<int> &costs, vector<char> &visited, vector<char> &unvisited,int);
	string topoSort();
	void DFS(int,int&,vector<bool> &);
	int getIndex(char);
	int getMaxIndex(vector<int>);
	int getMinIndex(vector<int>,vector<char>);
};

#endif
