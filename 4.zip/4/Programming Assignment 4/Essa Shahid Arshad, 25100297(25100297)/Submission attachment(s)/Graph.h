#ifndef GRAPH__H
#define GRAPH__H
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <limits>
#include <set>
#include <algorithm>
#include <queue>
#include <list>
#include <sstream>
#include <memory>
// You may include more libraries.

using namespace std;

class Edge
{
	// You may add more variables and functions in this class
public:
	char origin;
	char dest;
	int weight;
};

class Graph
{
	//
	// You are required to implement the data structures for the graph. Two representations
	// you will be familiar with are adjacency list and adjacency matrix.
	// You can choose to go with any representation you wish.
	//

public:
	//
	// To get you started, we have written the definitions for both adjacency list
	// and matrix. You can uncomment whichever one you like. You are also free to change
	// the data structure to your liking. HOWEVER:
	// MAKE SURE YOU DO NOT CHANGE NAME FROM 'graph' OTHERWISE THE TESTS WILL FAIL.
	//
	// Matrix:
	// vector<vector<shared_ptr<Edge>>> graph;
	//
	// List:
	vector<list<shared_ptr<Edge>>> graph;
	//
	int size = 0;
	Graph(string filename, bool flag);

	void addEdge(char start, char end, int weight, bool flag);
	string display(); // displays the graph
	bool Reachable(char start, char dest);
	int Dijkstra(char start, char dest);
	string topoSort();
	
	//
	// Add any helper function definitions here...
	bool isdirected(const vector<list<shared_ptr<Edge>>>& graph);
	int countEdges(const vector<list<shared_ptr<Edge>>>& graph);
	// function for dfs
	set<char> BFS(char start, char end);
	// bool ReachableHelper(char start, char end,unordered_set<char>& visited);
	void visualizeGraph();
	void printList();
	void printListinTreeStructure();
	// void DFS(char start);
	// void DFS(char start,char visited[],vector<char> &result);
	// vector <char> dfsOFGraph();
	bool DFS(char vertex, char end, bool visited[], vector<char> &result);
	vector<int> DijkstraHelper(char start, char dest);
	void printPriorityQueue(priority_queue<pair<int, char>, vector<pair<int, char>>, greater<pair<int, char>>> pq);
	void printDistanceVector(vector <int> v1,int size);
	void printPathVector(vector <string> v1,char dest);
	void printShortestPath(const vector<string>& path_store, char dest);
	// void DFS_topoSort(int vertex, unordered_map<char,bool> &visited, stack <char> &stack);
	int countUsableNodes();
	vector<list<shared_ptr<Edge>>>  convertToDirectedGraph(vector<list<shared_ptr<Edge>>> &graph);
	void DisplayHelper();
	void printShortestPath(char start, char dest, const vector<string>& path_store);
	vector<int>shortestPathInitialization();
	void dijkstraInitialization(char start, priority_queue<pair<int, char>, vector<pair<int, char>>, greater<pair<int, char>>>& pq, vector<int>& distance, vector<string>& path_store);
	void dijkstraAlgorithm(char start, priority_queue<pair<int, char>, vector<pair<int, char>>, greater<pair<int, char>>>& pq, vector<int>& distance, vector<string>& path_store);
	vector<int> getIndegreeVector();
	vector<char> getZeroIndegreeVertices(vector<int>& indegree);
	void updateIndegree(int vertex, vector<int>& indegree, vector<char>& zeroIndegreeVertices);
	void checkForCycle(vector<int>& indegree);
	void addDirectedEdge(char start, char end, int weight);
	void addUndirectedEdge(char start, char end, int weight);
	int verifyCost(int cost);
	

	







	//
	// We encourage you to make a helper function that can easily translate 
	// a city name to its index.
	// ...
	//
};

#endif
