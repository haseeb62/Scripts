#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <set>
#include <unordered_set>
#include <unordered_map>
#include <map>

Graph::Graph(string filename, bool flag)
{

	ifstream file(filename);

	int numNodes = 0;

	if (file.is_open())
	{
		string line;

		getline(file, line);
		istringstream iss(line);
		char dummyChar;
		iss >> dummyChar >> numNodes;

		graph = vector<list<shared_ptr<Edge>>>(numNodes);

		getline(file, line);

		while (getline(file, line))
		{
			istringstream iss(line);

			char start, end;
			int weight;
			iss >> start >> end >> weight;

			addEdge(start, end, weight, flag);
		}
	}

	file.close();
}

void Graph::addEdge(char start, char end, int weight, bool flag)
{
	if (flag == true)
	{
		addDirectedEdge(start, end, weight);
	}
	else
	{
		addUndirectedEdge(start, end, weight);
	}
}

string Graph::display()
{
	string keep_track = " ";

	set<pair<char, char>> visited;

	set<string> edges;

	if (isdirected(graph) == false)
	{
		stringstream ss;

		for (int i = 0; i < graph.size(); i++)
		{
			for (auto it = graph[i].begin(); it != graph[i].end(); it++)
			{

				ss << "(" << (*it)->origin << "," << (*it)->dest << "," << (*it)->weight << ") ";
				ss << "(" << (*it)->dest << "," << (*it)->origin << "," << (*it)->weight << ") ";
			}
		}

		string str = ss.str();

		int ascii[str.length()];

		string arr[str.length()];

		for (int i = 0; i < str.length(); i++)
		{

			arr[i] = str.substr(i, 7);
			str.erase(i, 7);
		}

		vector<string> edges;

		// copy the strings from the array to the vector
		for (int i = 0; i < str.length(); i++)
		{
			edges.push_back(arr[i]);
		}

		sort(edges.begin(), edges.end());

		edges.erase(unique(edges.begin(), edges.end()), edges.end());

		for (int i = 0; i < edges.size(); i++)
		{
			keep_track += edges[i] + " ";
		}

		string str2 = keep_track;

		return str2;
	}

	else if (isdirected(graph) == true)
	{
		stringstream ss;

		for (int i = 0; i < graph.size(); i++)
		{
			for (auto it = graph[i].begin(); it != graph[i].end(); it++)
			{

				ss << "(" << (*it)->origin << "," << (*it)->dest << "," << (*it)->weight << ") ";
			}
		}

		return ss.str();
	}

	return " ";
}

bool Graph::Reachable(char start, char end)
{

	int cost = Dijkstra(start, end);

	if (cost == -1)
	{
		return false;
	}

	else
	{
		return true;
	}
}

int Graph::Dijkstra(char start, char dest)
{

	vector<int> distances_shortest_path = DijkstraHelper(start, dest);

	int index_path_to_goal_node = dest - 'A';

	int cost = distances_shortest_path[index_path_to_goal_node];

	int verified_cost = verifyCost(cost);

	return verified_cost;
}

vector<int> Graph::DijkstraHelper(char start, char dest)
{

	priority_queue<pair<int, char>, vector<pair<int, char>>, greater<pair<int, char>>> pq;

	vector<int> distance;

	vector<string> path_store;

	dijkstraInitialization(start, pq, distance, path_store);

	dijkstraAlgorithm(start, pq, distance, path_store);

	printShortestPath(start, dest, path_store);

	return distance;
}

string Graph::topoSort()
{
	vector<int> indegree = getIndegreeVector();
	vector<char> zero_indegree_vertices = getZeroIndegreeVertices(indegree);

	string topo_sort = "";

	while (!zero_indegree_vertices.empty())
	{
		char front = zero_indegree_vertices.back();
		zero_indegree_vertices.pop_back();

		topo_sort += front;

		updateIndegree(front - 'A', indegree, zero_indegree_vertices);
	}

	checkForCycle(indegree);

	return topo_sort;
}

bool Graph::isdirected(const vector<list<shared_ptr<Edge>>> &graph)
{
	set<pair<char, char>> visited;

	for (int i = 0; i < graph.size(); i++)
	{
		for (auto it = graph[i].begin(); it != graph[i].end(); it++)
		{
			shared_ptr<Edge> edge = *it;

			if (visited.find({edge->dest, edge->origin}) != visited.end())
			{

				continue;
			}

			visited.insert({edge->origin, edge->dest});
		}
	}

	return visited.size() == countEdges(graph);
}

int Graph::countEdges(const vector<list<shared_ptr<Edge>>> &graph)
{
	int count = 0;

	for (int i = 0; i < graph.size(); i++)
	{
		count += graph[i].size();
	}

	return count;
}

void Graph::printList()
{
	for (int i = 0; i < graph.size(); i++)
	{
		for (auto it = graph[i].begin(); it != graph[i].end(); it++)
		{
			cout << (*it)->origin << " " << (*it)->dest << " " << (*it)->weight << endl;
		}
	}
}

void Graph::printListinTreeStructure()
{
	if (isdirected(graph) == false)
	{
		cout << "UNDIRECTED GRAPH" << endl;
		cout << "----------------" << endl;

		for (int i = 0; i < graph.size(); i++)
		{
			for (auto it = graph[i].begin(); it != graph[i].end(); it++)
			{
				cout << (*it)->origin << " " << (*it)->dest << " " << (*it)->weight << endl;
			}
		}
	}

	else if (isdirected(graph) == true)
	{
		cout << "DIRECTED GRAPH" << endl;
		cout << "--------------" << endl;

		for (int i = 0; i < graph.size(); i++)
		{
			for (auto it = graph[i].begin(); it != graph[i].end(); it++)
			{
				cout << (*it)->origin << " " << (*it)->dest << " " << (*it)->weight << endl;
			}
		}
	}
}

void Graph::printPriorityQueue(priority_queue<pair<int, char>, vector<pair<int, char>>, greater<pair<int, char>>> pq)
{
	while (!pq.empty())
	{
		cout << "Cost: " << pq.top().first << endl;
		cout << "Node " << pq.top().second << endl;
		pq.pop();
	}
}

void Graph::printDistanceVector(vector<int> v1, int size)
{
	for (int i = 0; i < size; i++)
	{
		cout << v1[i] << " ";
	}

	cout << endl;
}

int Graph::countUsableNodes()
{

	int count = 1;

	for (int i = 0; i < graph.size(); i++)
	{
		if (graph[i].size() > 0)
		{
			count++;
		}
	}

	return count;
}

vector<list<shared_ptr<Edge>>> Graph::convertToDirectedGraph(vector<list<shared_ptr<Edge>>> &graph)
{
	vector<list<shared_ptr<Edge>>> directedGraph;

	directedGraph = graph;

	for (int i = 0; i < graph.size(); i++)
	{
		for (auto it = graph[i].begin(); it != graph[i].end(); it++)
		{
			if ((*it)->origin > (*it)->dest)
			{
				directedGraph[i].remove(*it);
			}
		}
	}

	graph = directedGraph;

	return graph;
}

void Graph::printShortestPath(char start, char dest, const vector<string> &path_store)
{
	cout << start << " TO " << dest << " IS: ";

	string path = "";
	for (int i = 0; i < path_store.size(); i++)
	{
		for (int j = 0; j < path_store[i].length(); j++)
		{
			if (path_store[i][j] == dest)
			{
				path = path_store[i];
			}
		}
	}

	if (path.length() <= 1)
	{
		cout << " NO PATH EXISTS" << endl;
	}
	else
	{
		for (int i = 0; i < path.length(); i++)
		{
			cout << " " << path[i] << " ";
		}
		cout << endl;
	}
}

void Graph::dijkstraInitialization(char start, priority_queue<pair<int, char>, vector<pair<int, char>>, greater<pair<int, char>>> &pq, vector<int> &distance, vector<string> &path_store)
{
	pq = priority_queue<pair<int, char>, vector<pair<int, char>>, greater<pair<int, char>>>();

	distance = vector<int>(26, INT_MAX);

	path_store = vector<string>(26, "");

	distance[start - 'A'] = 0;

	path_store[start - 'A'] = start;
	
	pq.push({0, start});
}

void Graph::dijkstraAlgorithm(char start, priority_queue<pair<int, char>, vector<pair<int, char>>, greater<pair<int, char>>> &pq, vector<int> &distances, vector<string> &shortest_paths)
{
	while (!pq.empty())
	{
		int curr_dist = pq.top().first;

		char curr_node = pq.top().second;

		pq.pop();

		for (auto edge : graph[curr_node - 'A'])
		{
			int edge_weight = edge->weight;

			char dest_node = edge->dest;

			int new_dist = distances[curr_node - 'A'] + edge_weight;

			if (new_dist < distances[dest_node - 'A'])
			{
				distances[dest_node - 'A'] = new_dist;

				shortest_paths[dest_node - 'A'] = shortest_paths[curr_node - 'A'] + dest_node;

				pq.push({new_dist, dest_node});
			}
		}
	}
}

vector<int> Graph::getIndegreeVector()
{
	vector<int> indegree(graph.size());

	for (auto i : graph)
	{
		for (auto j : i)
		{
			indegree[j->dest - 'A']++;
		}
	}

	return indegree;
}

vector<char> Graph::getZeroIndegreeVertices(vector<int> &indegree)
{
	vector<char> zero_indegree_vertices;

	for (int i = 0; i < indegree.size(); i++)
	{
		if (indegree[i] == 0)
		{
			zero_indegree_vertices.push_back(i + 'A');
		}
	}

	return zero_indegree_vertices;
}

void Graph::updateIndegree(int vertex, vector<int> &indegree, vector<char> &zero_indegree_vertices)
{
	for (auto neighbour : graph[vertex])
	{
		indegree[neighbour->dest - 'A']--;

		if (indegree[neighbour->dest - 'A'] == 0)
		{
			zero_indegree_vertices.push_back(neighbour->dest - 'A' + 'A');
		}
	}
}

void Graph::checkForCycle(vector<int> &indegree)
{
	if (indegree.size() == 0)
	{
		cout << "CYCLE DETECTED" << endl;
	}
}

void Graph::addDirectedEdge(char start, char end, int weight)
{
	shared_ptr<Edge> edge = make_shared<Edge>();
	edge->origin = start;
	edge->dest = end;
	edge->weight = weight;

	graph[start - 'A'].push_back(edge);
}

void Graph::addUndirectedEdge(char start, char end, int weight)
{
	addDirectedEdge(start, end, weight);
	addDirectedEdge(end, start, weight);
}

int Graph::verifyCost(int cost)
{
	if (cost == INT_MAX)
	{
		cost = -1;

		return cost;
	}

	else
	{
		return cost;
	}
}

#endif