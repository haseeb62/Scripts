#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	// string file_name = filename + ".txt";
	// cout << file_name << endl;

	// Opening the file
	ifstream graph_file(filename);

	// string temp;
	// char temp[] = "";
	string temp;

	int count = 0; // To keep track of when to store n and c.

	// Reading from the file.
	while(getline (graph_file, temp))
	{
		// cout << temp << endl;
		if (count == 0)
		{
			// Storing n.
			string temp_num = temp.substr(2);
			size = stoi(temp_num);

			graph.resize(size);
		}
		else if (count == 1)
		{
			// Storing the c that will never be used.
			string temp_num = temp.substr(2);
			int c = stoi(temp_num);

		}
		else
		{
			// Calling the addEdge function to add the edges to the graph.
			char *temp_num = &temp[4];
			int temp_weight = atoi(temp_num);
			addEdge(temp[0], temp[2], temp_weight, flag);
		}
		count ++;
	}

	graph_file.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	// cout << "Start: " << start << endl;
	// cout << "End: " << end << endl;
	// cout << "Weight: " << weight << endl;

	// Dealing with the case of directed graph. Only one route need be added from start to end.
	if (flag)
	{

		shared_ptr<Edge> temp = make_shared<Edge>();
		temp -> origin = start;
		temp ->dest = end;
		temp->weight = weight;
		graph[int(start) - 65].push_back(temp);
		
	}

	// Dealing with the case of undirected graph. Routes need to be added both ways.
	if (!flag)
	{
		shared_ptr<Edge> temp = make_shared<Edge>();
		temp -> origin = start;
		temp ->dest = end;
		temp->weight = weight;
		graph[int(start) - 65].push_back(temp);

		shared_ptr<Edge> temp2 = make_shared<Edge>();
		temp2->origin = end;
		temp2->dest = start;
		temp2->weight = weight;
		graph[int(end) - 65].push_back(temp2);

	}


	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string result = "";

	// Iterating through the number of unique cities.
	for(int i = 0; i < size; i++)
	{
		char src = char(i + 65); // Storing index.

		// Iterating through the graph. The iterator allows for each graph[i]th element's list to be traversed one by one.
		for (list<shared_ptr<Edge>>::iterator j = graph[i].begin(); j != graph[i].end(); j++)
		{
			// string temp = "(" + char(i + 65) + "," + (*j)->dest + "," + (*j)->weight + ")";

			// Simply formatting the pair and adding to result.
			string temp = "(" + string(1, char(i + 65)) + "," + string(1, (*j)->dest) + "," + to_string((*j)->weight) + ") ";
			result += temp;
		}
	}

	// cout << result << endl;

	return result;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
    bool reachable = false;
    bool direct_path = false;

	// Converting a character to a usabale index by subtracting ASCII code for "A".
    int start_index = int(start) - 65;

    // Checking to see if a direct path exists from start to end and then returning true.
    for (list<shared_ptr<Edge>>::iterator i = graph[start_index].begin(); i != graph[start_index].end(); i++)
    {
        if ((*i)->dest == end)
        {
            reachable = true;
            direct_path = true;
            break;
        }
    }

    // Checking for an indirect path by adding nodes adjacent to start node in queue.
	// Chose to do an iterative method using a queue based on logic from previous assignments.
	// Had attempted to use a recursive approach but could not figure out how to avoid segmentation faults.
    if (!direct_path)
    {

		// Creating a queue to store nodes and an array to store true or false based on whether or not a node has been checked so far.
        queue<char> temp_queue;
        bool checked[size];

		// Initializing all the values to 0.
		for(int i = 0; i < size; i++)
		{
			checked[i] = false;
		}

		// Pushing start onto queue and setting the value of visited corresponding to the start node to true.
        temp_queue.push(start);
        checked[start_index] = true;

		// While the queue is not empty, repeatedly checking if the index at the start of the queue is the destination node. 
		// If the condition is met, the loop will break and reachable will be set to true and returned.
		// Else, a new temporary index of the current (top) node is created and all the nodes adjacent to it are checked for whether or not they have been visited.
		// All nodes that have not been visited are added to the queue and the process repeats until the queue is either empty or a path is found.
        while (!temp_queue.empty())
        {
            char temp = temp_queue.front();
            temp_queue.pop();

			if (temp == end)
            {
                reachable = true;
                break;
            }

            int temp_start = int(temp) - 65;

            for (list<shared_ptr<Edge>>::iterator j = graph[temp_start].begin(); j != graph[temp_start].end(); j++)
            {

                int temp2 = int((*j)->dest) - 65;

                if (!checked[temp2])
                {
                    checked[temp2] = true;
                    temp_queue.push((*j)->dest);
                }
            }
        }
    }

    return reachable;
}

// Previously attempted recursive implementation that kept returning seg faults :'(

// bool Graph::Reachable(char start, char end)
// {
// 	// TODO
// 	bool reachable = false;
// 	bool direct_path, through_path;
// 	direct_path = through_path = false;
// 	// display();
// 	int start_index = int(start) - 65;
// 	for (list<shared_ptr<Edge>>::iterator i = graph[start_index].begin(); i != graph[start_index].end(); i++)
// 	{
// 		if ((*i)->dest == end)
// 		{
// 			reachable = true;
// 			direct_path = true;
// 		}
// 	}
// 	if (!direct_path)
// 	{
// 		for (list<shared_ptr<Edge>>::iterator i = graph[start_index].begin(); i != graph[start_index].end(); i++)
// 		{
// 			reachable = Reachable((*i)->origin, end);
// 		}
// 		// cout << "Direct path found " << start << " " << end << endl;
// 	}
// 	return reachable;
// }



//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//

// Logic understood from youtube and then made to adapt based on previous assignments and also logic understood for netcen lol.
int Graph::Dijkstra(char start, char dest)
{

	int start_index = int(start) - 65; // Storing start index.
	int min_weight = INT_MAX;		   // Setting minimum weight to MAX at the start to account for any plausable weights.

	// Setting the current minimum weight index to the start of the start index's list of edges.
	// list<shared_ptr<Edge>>::iterator min_index = graph[start_index].begin();

	// if (start == dest)
	// {
	// 	// cout << "Destination found" << endl;
	// 	return -1;
	// }

	// Immediately returning -1 if there is no path found.
	if (!Reachable(start, dest))
	{
		return -1;
	}

	// if (Reachable(start, dest))
	// {
	// 	for (list<shared_ptr<Edge>>::iterator i = graph[start_index].begin(); i != graph[start_index].end(); i++)
	// 	{
	// 		if (Reachable((*i)->dest, dest))
	// 		{
	// 			if ((*i)->weight < min_weight)
	// 			{
	// 				min_weight = (*i)->weight;
	// 				min_index = i;
	// 			}
	// 		}
	// 	}
	// 	cout << "Passing recursively" << endl;
	// 	return (min_weight + Dijkstra((*min_index)->dest, dest));
	// }
	// else
	// {
	// 	cout << "No path found" << endl;
	// 	return -1;
	// }

	else
	{
		// Creating and initializing an array for distances for each node and a boolean to store whether or not a node has been visited corresponding to an index.
		int dist[size];
		bool visited[size];

		for(int i = 0; i < size; i++)
		{
			dist[i] = INT_MAX;
			visited[i] = false;
		}

		// Setting distance for the start index to 0 to begin.
		dist[start_index] = 0; 

		// Outer loop to run for the number of cities in the graph.
		for (int i = 0; i < size; i++) 
		{
			
			int min_weight = INT_MAX, min_index;
			// int min_weight = INT_MAX; 
			// list<shared_ptr<Edge>>::iterator min_index;

			// Finding the node with smalled weight which hasn't been visited and setting the the min_index to that location and min_weight to it's associated weight.
			for (int j = 0; j < size; j++) 
			{
				if ((!visited[j]) && (dist[j] <= min_weight)) 
				{
					min_weight = dist[j];
					min_index = j;
				}
			}

			// Marking least weight city as visited.
			visited[min_index] = true; 

			// Iterating through nodes adjacent to the current minimum node and updating their corresponding distances if less than before.
			for (list<shared_ptr<Edge>>::iterator temp = graph[min_index].begin(); temp != graph[min_index].end(); temp++)
			{
				int dest_index = int((*temp)->dest) - 65;
				if ((!visited[dest_index]) && (dist[min_index] != INT_MAX) && ((dist[min_index] + (*temp)->weight) < dist[dest_index])) 
				{
					dist[dest_index] = dist[min_index] + (*temp)->weight;
				}
			}
		}

		// Returning the minimum found distance corresponding to the destination node.
		return dist[int(dest) - 65];
	}
}




// Old attempted implementation of Dijkstra.

// int Graph::Dijkstra(char start, char dest)
// {
// 	// TODO
// 	queue<char> temp_queue, weight_queue, dest_queue;
// 	bool visited[size];
// 	bool reachable = Reachable(start, dest);
// 	int final_weight = 0;
// 	if (!reachable)
// 	{
// 		return -1;
// 	}
// 	else if (reachable)
// 	{
// 		int start_index = int(start) - 65;
// 		for(int i = 0; i < size; i++)
// 		{
// 			visited[i] = false;
// 		}
// 		int start_index = int(start) - 65;
// 		temp_queue.push(start);
// 		visited[start] = true;
// 		for (list<shared_ptr<Edge>>::iterator i = graph[start_index].begin(); i != graph[start_index].end(); i++)
// 		{
// 			if ((*i)->dest == dest)
// 			{
// 				final_weight = (*i)->weight;
// 				break;
// 			}
// 			else
// 			{
// 				int temp_index = int((*i)->dest) - 65;
// 			}
// 		}
// 	}
// 	return final_weight;
// }




// //
// // Implement topological sort on the graph and return the string of the sorted cities
// //


// Logic understood from YouTube and then implemented.
string Graph::topoSort()
{
    // Initialize visited and conn_count arrays to store the visited state of a node (true or false) and the in_degree of the node.
    bool visited[size];     
    int conn_count[size];   
    string result = "";  

	// Initializing all nodes' status to false and in_degree to 0.
    for (int i = 0; i < size; i++)
    {
        visited[i] = false;     
		conn_count[i] = 0;
	}

    // Calculating the in_degree for each node in the graph.
	// Looping theough all the nodes and then updating the conn_count for each destination node found in each start_node's list.
    for (int i = 0; i < size; i++)
    {
        for (list<shared_ptr<Edge>>::iterator j = graph[i].begin(); j != graph[i].end(); j++)
		{
			conn_count[int((*j)->dest - 65)]++; 
		}
    }


	// Looping through each start_point and destination.
	for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            // If the conn_count for the vertex is 0 and it hasn't been visited yet, mark it as visited and add it to the result
            if (conn_count[j] == 0 && visited[j] == false)
            {
                visited[j] = true;
                result += char(j + 65);

                // Decreasing the count of incoming edges for all the vertices adjacent to the visited vertex
                for (list<shared_ptr<Edge>>::iterator k = graph[j].begin(); k != graph[j].end(); k++)
				{
					conn_count[int((*k)->dest - 65)]--;
				}
            }
        }
    }

    return result;
}


// string Graph::topoSort()
// {
// 	//TODO
// 	char visited[size];
// 	for(int i = 0; i < size; i++)
// 	{
// 		visited[i] = ' ';
// 	}
// 	string result = "";
// 	int visited_count = 0;
// 	for (int j = 0; j < size; j++)
// 	{
// 		char temp = char(j + 65);
// 		for (list<shared_ptr<Edge>>::iterator i = graph[j].begin(); i != graph[j].end(); i++ )
// 		{
// 			if (!topoSortHelper((*i)->origin, (*i)->dest, visited))
// 			{
// 				visited[visited_count] = (*i)->origin;
// 				visited_count++;
// 				continue;
// 			}
// 		}
// 	}
// 	for(int i = 0; i < visited_count; i++)
// 	{
// 		result += visited[i];
// 	}
// 	cout << result << endl;
// 	return result;
// }
// bool Graph::topoSortHelper(char start, char end, char visited[])
// {
// 	for(int i = 0; i < size; i++)
// 	{
// 		if(visited[i] == start)
// 		{
// 			return true;
// 		}
// 	}
// 	return false;
// }

#endif

// int main(void)
// {
// 	Graph mygraph1("test1.txt",false); //undirected graphs
// }
