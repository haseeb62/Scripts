#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	string filedata;
	vector<string> filevec;
	ifstream file(filename);
	int citynum,flightnum;

	while(getline(file,filedata))
	{
		if(filedata[0] == 'n') // first line will be number of cities (vertices)
		{
			citynum = stoi(filedata.substr(2));
		}
		else if(filedata[0] == 'c') //second line will be number of flights (edges)
		{
			flightnum = stoi(filedata.substr(2));
		}
		else
		{
			filevec.push_back(filedata); //otherwise push the flight info into a vector
		}
	}

	file.close();

	size = citynum;
	string flight_info;
	int cost;

	graph.resize(citynum);

	for(int i =0;i<filevec.size();i++)
	{
		flight_info = filevec[i]; //get file info containing start,end and cost
		cost = stoi(flight_info.substr(4)); // cost will be the last item in string
		addEdge(flight_info[0],flight_info[2],cost,flag); // 0: start point 2:end point 4:cost 1,3: space char
	}
	
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO

	int index = getIndex(start); //convert start point to integer
	shared_ptr<Edge> new_edge = make_shared<Edge>(start,end,weight); //create an edge from parameters
	graph[index].push_back(new_edge); //stores the edge in list at start index
	
	if(!flag) //if graph is also undirected make an edge of end to start
	{
		index = getIndex(end);
		shared_ptr<Edge> reverse_edge = make_shared<Edge>(end,start,weight);
		graph[index].push_back(reverse_edge);
	}
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string return_string = "";
	for(int i=0;i<graph.size();i++)
	{
		list<shared_ptr<Edge>> temp_list = graph[i];
		list<shared_ptr<Edge>>::iterator j; //list iterator to traverse linked list
		for(j = temp_list.begin(); j!=temp_list.end();j++)
		{
			return_string = return_string + "(" + j->get()->origin + "," + j->get()->dest + "," + to_string(j->get()->weight) + ") ";
		}
	}
	return return_string;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// TODO
	vector<bool> visited(graph.size(),false); // bool vector to check whether an index has been visited during traversal
	vector<char> queue; //queue to hold elements as per BFS
	queue.push_back(start);

	while(!queue.empty())
	{
		char vertex = queue.back();
		queue.pop_back();

		if(vertex == end)
		{
			return true;
		}

		int vertex_index = getIndex(vertex); 
		list<shared_ptr<Edge>> vertex_list = graph[vertex_index]; // traverse the vertices connected to that vertex
		list<shared_ptr<Edge>>::iterator list_it;
		for(list_it = vertex_list.begin(); list_it!=vertex_list.end(); list_it++)
		{
			char temp = list_it->get()->dest;
			int temp_index = getIndex(temp); // get the index of the connected vertices and mark them as visited.
			if(visited[temp_index]==false)
			{
				visited[temp_index]=true;
				queue.push_back(temp); //If vertex was not visited add to queue since it may be a destination
			}
		}
	}

	return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// TODO
	vector<int> distance(graph.size(), INT32_MAX); // distance vector containing shortest distance from node to node. Initialized to maximum possible value
    vector<bool> visited(graph.size(), false); // bool vector to check if vertex has been visited
	vector<char> dijkstra_path(graph.size()); // this vector will contain the entire traversal order of dijkstra
    int start_index = getIndex(start);
	int dest_index = getIndex(dest);
    distance[start_index] = 0; //distance from start always 0
	
    for (int i = 0; i < graph.size() - 1; i++) //traverse entire graph
	{
        
		int smallest_dist = INT32_MAX;
		int smallest_dist_index;

		for (int j = 0; j < graph.size(); j++)
		{
			if (!visited[j] && distance[j] < smallest_dist) //this loop will get the next smallest distance in the start it will be from start index
			{
				smallest_dist = distance[j];
				smallest_dist_index = j;
			}
		}
        visited[smallest_dist_index] = true; //set visited for vertex with smallest distance from start to true

        list<shared_ptr<Edge>> temp_list = graph[smallest_dist_index]; //traverse the list of smallest index
		list<shared_ptr<Edge>>::iterator list_it;
        for (list_it = temp_list.begin(); list_it != temp_list.end(); list_it++)
		{
            char temp = list_it->get()->dest;
			int temp_index = getIndex(temp);
			int curr_dist = distance[smallest_dist_index]+list_it->get()->weight; // calculate distance of each node from start index.

            if (curr_dist < distance[temp_index])
			{
                distance[temp_index] = curr_dist;// Will be updated everytime the vertex is visited until it finds the smallest distance
				dijkstra_path[temp_index] = getChar(smallest_dist_index); //add the vertex with smallest dist to the dijkstra path
			}
        }
    }

	// once the above loop is completed the distance vector will contain shortest distances from start to each reachable endpoint
    if (distance[dest_index] == INT32_MAX) //if no path available then distance[dest_index] won't change
	{
        return -1;
    } 
	else
	{
		string path = "";
		int index = dest_index; // to create the path from end to start by backtracking
		while(index != start_index)
		{
			path+=getChar(index); //keep adding the vertex until start is reached
			index = getIndex(dijkstra_path[index]);
			if(index == start_index)
			{
				path+=start;
			}
		}
		reverse(path.begin(),path.end()); //reverse path start --> dest
		cout << "Path from " << start << " to " << dest <<": " << path << endl;
        return distance[dest_index];
    }
	
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	//TODO
	vector<char> queue; // will hold char with in degree 0
	vector<int> in_degree(graph.size(),0); // vector that will hold the in-degree of each vertex
	string result = "";

	for(int i=0;i<graph.size();i++)
	{
		list<shared_ptr<Edge>> temp_list = graph[i]; //caclulate and set in-degree of each vertex in the graph
		list<shared_ptr<Edge>>::iterator list_it;
		for(list_it = temp_list.begin(); list_it != temp_list.end(); list_it++)
		{
			char dest_vertex = list_it->get()->dest;
			int dest_index = getIndex(dest_vertex);
			in_degree[dest_index]++; // every item in list of a vertex will have an in degree of at least 1.
		}
	}

	for(int i=0;i<in_degree.size();i++)
	{
		if(in_degree[i]==0)
		{
			queue.push_back(i); // get the starting vertex where in degree is 0
		}
	}

	while(!queue.empty())
	{
		int index = queue.back();
		queue.pop_back();

		result+=getChar(index); //result string will hold final sort
		list<shared_ptr<Edge>> temp_list = graph[index]; //next for loop will decrement the in degree of each vertex in a specific list index by virtually removing that index's vertex
		list<shared_ptr<Edge>>::iterator list_it;
		for(list_it = temp_list.begin(); list_it != temp_list.end(); list_it++)
		{
			char dest_vertex = list_it->get()->dest;
			int dest_index = getIndex(dest_vertex);
			in_degree[dest_index]--;
			if(in_degree[dest_index]==0) // if the new in degree after removal becomes 0 add it to queue
			{
				queue.push_back(dest_index);
			}
		}

	}
	return result;
}

int Graph::getIndex(char val) //helper function to convert a character to a integer
{
	return int(val-64)-1;
}

char Graph::getChar(int val) //helper function to convert an integer index to character
{
	return char(val+65);
}


#endif
