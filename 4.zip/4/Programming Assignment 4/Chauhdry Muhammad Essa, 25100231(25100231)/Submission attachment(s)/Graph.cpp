#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <queue>



//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	  ifstream infile(filename);
    if (!infile)
    {
        cerr << "Can't open file " << filename << endl;
        exit(1);
    }
    char n, c;
    int nodes, connections;
    infile >> n >> nodes >> c >> connections;
    size = nodes;
    graph.resize(nodes);

    for (int i = 0; i < connections; ++i)
    {
        char start, end;
        int weight;
        infile >> start >> end >> weight;
        addEdge(start, end, weight, flag);
    }

    infile.close();
}

	


//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	  int startIndex = start - 'A';
    int endIndex = end - 'A';

    auto edge = make_shared<Edge>();
    edge->origin = start;
    edge->dest = end;
    edge->weight = weight;

    graph[startIndex].push_back(edge);

    if (!flag)
    {
        auto reverse_edge = make_shared<Edge>();
        reverse_edge->origin = end;
        reverse_edge->dest = start;
        reverse_edge->weight = weight;
        graph[endIndex].push_back(reverse_edge);
    }
	
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	 stringstream result;

    for (int i = 0; i < size; ++i)
    {
        for (const auto &edge : graph[i])
        {
            result << "(" << edge->origin << "," << edge->dest << "," << edge->weight << ") ";
        }
    }

    return result.str();
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	int startIndex = start - 'A';
    int endIndex = end - 'A';

    vector<bool> visited(size, false);
    queue<int> bfsQueue;

    visited[startIndex] = true;
    bfsQueue.push(startIndex);

    while (!bfsQueue.empty())
    {
        int currentNode = bfsQueue.front();
        bfsQueue.pop();

        if (currentNode == endIndex)
        {
            return true;
        }

        for (list<shared_ptr<Edge>>::iterator it = graph[currentNode].begin(); it != graph[currentNode].end(); ++it)
        {
            int neighborIndex = (*it)->dest - 'A';
            if (!visited[neighborIndex])
            {
                visited[neighborIndex] = true;
                bfsQueue.push(neighborIndex);
            }
        }
    }

    return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	   int startIndex = start - 'A';
    int endIndex = dest - 'A';

    vector<int> dist(size, numeric_limits<int>::max());
    vector<bool> visited(size, false);
    vector<int> prev(size, -1);

    dist[startIndex] = 0;
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push(make_pair(0, startIndex));

    while (!pq.empty())
    {
        int currentNode = pq.top().second;
        pq.pop();

        if (visited[currentNode])
        {
            continue;
        }
        visited[currentNode] = true;

        if (currentNode == endIndex)
        {
            break;
        }

        list<shared_ptr<Edge>>::iterator it;
        for (it = graph[currentNode].begin(); it != graph[currentNode].end(); ++it)
        {
            shared_ptr<Edge> edge = *it;
            int neighborIndex = edge->dest - 'A';
            int newDistance = dist[currentNode] + edge->weight;
            if (newDistance < dist[neighborIndex])
            {
                dist[neighborIndex] = newDistance;
                prev[neighborIndex] = currentNode;
                pq.push(make_pair(newDistance, neighborIndex));
            }
        }
    }

    if (dist[endIndex] == numeric_limits<int>::max())
    {
        return -1;
    }

    vector<char> path;
    for (int node = endIndex; node != -1; node = prev[node])
    {
        path.push_back(static_cast<char>(node + 'A'));
    }
    reverse(path.begin(), path.end());
    cout << "Shortest path: ";
    for (size_t i = 0; i < path.size(); ++i)
    {
        cout << path[i] << " ";
    }
    cout << endl;

    return dist[endIndex];
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//

void dfs(int node, vector<bool> &visited, list<int> &sorted, vector<list<shared_ptr<Edge>>> &graph)
{
    visited[node] = true;

    list<shared_ptr<Edge>>::iterator it;
    for (it = graph[node].begin(); it != graph[node].end(); ++it)
    {
        int neighborIndex = (*it)->dest - 'A';
        if (!visited[neighborIndex])
        {
            dfs(neighborIndex, visited, sorted, graph);
        }
    }
    sorted.push_front(node);
}
string Graph::topoSort()
{
	 vector<bool> visited(size, false);
    list<int> sorted;

    for (int i = 0; i < size; ++i)
    {
        if (!visited[i])
        {
            dfs(i, visited, sorted, graph);
        }
    }

    string sortedString;
    for (list<int>::iterator it = sorted.begin(); it != sorted.end(); ++it)
    {
        sortedString += static_cast<char>(*it + 'A');
    }

    return sortedString;
}

#endif
