#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	ifstream graph_file;
	graph_file.open(filename);
	
	for(int i = 0; i < 2; i++)
	{
		string num;
		getline(graph_file, num);

		if(num[0] == 'n')
		node_no = int(num[2]) - int('0');
		else if(num[0] == 'c' && flag)
		edge_no = int(num[2]) - int('0');
		else if(num[0] == 'c' && !flag)
		edge_no = 2 * (int(num[2]) - int('0'));


	}

	while(!graph_file.eof())
	{
		string edge;
		getline(graph_file, edge);
		if(edge[0] != '\0')
		{
			char origin = edge[0];
			char dest = edge[2];
			int weight = int(edge[4]) - int('0');
			addEdge(origin, dest, weight, flag);
		}
	}
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	if(flag)
	addEddgeHelper(start, end, weight);
	else
	{
		addEddgeHelper(start, end, weight);
		addEddgeHelper(end, start, weight);
	}
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO

	string to_display = "";

	for(int i = 0; i < graph.size(); i++)
	{
		vector<shared_ptr<Edge>> neighbours = graph[i];
		for(int j = 0; j< neighbours.size(); j++)
		{
			to_display += "(" + string(1,neighbours[j] -> origin) + "," + string(1,neighbours[j] -> dest) + "," + to_string(neighbours[j] -> weight) + ") ";
		}
		to_display += "\n";
	}

	return to_display;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// TODO
	vector<char> visited;
	queue<char> traveral;
	traveral.push(start);

	while(!traveral.empty())
	{
		char curr = traveral.front();
		traveral.pop();
		

		if(findIndex(curr) != -1)
		{
			vector<shared_ptr<Edge>> childern = graph[findIndex(curr)];
			if(find(visited.begin(), visited.end(), childern[0] -> origin) == visited.end())
			{
				for(int j = 0; j < childern.size(); j++)
				{
					if(childern[j] -> dest == end)
					return true;
					else
					traveral.push(childern[j] -> dest);
				}
			}
		}
		
		visited.push_back(curr);

	}

	return false;

}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// TODO
	if(!Reachable(start, dest))
	return -1;

	vector<char> visited;
	vector<shared_ptr<Edge>> frontier;
	map<char, int> net_weight;

	stack<shared_ptr<Edge>> path;

	char curr = start;
	int total_cost = 0;
	cout<<curr<<" ";

	while(true)
	{		
		vector<shared_ptr<Edge>> childern = graph[findIndex(curr)];
		net_weight[curr] = total_cost;
		
		for(int i = 0; i < childern.size(); i++)
		{	
			if(find(visited.begin(), visited.end(), childern[i] -> dest) == visited.end())
			{
				frontier.push_back(childern[i]);
			}		
		}
		visited.push_back(curr);
		int min_idx = findMin(frontier, net_weight, visited);
		total_cost = net_weight[frontier[min_idx] -> origin] + frontier[min_idx] -> weight;

		curr = frontier[min_idx] -> dest;

		cout<<curr<<" ";
		
		frontier.erase(frontier.begin() + min_idx);
		if(curr == dest) break;		
	}

	cout<<endl;

	return total_cost;
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	//TODO

	vector<string> all_answer;
	// cout<<graph.size()<<endl;
	for(int i = 0; i < graph.size(); i++)
	{
		all_answer.push_back(topoSortHelper(graph[i][0] -> origin));
	}	
	
	string answer = "";


	for(int i = 0; i<node_no; i++)
	{
		for(int j = 0; j < all_answer.size(); j++)
		{
			if(i < all_answer[j].size())
			{
				if(answer.find(all_answer[j][i]) == string::npos)
				answer += all_answer[j][i];
			}			
		}
	}

	return answer;

}


// HELPER FUNCTIONS ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Graph::addEddgeHelper(char origin, char dest, int weight)
{

	shared_ptr<Edge> new_edge(new Edge(origin, dest, weight));


	for(int i = 0; i < graph.size(); i++)
	{
		if(graph[i].front() -> origin == origin)
		{

			vector<shared_ptr<Edge>> origin_vec = graph[i];
			for(int j = 0; j < origin_vec.size(); j++)
			{

				if(origin_vec[j] -> dest == dest)
				return;
			}
			
			graph[i].push_back(new_edge);
			return;
		}
	}

	vector<shared_ptr<Edge>> new_list;
	new_list.push_back(new_edge);
	graph.push_back(new_list);
}

int Graph::findIndex(char to_find)
{
	for(int i = 0; i < graph.size(); i++)
	{
		if(graph[i].front() -> origin == to_find)
		return i;
	}

	return -1;
}

int Graph::findMin(vector<shared_ptr<Edge>> childern, map<char, int> net_weight , vector<char> visited)
{
	int min_idx = -1;
	int weight = 1000;
	for(int i = 0; i < childern.size(); i++)
	{
		// cout<<net_weight[childern[i] -> origin]<<endl;
		if(weight > childern[i] -> weight + net_weight[childern[i] -> origin] && find(visited.begin(), visited.end(), childern[i] -> dest) == visited.end())
		{
			min_idx = i;
			weight = childern[i] -> weight + net_weight[childern[i] -> origin];
		}
	}

	return min_idx;
}

string Graph::topoSortHelper(char start)
{
	string topological = "";

	vector<char> visited;
	stack<char> topo;
	
	topo.push(start);

	while(!topo.empty())
	{	
		char curr = topo.top();
		topo.pop();

		if(find(visited.begin(), visited.end(), curr) == visited.end())
		{
			topological += curr;
			visited.push_back(curr);
		}

		if(findIndex(curr) != -1)
		{
			vector<shared_ptr<Edge>> childern = graph[findIndex(curr)];
			for(int i = 0; i<childern.size(); i++)
			{
				if(find(visited.begin(), visited.end(), childern[i]->dest) == visited.end())
				topo.push(childern[i] -> dest);
			}
		}
	}

	return topological;
}

#endif
