#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include<unordered_set>
#include<unordered_map>
#include<climits>

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it 
//

Graph::Graph(string filename, bool flag)
{  
    string line;

	ifstream myfile;

	myfile.open(filename);

	getline(myfile, line);

	int a = int(line[2]) - 48;

	graph.resize(a);

	getline(myfile, line);

	while (getline(myfile, line)){

		int cost = int(line[4]) - 48;

		addEdge(line[0], line[2], cost , flag);
	
	}

	// TODO
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//

void Graph::addEdge(char start, char end, int weight, bool flag)
{     
	shared_ptr<Edge> temp(new Edge);

	temp->origin = start;

	temp->dest = end;

	temp->weight = weight;


	int index = int(start) - int('A');

	graph[index].push_back(temp);

	

	if (!flag)
	{
		shared_ptr<Edge> temp(new Edge);

		temp->origin = end;

		temp->dest = start;

		temp->weight = weight;

		int index = int(end) - int('A');

		graph[index].push_back(temp);

	}

	
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{  
    
    string temporary="";

	int graph_size = graph.size();

	for (int i=0; i<graph_size; i++){

    	int list_size = graph[i].size();
     
		for (int j=0; j<list_size; j++){

			
    		string cost = to_string(graph[i].front()->weight);               // it converts the int to string

			string end;

			end += graph[i].front()->dest;    

			string start;

			start += graph[i].front()->origin;

			temporary += "(" + start + "," + end + "," + cost + ") "; 

			graph[i].pop_front();

		}
		
	}

	// TODO
	return temporary;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	
    unordered_set<char> visited_nodes;      
                                       
    visited_nodes.insert(start);                               
       
    char * temp = &start;

    while (temp!=NULL) {

        char curr = *temp;

        temp = NULL;

        if (curr == end) {
            
            return true;
        }

        int index = int(curr) - int('A');
   
     for (auto edge : graph[index]) {                                      // it checks for every node in the list of the index, if that does not exist in the visited nodes, then
                                                                            // then add that in the vector, which shows that this is neither the destination and also it has been visited
            if (visited_nodes.find(edge->dest) == visited_nodes.end()) {

                visited_nodes.insert(edge->dest);                      
                                                             // after adding the edge, it checks if it is equal to the destination or not
                temp = &edge->dest;
            }
        }
    }

    return false;
}



// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// // TODO

	unordered_map<char, int> total_cost;               // we have used this to store the cost against the vertex, just like the dictionary in python

    vector<char> visited_nodes;

    priority_queue<pair<int, char>, vector<pair<int, char>>, greater<pair<int, char>>> temp_queue;

    for (int i = 0; i < graph.size(); i++) {

        char node = char(i + int('A'));                   // initializing the total_cost map/dict with random alaphabets and cost values

        total_cost[node] = 100;
    }

    total_cost[start] = 0;   // initializing the cost equal to zero

    temp_queue.push({0, start});

    while (!temp_queue.empty()) {

        char curr = temp_queue.top().second;   // it is returning the 2nd element if the top object

        temp_queue.pop();

        if (curr == dest) {

            return total_cost[curr];

        }

        for (int i=0; i<visited_nodes.size(); i++){                        // it checks if the vertex exists in the visited_nodes vector

              if (visited_nodes[i] == curr){
                continue;                                       // this checks only one node, the cornor node of the list, in the visited_nodes dictionary
              }

        }

       
        visited_nodes.push_back(curr);

        int index = int(curr) - int('A');                       // this loop searches all the verteices against the visited nodes
 
        for (auto& edge : graph[index]) {
                                                                    // checking if the edge already exists in the visited_nodes vector
            bool checker = false;

            for (int i=0; i<visited_nodes.size(); i++){

                if(visited_nodes[i] == edge->dest){
                    checker = true;
                }
            }

            if (!checker && total_cost[curr] + edge->weight < total_cost[edge->dest]) {                     // if it does not then update its cost and then add it in the vector(visited_nodes)

                total_cost[edge->dest] = total_cost[curr] + edge->weight;

                temp_queue.push({total_cost[edge->dest], edge->dest});
            }
        }
    }

    return -1;

}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	//TODO

    string tempo = "";

    vector<int> inDegree(graph.size());

    for (int i=0; i<graph.size(); i++){     /// populating the vector for every vertex with indegree value equal to zero (0)

        inDegree[i] = 0;

    }

    queue<int> q;

    for (auto edges : graph) {                      ///  this goes through lists of every index in the graph, and for every character it 
                                                    ///  finds, it increment its indegree value by 1
        for (auto edge : edges) {
                   
            int index = int(edge->dest) - int('A');       

            inDegree[index] = inDegree[index] + 1;
        }
    }
    
    for (int i = 0; i < inDegree.size(); i++) {    /// it pushes the vertex with zero(0) in_degree
    
        if (inDegree[i] == 0) {
    
            q.push(i);
        }
    }
    
    while (!q.empty()) {
    
        int curr = q.front();
    
        q.pop();
    
        tempo += char(curr + int('A'));       //  concatenating the char/vertex with zero index
    
        for (auto edge : graph[curr]) {             // searching in the list/(connected vertices) of that vertex and decreasing their indegree value by one(1)
    
            inDegree[int(edge->dest) - int('A')]--;
                                                         // if there exists any other vertex whose indegree turned to zero(0), then add that in the queue
            if (inDegree[int(edge->dest) - int('A')] == 0) {
    
                q.push(int(edge->dest) - int('A'));            // repeat the process till their is no vertex left
            }
        }
    }
    
    if (tempo.length() != graph.size()) {
    
        return "";
    }
                                            // returning the resulting string
    
    return tempo;

	
}

#endif
