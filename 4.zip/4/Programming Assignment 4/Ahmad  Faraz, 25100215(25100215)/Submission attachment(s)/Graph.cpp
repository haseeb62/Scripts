#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	ifstream file(filename);
	string line;

	while (getline(file, line))
	{
		// do smth with line
		if (line[0] == 'n' || line[0] == 'c')
		{
			if (line[0] == 'n')
			{
				string j(1, line[2]); // storing the number of nodes
				size = stoi(j);
			}
			continue; // skipping first two lines
		}
		string s(1, line[4]);
		int i = stoi(s);
		addEdge(line[0], line[2], i, flag);
	}

	file.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	int start_index = cn_to_index(start);
	shared_ptr<Edge> e1(new Edge(start, end, weight));
	graph.resize(26);
	if (graph[start_index].empty())
	{
		graph[start_index].push_back(e1); // simply insert if list was empty. no need to sort
	}
	else
	{
		list<shared_ptr<Edge>>::iterator it;
		// traversing the list
		for (it = graph[start_index].begin(); it != graph[start_index].end(); it++)
		{
			if (e1->dest < (*it)->dest) // this is the position i want to insert at
			{
				break; // getting the iterator at which position insertion would happen to keep alphabetical order maintained
			}
		}
		graph[start_index].insert(it, e1);
	}
	if (flag == false)
	{
		// undirected edge add too!
		int end_index = cn_to_index(end);
		shared_ptr<Edge> e2(new Edge(end, start, weight));
		if (graph[end_index].empty())
		{
			graph[end_index].push_back(e2); // simply insert if list was empty. no need to sort
		}
		else
		{
			list<shared_ptr<Edge>>::iterator it2; // externally declaring an iterator
			// traversing the list
			for (it2 = graph[end_index].begin(); it2 != graph[end_index].end(); it2++)
			{
				if (e2->dest < (*it2)->dest) // this is the position i want to insert at
				{
					break; // getting the iterator at which position insertion would happen to keep alphabetical order maintained
				}
			}
			graph[end_index].insert(it2, e2);
		}
	}
	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string s = "";
	for (int i = 0; i < graph.size(); i++)
	{
		// traverse list in each index and store in string the edge info
		for (auto e : graph[i]) // range based for loop. if graph[i] is empty then no errors
		{
			s = s + "(" + e->origin + "," + e->dest + "," + to_string(e->weight) + ") ";
		}
	}
	return s;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// TODO
	int index = 0;
	char c;
	queue<char> q;
	vector<char> visited;
	q.push(start);

	while (!q.empty())
	{
		index = cn_to_index(q.front()); // index of graph vector obtained
		visited.push_back(q.front());
		q.pop(); // removing front of queue
		list<shared_ptr<Edge>> l = graph[index];
		// traversing this whole list l
		for (auto it = l.begin(); it != l.end(); it++)
		{
			c = (*it)->dest;
			if (in_vec(c, visited) == false && in_queue(c, q) == false)
			{
				// not already in visited vec or q queue
				// so enque it as a child of popped element
				q.push(c);
			}
			if (c == end)
			{
				// path found!!
				return true;
			}
		}
	}

	return false; // true wasn't returned as yet so not reachable
}

bool Graph::in_vec(char letter, vector<char> v)
{
	for (int i = 0; i < v.size(); i++)
	{
		if (v[i] == letter)
		{
			return true;
		}
	}
	return false;
}

bool Graph::in_queue(char letter, queue<char> q)
{
	while (!q.empty())
	{
		if (q.front() == letter)
		{
			return true;
		}
		q.pop();
	}
	return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
    int start_index = cn_to_index(start);
    int dest_index = cn_to_index(dest);
	vector<string> path;
	path.resize(26);
    vector<int> dist_vec(26, INT16_MAX); //populating distance vector
    vector<bool> known(26, false); //type of visited list of booleans
    dist_vec[start_index] = 0; //it is the source vertex
	//min heap type priority queue declared
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq; //first element will be distance(priority) //second element is index no. of char

    //building the min heap/priority queue with all vertices
    for (int i = 0; i < size; i++)
    {
        if (!graph[i].empty())
        {
            pq.push({ dist_vec[i], i });
        }
    }

    while (!pq.empty())
    {
        int min_element = pq.top().second;
        pq.pop(); //remove min called on the min heap
        known[min_element] = true;
        //traversing the list for that particular min element
        list<shared_ptr<Edge>> l = graph[min_element];
        for (auto it = l.begin(); it != l.end(); it++)
        {
            char neighbour = (*it)->dest; //got the connected neighbour
            int n_index = cn_to_index(neighbour); //got the neighbour index
            int n_weight = (*it)->weight; //weight of that edge
            if (known[n_index] == false) //it is outside the cloud
            {
                if ((dist_vec[min_element] + n_weight) < dist_vec[n_index])
                {
                    //decrease the key in min heap/priority queue
                    dist_vec[n_index] = dist_vec[min_element] + n_weight; //dist vec updated
                    //updating min heap too
                    pq.push({ dist_vec[n_index], n_index });
					path[n_index] = path[min_element] + index_to_cn(min_element);
                }
            }
        }
    }

    //now returning answer
    if (dist_vec[dest_index] == INT16_MAX)
    {
		cout<<"Shortest path from "<<index_to_cn(start_index)<<" to "<<index_to_cn(dest_index)<<" : ";
		cout<<"NO PATH EXISTS"<<endl;
        return -1;
    }
    else
    {
		cout<<"Shortest path from "<<index_to_cn(start_index)<<" to "<<index_to_cn(dest_index)<<" : ";
		cout << path[dest_index] << index_to_cn(dest_index)<<endl;
        return dist_vec[dest_index]; //min dist to dest returned
    }
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	vector<char> top_list;
	map<char, int> in_degrees;

	for (int i = 0; i < graph.size(); i++)
	{
		list<shared_ptr<Edge>> l = graph[i];
		if (!l.empty())
		{
			char src_node = l.front()->origin;
			if (in_degrees.find(src_node) == in_degrees.end())
			{
				in_degrees.insert(make_pair(src_node, 0));
			}
			for (auto it = l.begin(); it != l.end(); it++)
			{
				char current_node = (*it)->dest;
				if (in_degrees.find(current_node) == in_degrees.end())
				{
					in_degrees.insert(make_pair(current_node, 1));
				}
				else
				{
					in_degrees[current_node] += 1;
				}
			}
		}
	}

	int total_nodes = graph.size();
	while (total_nodes != 0)
	{
		char zero_ind = '\0'; // letter with zero in degree. initialized with null character
		for (const auto &k : in_degrees)
		{
			if (k.second == 0)
			{
				zero_ind = k.first;
				break;
			}
		}
		if (zero_ind == '\0')
		{
			break; // if no node has zero in degree then break out of the main loop
		}
		int z_index = cn_to_index(zero_ind); // index in AL of z_ind char
		list<shared_ptr<Edge>> z_list = graph[z_index];
		if (z_list.empty())
		{
			top_list.push_back(zero_ind);
		}
		else
		{
			for (auto it = z_list.begin(); it != z_list.end(); it++)
			{
				char curr_vertex = (*it)->dest;
				in_degrees[curr_vertex] -= 1;
			}
			top_list.push_back(zero_ind);
		}
		in_degrees.erase(zero_ind);
		total_nodes--;
	}

	string ans = "";
	for (int i = 0; i < top_list.size(); i++)
	{
		ans = ans + top_list[i];
	}
	return ans;
}

// helper funcs
int Graph::cn_to_index(char cityName)
{
	int ascii_val = static_cast<int>(cityName);
	int index = ascii_val - 65;
	return index;
}
char Graph::index_to_cn(int index)
{
	int ascii_val = index + 65;
	char c = static_cast<char>(ascii_val);
	return c;
}

#endif
