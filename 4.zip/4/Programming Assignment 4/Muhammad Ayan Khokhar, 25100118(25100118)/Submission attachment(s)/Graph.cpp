#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
     ifstream infile(filename);
    int num_vertices;
    infile >> num_vertices;
    graph.resize(num_vertices, vector<shared_ptr<Edge>>(num_vertices, nullptr));
    int num_edges;
    infile >> num_edges;

   for (int i = 0; i < num_edges; ++i) {
    char start, end;
    int weight;
    infile >> start >> end >> weight;

    int start_index = start - 'A';
    int end_index = end - 'A';
    addEdge(start_index, end_index, weight, flag);
}
	
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
 int start_index = start - 'A';
        int end_index = end - 'A';
        graph[start_index][end_index] = make_shared<Edge>(start, end, weight);
        if (flag) {
            graph[end_index][start_index] = make_shared<Edge>(end, start, weight);
        }
}

string Graph::display()
{
      stringstream ss;
    for (int i = 0; i < graph.size(); ++i) {
        ss << (char)('A' + i) << "\t";
    }
    ss << endl;
    for (int i = 0; i < graph.size(); ++i) {
        ss << (char)('A' + i) << "\t";
        for (int j = 0; j < graph[i].size(); ++j) {
            ss << graph[i][j] << "\t";
        }
        ss << endl;
    }
    return ss.str();
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end) {
    int start_index = start - 'A';
    int end_index = end - 'A';
    vector<bool> visited(graph.size(), false);
    dfs(start_index, visited);
    return visited[end_index];
}

void Graph::dfs(int vertex, vector<bool>& visited) {
    visited[vertex] = true;
    for (int i = 0; i < graph.size(); i++) {
        if (graph[vertex][i] != nullptr && !visited[i]) {
            dfs(i, visited);
        }
    }
}




//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::minDistance(int* dist, bool* visited) {
    int minDist = INT_MAX, minIndex = -1;

    for (int i = 0; i < graph.size(); ++i) {
        if (!visited[i] && dist[i] <= minDist) {
            minDist = dist[i];
            minIndex = i;
        }
    }

    return minIndex;
}

int Graph::Dijkstra(char start, char dest)
{   int start_index = start - 'A';
    int dest_index = dest - 'A';
    vector<int> dist(graph.size(), INT_MAX);
    vector<bool> visited(graph.size(), false);
    vector<int> parent(graph.size(), -1);
    dist[start_index] = 0;
    //couldnt complete

}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	vector<int> in_degree(graph.size(), 0);
for (int i = 0; i < graph.size(); ++i) {
for (int j = 0; j < graph[i].size(); ++j) {
if (graph[i][j] != nullptr) {
in_degree[j]++;
}
}
}
queue<int> q;
for (int i = 0; i < graph.size(); ++i) {
    if (in_degree[i] == 0) {
        q.push(i);
    }
}

vector<int> result;
while (!q.empty()) {
    int u = q.front();
    q.pop();
    result.push_back(u);

    for (int v = 0; v < graph.size(); ++v) {
        if (graph[u][v] != nullptr) {
            if (--in_degree[v] == 0) {
                q.push(v);
            }
        }
    }
}

stringstream ss;
for (int i = 0; i < result.size(); ++i) {
    ss << (char)('A' + result[i]);
    if (i != result.size() - 1) {
        ss << "->";
    }
}

return ss.str();

}

#endif