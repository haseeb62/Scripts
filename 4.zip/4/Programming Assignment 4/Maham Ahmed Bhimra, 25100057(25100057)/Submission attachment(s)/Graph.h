#ifndef GRAPH__H
#define GRAPH__H
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <fstream>
#include <limits>
#include <set>
#include <algorithm>
#include <queue>
#include <list>
#include <sstream>
#include <memory>
// You may include more libraries.

using namespace std;

class Edge
{
	// You may add more variables and functions in this class
public:
	char origin;
	char dest;
	int weight;

};

class Graph
{
	//
	// You are required to implement the data structures for the graph.
	//

public:
	// List:
	vector<list<shared_ptr<Edge>>> graph;
	//
	int size = 0;
	
	
	Graph(string filename, bool flag);
	
	void addEdge(char start, char end, int weight, bool flag);
	string display(); // displays the graph
	int getIndex(char city);
	bool Reachable(char start, char dest);
	int Dijkstra(char start, char dest);
	string topoSort();
	//
	// Add any helper function definitions here...
	//
	// We encourage you to make a helper function that can easily translate 
	// a city name to its index.
	// ...
	//
};

#endif