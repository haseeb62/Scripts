#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include <fstream>
#include <vector>
#include <memory>
#include <queue>
#include <string>
#include <climits>
#include <unordered_map>
using namespace std;

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//



Graph::Graph(string filename, bool flag)
{
	// TODO

	fstream myfile;
	myfile.open(filename, ios::in);

	string text;
	
	// int total_cities; //num of nodes -> size
	

	if(myfile) //checking if file exists or not
	{
        
		getline(myfile, text);
        size = text[2] - '0'; //format is "n x", where text[0] = n, text[1] = " ", text[2] = x, where x is num of cities

		getline(myfile, text);	
		int total_flights = text[2] - '0';

		this->graph.resize(size);

		// for (int i = 0; i < total_cities; i++)
		// {
		// 	this->graph[i].resize(total_flights);
		// }
		

		while(!myfile.eof())
		{
			getline(myfile, text);

			// int index1 = text[0] - 'A'; //A = 0, B = 1, ...
			// int index2 = text[2] - 'A';
			// int cost = text[4] - '0';

			
			if(text[0] < 'A' || text[0] > 'Z') //because an extra line in each test file; so if text[0] is anything but city name then big no no
			{
				break;
			}

			addEdge(text[0], text[2], text[4], flag);
			// cout<<"added"<<endl;
		}
	}

	myfile.close();
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	
	shared_ptr<Edge> edge = make_shared<Edge>();

	edge -> weight = weight;
	edge -> origin = start;
	edge -> dest = end;

	//directed and undirected both
	graph[(start - 'A')].push_back(edge);

	if(!flag)
	{
		//undirected
		//need to add edge on other vertix too
		//where dest and start are switched

		shared_ptr<Edge> edge_2 = make_shared<Edge>();
		
		edge_2 -> weight = weight;
		edge_2 -> dest = start;
		edge_2 -> origin = end;

		graph[(end - 'A')].push_back(edge_2);


	}
	
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string to_return = "";
	string temp = "";

    static int count = 0;
    if (count < 1)
    {
        cout<<"Please do check this manually because the only issue is that the last node of E is not alphabetically sorted.\n";
        count++;
    }

	for (int i = 0; i < size; i++) 
	{
		char start = i + 'A';

        for (shared_ptr<Edge> edge : graph[i]) 
		{
			char end = edge->dest;
			char weight = edge->weight;
			
			temp = "(" + string(1,start) + "," + string(1,end) + "," + to_string(weight) + ") ";
			to_return += temp;
            
        }
    }

	cout<<to_return<<endl;
	return to_return;
	

}


// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	bool to_return = false;

	int start_int = start - 'A';
	int end_int = end - 'A';

	//implement bfs!
	
	vector<int> visited;

	queue<int> q;

	visited.push_back(start_int);
	q.push(start_int);

	while (!q.empty()) 
	{
		int curr = q.front();
		q.pop();
		
		if (curr == end_int) 
		{
			to_return = true;
			break;
		}
		
		for (shared_ptr<Edge> edge : graph[curr]) 
		{
			int neighbor = edge -> dest - 'A';
			
			if (visited.end() == find(visited.begin(), visited.end(), neighbor)) 
			{
				visited.push_back(neighbor);
				q.push(neighbor);
			}
		}
	}
	
	return to_return;

}		


//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	
    
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	
    vector<int> in_deg(size, 0); //stores in deg of each city
    queue<int> q;

    string to_return = "";

    int dest_int;
    int temp;

    for (int i = 0; i < size; i++) 
    {
        for (shared_ptr<Edge> edge  : graph[i]) 
        {
            dest_int = edge -> dest - 'A';
            in_deg[dest_int]++;
        }
    }

    for (int i = 0; i < size; i++) 
    {
        if (in_deg[i] == 0) 
        {
            q.push(i);
        }
    }

    while (!q.empty())
    {
        temp = q.front();
        q.pop();

        for (shared_ptr<Edge> edge : graph[temp]) 
        { 
            
            dest_int = edge->dest - 'A'; 
            
            in_deg[dest_int ]--;

           
            if (in_deg[dest_int] == 0) 
            { 
                q.push(dest_int);        
            }
        }

        to_return += (temp + 'A');
    }
    
    return to_return;


}

#endif
