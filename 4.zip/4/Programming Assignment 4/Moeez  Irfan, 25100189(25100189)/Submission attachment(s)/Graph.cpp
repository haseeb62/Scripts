#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	fstream file;               
    file.open(filename, ios::in); 
	
	char flights_cities;
	int val;
	int flights;
	int nodes;
	
	file >> flights_cities >> val;
	nodes = val;
	
	file >> flights_cities >> val;
	flights = val;
	
	graph.resize(nodes);
	for (int i=0;i<nodes;i++)
	{
		graph[i].resize(nodes,NULL);
	}
    
	int cost;
	char start;
	char end;

	for (int i = 0; i < flights; i++)
	{
		file >> start >> end >> cost;
		addEdge(start,end,cost,flag);
	}
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	int index_start, index_end;
	index_start = int(start) - int('A');
	index_end = int(end) - int('A');
	shared_ptr<Edge> node(new Edge(start, end, weight));
	graph[index_start][index_end] = node;
	if (!flag)
	{
		shared_ptr<Edge> node2(new Edge(end, start, weight));
		graph[index_end][index_start] = node2;	
	}
	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string output = "";
	string view = "";
	for (int i=0; i < graph.size();i++)
	{
		for (int j=0; j < graph[i].size(); j++)
		{
			if(graph[i][j] != NULL)
			{
				output += "(";
				output += graph[i][j]->origin;
				output += ",";
				output +=graph[i][j]->dest;
				output += ",";
				output += to_string(graph[i][j]->weight);
				output += ")";
				output += " ";
			}
		}
		if (output != "")
		{
			view += output;
			output = "";
		}
	}
	return view;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// TODO
	int index_start = int(start) - int('A');
	int index_end = int(end) - int('A');
	queue<shared_ptr<Edge>> visited;
	queue<shared_ptr<Edge>> paths;
	bool visit = false;

	if(graph[index_start][index_end] != NULL)
	{
		return true;
	}
	else
	{
		for (int i=0; i<graph[index_start].size(); i++)
		{
			if (graph[index_start][i] != NULL)
			{
				paths.push(graph[index_start][i]);
			}
		}

		while (!paths.empty())
		{
			shared_ptr<Edge> node = paths.front();
			paths.pop();

			int visit_size = visited.size();
			visit = false;
			
			for (int j=0; j<visit_size; j++)
			{
				shared_ptr<Edge> check = visited.front();
				visited.pop();
				visited.push(check);
				if (node == check)
				{
					visit = true;
				}
			}

			if (!visit)
			{
				visited.push(node);
				index_start = int(node->dest) - int('A');
				for (int i=0; i<graph[index_start].size(); i++)
				{
					if (graph[index_start][i] != NULL)
					{
						paths.push(graph[index_start][i]);
					}
				}
			}
		}
		
		while (!visited.empty())
		{
			shared_ptr<Edge> node = visited.front();
			visited.pop();
			if (node->dest == end)
			{
				return true;
			}
		}
		return false;	
	}
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// TODO
	if (!Reachable(start,dest))
	{
		cout << "Route: " << endl;
		return -1;
	}
	
	int graph_size = graph.size();
	vector<int> cost(graph_size, INT32_MAX);
    vector<char> prev(graph_size);
	vector<char> table(graph_size);
	vector<char> visit(graph_size, false);
	int visits = 0;
    
	int src = int(start) - int('A');
	for (int i=0; i<graph_size; i++)
	{
		table[i] = char(int('A') + i);
	}

	cost[src] = 0;
	visit[src] = true;
	visits += 1;
	int min_cost;
	int next_node;

	for (int j=0; j<graph_size; j++)
	{
		if (graph[src][j] != NULL && !visit[j])
		{
			cost[j] = graph[src][j]->weight;
			prev[j] = graph[src][j]->origin;
		}
	}

	while (visits < graph_size)
	{
		min_cost = INT32_MAX;
		for (int i=0; i<graph_size; i++)
		{
			if (!visit[i] && cost[i] != INT32_MAX)
			{
				if (cost[i] < min_cost)
				{
					min_cost = cost[i];
					next_node = i;
				}
			}
		}

		visit[next_node] = true;
		visits++;

		for (int j=0; j<graph_size; j++)
		{
			if (graph[next_node][j] != NULL && !visit[j])
			{
				if (cost[j] > cost[next_node] + graph[next_node][j]->weight)
				{
					cost[j] = cost[next_node] + graph[next_node][j]->weight;
					prev[j] = graph[next_node][j]->origin;
				}
			}
		}
	}
	
	char prev_node;
	int total_cost;
	vector<char> path;
	path.push_back(dest);
	string pathway = "";
	
	for (int i = 0; i < graph_size; i++)
	{
		if (table[i] == dest)
		{
			total_cost = cost[i];
			prev_node = prev[i];
			path.push_back(prev_node);
			break;
		}
	}

	while (true)
	{
		if (prev_node == start)
		{
			break;
		}
		for (int i = 0; i < graph_size; i++)
		{
			if (table[i] == prev_node)
			{
				prev_node = prev[i];
				path.push_back(prev_node);
				break;
			}
		}
	}

	for (int i=0; i<path.size(); i++)
	{
		pathway = path[i] + pathway; 
	}

	cout << "Route: " << pathway << endl;
	
	return total_cost;
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	//TODO
	string output = "";
	int size = graph.size();
	vector<int> in_deg;
	in_deg.resize(size,0);

	vector<vector<shared_ptr<Edge>>> graph_sort(graph);

	for (int i=0; i<graph_sort.size(); i++)
	{
		for (int j=0; j<graph_sort[i].size(); j++)
		{
			if (graph_sort[i][j] != NULL)
			{
				in_deg[j] += 1;
			}
		}
	}

	for (int i=0; i<size; i++)
	{
		for (int k=0; k<size; k++)
		{
			if (in_deg[k] == 0)
			{
				char value;
				value = char(int('A') + k);
				in_deg[k] = -1;
				output += value;
				
				for (int j=0; j<graph_sort[k].size(); j++)
				{
					if (graph_sort[k][j] != NULL)
					{
						in_deg[j] -= 1;
					}
				}
			}
		}
	}
	return output;
}

#endif
