#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"


// Add your constructor code here. It takes the filename and loads the graph from the file, storing into your representation of the graph.  MAKE SURE you use the addEdge function here, and pass the  flag to it too.
Graph::Graph(string filename, bool flag)
{
	// TODO
	fstream file;
    file.open(filename,ios::in);
    if (file.is_open())
    {
		int count =1;
		string line;
		while (true) {
			getline(file, line);  
			if(count==1)
			{
				this->size = stoi(&line[2]);
				for(int i=0; i<  stoi(&line[2]); i++)
				{
					vector<shared_ptr<Edge>> row;
					for(int j=0; j<stoi(&line[2]); j++)
					{
						row.push_back(NULL);

					}
					graph.push_back(row);
				}
			}
			if (file.fail()) {break;}
			if(count>=3)
			{
				addEdge(line[0], line[2], stoi(&line[4]), flag);
			}
			cout <<endl;
			count++;
		}
		cout << "NEXT.....";
        file.close();
    }
    else
    {
            cout << " some error occured - can not Read "; 
    }
	cout <<endl;
	for(int i=0; i<graph.size(); i++) 
	{
		for(int j=0; j<graph[i].size(); j++) 
		{  	
			if(graph[i][j]) {   cout << graph[i][j]->weight << "  "; 	}  else {   cout  << " x ";}
		}
		cout << endl; 		
	}
	
	
}

// Adds an edge to the graph. Useful when loading the graph from file.  The flag determines whether the edges will be added according to a directed or undirected graph.
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	cout << start << end << weight << flag << "  ";
	shared_ptr<Edge> thisedge(new Edge(start,end,weight), default_delete<Edge>());
	if(flag) //directed - onesided
	{
		graph[mapper(start)][mapper(end)] = thisedge;
	}
	else  //undirected - bothways
	{
		graph[mapper(start)][mapper(end)] = thisedge;
		graph[mapper(end)][mapper(start)] = shared_ptr<Edge> (new Edge(end,start,weight), default_delete<Edge>());
	}
	// cout <<endl;
	for(int i=0; i<graph.size(); i++) 
	{
		for(int j=0; j<graph[i].size(); j++) 
		{  	
			if(!graph[i][j]) {graph[i][j] = shared_ptr<Edge> (new Edge(' ',' ',0), default_delete<Edge>());}
			// cout << graph[i][j];
		}
		// cout << endl; 		
	}
	return;
}

int Graph::mapper(char city)
{
	return city-65;  //cities are capital letters so it maps them to their ascii values - 65(indexing from 0.....25) since 26 letters in alphabet
}


// Returns the display of the graph as a string. Make sure you follow the same output as given in the manual.
string Graph::display()
{
	string out ="";
	for(int i=0; i<graph.size(); i++) 
	{
		for(int j=0; j<graph[i].size(); j++) 
		{  	
			// if(graph[i][j]) {   cout << graph[i][j]->weight << "  "; 	}    else   {    cout << " x ";   }	
			if(graph[i][j]->weight!=0) {   out +="(" ;out+= graph[i][j]->origin ; out+=","; out+= graph[i][j]->dest ;  out+=",";  out+= to_string(graph[i][j]->weight) ; out+=") ";  } 
		}
		// cout << endl; 		
	}
	// cout <<endl;
	return out;
	
}

// Returns whether the destination city is reachable from the origin city or not.
bool Graph::Reachable(char start, char end) //test on undirected graphs - use DFS(recursive) 
{
	cout <<endl;
	// cout << " ME is " << start  << "  " ;
	bool flag = false;
	vector<char> visited;
	visited.push_back(start);
	if(graph[mapper(start)][mapper(end)]->weight!=0) 
	{
		// cout << "  direct edge....." ;
		return true;   //if direct edge
	}  
	for(int j=0; j<graph[mapper(start)].size(); j++) 
	{  	
		if(graph[mapper(start)][j]->weight!=0) 
		{   
			// cout  << graph[mapper(start)][j]->dest << "  " << graph[mapper(start)][j]->weight << "   ";     //prints neighbours
			flag = dfsfindpath (graph[mapper(start)][j]->dest ,end, visited);
			if(flag) {return true;}  else {continue;}
		}    
	}
	// cout << " not connected ";
	return false;
}


 bool Graph::dfsfindpath( char start,char end, vector<char> visited)
{
	bool flag = false;
	// cout << " I am "  <<start << "  " ;

	if(find(visited.begin(), visited.end(), start) != visited.end())
	{
		// cout << "ret " << start << "  ";
		return false;
	}
	visited.push_back(start);
	if(graph[mapper(start)][mapper(end)]->weight!=0) 
	{
		// cout << graph[mapper(start)][mapper(end)]->dest <<" direct edge....." ;    
		return true;     //if direct edge
	}  
	for(int j=0; j<graph[mapper(start)].size(); j++) 
	{  	
		if(graph[mapper(start)][j]->weight!=0) 
		{   
			// cout << " here " <<  graph[mapper(start)][j]->dest << "  " << graph[mapper(start)][j]->weight << "  ";     //prints neighbours
			if(find(visited.begin(), visited.end(), graph[mapper(start)][j]->dest) != visited.end()) 	{   continue;  }
			flag = dfsfindpath (graph[mapper(start)][j]->dest ,end, visited);
			if(flag) {return true;}  else {continue;}
		}    
	}
	return false;
}


// Returns the weight of shortest path between origin and destination cities ... Return -1 if no path exists.
int Graph::Dijkstra(char start, char dest) //shortest path algorithm  - on undirected graphs
{
	if (Reachable(start, dest))
	{   //find shortest path costs to all nodes from start, return the shortest path cost for start->dest 
		vector<int> distance;
		for(int i=0; i<size; i++) 
		{
			distance.push_back(INT_MAX);  				  //initialize all distances to inf
			if (i == mapper(start)) {distance[i] = 0;}    //distance to itself is zero ...  
		} 
		vector<char> visited;
		priority_queue<char> frontier ;
		frontier.push(start) ;

		while(!frontier.empty())
		{
			char minima = frontier.top();
			int minvertex = mapper(frontier.top());
			frontier.pop() ;
			// cout << minima << "  ";

			for(int i=0; i<size; i++)
			{
					if (graph[minvertex][i] ->weight == 0)	{ continue ;}  //no edge exists
					if( distance[minvertex] + graph[minvertex][i] ->weight < distance[i])  //edge exists and new distance is less than original distance
					{
						distance[i] = distance[minvertex] + graph[minvertex][i] ->weight ;
						frontier.push(char(i+65));
					}		
			}
			visited.push_back(minima); //create and pass edges to visited, check if edge has been visited OR NOT??
		}
		// for(int i=0; i<visited.size();i++){cout << visited[i];}  //prints visited nodes in order of visitation
		return distance[mapper(dest)] ;  
	}
	return -1;
}


// Implement topological sort on the graph and return the string of the sorted cities
string Graph::topoSort()  //DAG provided - directed graph w/o cycles
{
	vector<char> visited;
	vector<vector<shared_ptr<Edge>>> temp = graph;
	string ans="";
	for(int h=0; h<this->size; h++)      //repeats for all nodes
	{
		char chars = getzeroindeg(visited,temp);   //indegree = 0 means if no ingoing edge to A then first column = 0s ONLY
		ans+=chars;  
		visited.push_back(chars);
		for(int i=0; i<temp.size(); i++) 
		{
			for( int j=0; j<temp[i].size(); j++) 
			{  	
				if(temp[mapper(chars)][i] && temp[mapper(chars)][i]->weight!=0) 
				{  temp[mapper(chars)][i]->weight =0; }  //sets that character's outgoing edges to 0
			}	
		}
	}
	cout << ans << endl; 
	return ans;
}


char Graph::getzeroindeg(vector<char> visited, vector<vector<shared_ptr<Edge>>> temp)
{
	vector<char> ans;   //stores characters with 0 incoming edges
	vector<int> indeg;  //stores index of vertices with 0 incoming edges
	int index;
	bool flag = 1;
	for(int i=0; i<temp.size(); i++) 
	{
		flag=1;
		for( int j=0; j<temp[i].size(); j++) 
		{  	
			if(temp[j][i] && temp[j][i]->weight!=0) {flag =0; } 
		}	
		if(flag){index = i; }  //means no incoming edge (hence 0 indegree)
		if(find(indeg.begin(), indeg.end(), index) == indeg.end()) { indeg.push_back(index);}
	}
	for(int i=0; i <indeg.size(); i++) 
	{  ans.push_back(static_cast<char>(indeg[i]+65)) ; 	}   //adds those characters at respective indexes to our vector
	
	for(int i=0; i<ans.size(); i++)
	{
		if(find(visited.begin(), visited.end(), ans[i]) == visited.end()) 
		{ return ans[i];}    //returns the character with 0 indegree, that isnt already visited
	}

}

#endif
