#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"
#include<queue>
#include<tuple>

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	ifstream file(filename);

	//reading from the file
	int total_vertices;
	string s;
	file >> s >> total_vertices;
	
	graph.resize(total_vertices);
	size = total_vertices;

	string temp;
	getline(file, temp);

	int i = 0;
	while (getline(file, temp)){

		if (temp[0] != 'A' && i == 0){
			i++;
			continue;
		}
			
		
		addEdge(temp[0], temp[2], static_cast<int>(temp[4] - '0'), flag);
	}
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//

void Graph::addEdge(char start, char end, int weight, bool flag)
{
	
	shared_ptr<Edge> temp(new Edge);	
	temp->dest = end;
	temp->origin = start;
	temp->weight = weight;	
	
	shared_ptr<Edge> temp1(new Edge);
	temp1->dest = start;
	temp1->origin = end;
	temp1->weight = weight;
	//incase of a directed graph
	if (flag){
		int index = static_cast<int>(start - 'A');
		graph[index].push_back(temp); 

		//sorting
		// for (int i = 0; i < graph[index].size(); i++){

		// 	for (int j = 0; j < graph[index].size() - 1; j++){

		// 		graph[index][0].
		// 	}
		// }
	}

	else{

		//incae of undirected
		int start_index = static_cast<int>(start - 'A');
		int end_index = static_cast<int>(end - 'A');

		graph[start_index].push_back(temp);
		graph[end_index].push_back(temp1);

	}

	//sorting

	return;
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	string ans = "";
	for (int i = 0; i < graph.size(); i++){

		int list_length = graph[i].size();
		for (int j = 0; j < list_length; j++){

			shared_ptr<Edge> temp;
			temp = graph[i].front();
			graph[i].pop_front();
			ans = ans + "(" + temp->origin + "," + temp->dest + "," + static_cast<char>(temp->weight + '0') + ")" + " ";
		}
	}

	return ans;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	
	// run BFS, to see if reachable
	int n = 0;
	bool visited [size] = {false};

	queue<char> q;
	q.push(start);
	char c = q.front();
	visited[static_cast<int>(c - 'A')] = true;
	
	int length = graph[static_cast<int>(c - 'A')].size();
	for (int i = 0; i < length; i++){
		int index = static_cast<int>(c - 'A');
		// cout << "X : " << graph[index].front()->dest << endl;
		if (graph[index].front()->dest == end)
			return true;

		q.push(graph[static_cast<int>(c - 'A')].front()->dest);
		shared_ptr<Edge> temp = graph[static_cast<int>(c - 'A')].front();
		graph[static_cast<int>(c - 'A')].pop_front();
		graph[static_cast<int>(c - 'A')].push_back(temp);
	}
	// int x = q.size();
	// for (int i = 0; i < x; i++){
	// 	cout << q.front() << " ";
	// 	q.pop();
	// }
	q.pop();
	
	//now doing this for every node, as long as queue is not empty
	
	while (q.size()){
		
		c = q.front();
		visited[static_cast<int>(c - 'A')] = true;
		 
		length = graph[static_cast<int>(c - 'A')].size();
		for (int i = 0; i < length; i++){
			n++;
			if (n > 100)
				return false;
			// cout <<
			 graph[static_cast<int>(c - 'A')].front()->dest;
			if (graph[static_cast<int>(c - 'A')].front()->dest == end)
				return true;


			int x = static_cast<int>(graph[static_cast<int>(c - 'A')].front()->dest - 'A');
			// cout << x << endl;
			//check if node has already been visited
			// if (visited[static_cast<int>(graph[static_cast<int>(c - 'A')].front()->dest - 'A')]){
			// 	q.pop();
			// 	continue;
			// }

			q.push(graph[static_cast<int>(c - 'A')].front()->dest);
			shared_ptr<Edge> temp = graph[static_cast<int>(c - 'A')].front();
			graph[static_cast<int>(c - 'A')].pop_front();
			graph[static_cast<int>(c - 'A')].push_back(temp);
		} 
		q.pop();
	}
	
	return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// TODO
	if (!Reachable(start, dest)){
		cout << "No Path Exists" << endl;
		return -1;
	}

	// tuple<int, char> tup;
	priority_queue<tuple<int, char, char>> q; //weight, node, parent
	string ans = "";
	int total_weight = 0;
	char parent[size] = {'Z'};
	bool visited[size] = {false};
	shared_ptr<Edge> temp;
	//when priority has 1st element as dest, the weight in that tuple is to be returned
	//return when the char in priority queue == dest
	//make an arr of char where index is node, and value is its parent
	//make a bool visited arr as well
	
	//expand the start node
	visited[static_cast<int>(start - 'A')] = true;

	//add all the adjacent nodes to the priority queue(along with their weights)
	int length = graph[static_cast<int>(start - 'A')].size();
	// cout << length;
	for (int i = 0; i < length; i++){

		//multiply with -1 so that lowest dist is stored at the front in the priority queue
		int w = -1 * graph[static_cast<int>(start - 'A')].front()->weight;
		// cout << w << endl;
		char c = graph[static_cast<int>(start - 'A')].front()->dest;
		q.push(make_tuple(w, c, start));
		temp = graph[static_cast<int>(start - 'A')].front();
		graph[static_cast<int>(start - 'A')].pop_front();
		graph[static_cast<int>(start - 'A')].push_back(temp);
	}

	// for (int i = 0; i < 3; i++){

	// 	cout << "W : " << get<0>(q.top()) << " N : " << get<1>(q.top()) << " P : " << get<2>(q.top()) << endl;
	// 	q.pop();
		
	// }
	// return 0;
	

	while (true){
	
		//expand the node in priority queue, if it has not been visited
		//add its adjacent nodes in the priority queue(if they have not been visited)
		char frontier = get<1>(q.top());
		int weight = get<0>(q.top());
		char p = get<2>(q.top());
		q.pop();
		if (!visited[static_cast<int>(frontier - 'A')]){

			visited[static_cast<int>(frontier - 'A')] = true;
			parent[static_cast<int>(frontier - 'A')] = p; //???
			
			//check if the current node is the dest
			if (frontier == dest){
				
				total_weight = weight;
				break;
			}

			//add its adjacent nodes to the priority queue
			int length = graph[static_cast<int>(frontier - 'A')].size();
			for (int i = 0; i < length; i++){

				int w = -1 * graph[static_cast<int>(frontier - 'A')].front()->weight + weight;
				char c = graph[static_cast<int>(frontier - 'A')].front()->dest;
				char par = graph[static_cast<int>(frontier - 'A')].front()->origin;
				q.push(make_tuple(w, c, par));
				temp = graph[static_cast<int>(frontier - 'A')].front();
				graph[static_cast<int>(frontier - 'A')].pop_front();
				graph[static_cast<int>(frontier - 'A')].push_back(temp); 

			}
		}
	}

	//print the path
	char temp_dest = dest;
	ans = ans + dest;
	for (int i = 0; i < size; i++){

		if (temp_dest == start){

			ans = ans + start;
			break;
		}

		ans = ans + parent[static_cast<int>(temp_dest - 'A')];
		temp_dest = parent[static_cast<int>(temp_dest - 'A')];
		
	}

	//reverse
	string new_ans = "";
	for (int i = ans.length() - 2; i >= 0; i--){

		new_ans = new_ans + ans[i];
	}
	cout << new_ans << endl;
	// cout << total_weight;
	return -1 * total_weight;

}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	
	string ans = "";
	bool arr[size] = {false};
	//implement using in degree method

	//calculate indegree of every node

	for (int k = 0; k < size; k++){
		vector<int> v = indegree();
		
		
		// for (int i = 0; i < v.size(); i++){
		// 	cout << v[i] << " ";
		// }	cout << endl;

		//remove the vertex with indegree 0
		int i = 0;
		// cout << "S : " << v.size() << endl;
		for (i = 0; i < v.size(); i++){

			if (v[i] == 0 && !arr[i]){
				
				
				ans = ans + static_cast<char>(i + 'A');
				arr[i] = true;
				break;
			}
		}
		int length = graph[i].size();
		for (int j = 0; j < length; j++){

			graph[i].pop_front();
		}

	}
	//repeat
	// v = indegree();
	
	// for (int i = 0; i < v.size(); i++){
	// cout << v[i] << endl;
	// }
	// cout << ans << endl;
	return ans;
}

vector<int> Graph::indegree(){
	
	//initializing a vector
	vector<int> v(size);
	char c = 'A';
	while (static_cast<int>(c - 'A') < size){

		for (int i = 0; i < size; i++){

			int length = graph[i].size();
			for (int j = 0; j < length; j++){

				if (graph[i].front()->dest == c){

					v[static_cast<int>(c - 'A')]++;
				}

				if (graph[i].size()){
					shared_ptr<Edge> temp = graph[i].front();
					graph[i].pop_front();
					graph[i].push_back(temp);
					
				}
			}
		}
		c++;
	}
	return v;
}

#endif
