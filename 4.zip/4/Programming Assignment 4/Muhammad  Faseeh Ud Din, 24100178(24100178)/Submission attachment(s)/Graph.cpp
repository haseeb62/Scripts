#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	ifstream file(filename);
	string line;
	int n, c;

	if (file.is_open())
	{
		getline(file, line);
		sscanf(line.c_str(), "n %d", &n);
		getline(file, line);
		sscanf(line.c_str(), "c %d", &c);

		// initialising the graph
		graph = vector<list<shared_ptr<Edge>>>(26);

		while (getline(file, line))
		{
			char start, end;
			int weight;
			sscanf(line.c_str(), "%c %c %d", &start, &end, &weight);
			addEdge(start, end, weight, flag);
		}
		file.close();
	}
	else
	{
		cout << "Unable to open the file." << endl;
	}
}

//helper
int Graph::getIndex(char city)
{
	return city - 'A';
	//following concept of 0 indexing, and will have free space, i.e A-Z are possible indexes and and the size of the graph will be 26
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	auto newEdge = make_shared<Edge>();
	newEdge->origin = start;
	newEdge->dest = end;
	newEdge->weight = weight;

	// cout << "Adding: " << start << " " << end << " " << weight << endl;
	if (graph[start - 'A'].size() == 0)
	{
		this->size++;
	}
	graph[start - 'A'].push_back(newEdge);

	if (!flag)
	{
		auto newEdge2 = make_shared<Edge>();
		newEdge2->origin = end;
		newEdge2->dest = start;
		newEdge2->weight = weight;

		if (graph[end - 'A'].size() == 0)
		{
			this->size++;
		}
		graph[end - 'A'].push_back(newEdge2);

		// cout << "Adding: " << end << " " << start << " " << weight << endl;
	}
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// loop through the vector, then the list, and append to string
	string output = "";
	for (int i = 0; i < 26; i++)
	{
		// now we loop the internal lists
		if (graph[i].size() != 0)
		{
			for (auto it = graph[i].begin(); it != graph[i].end(); it++)
			{
				output += "(";
				output += (*it)->origin;
				output += ",";
				output += (*it)->dest;
				output += ",";
				output += to_string((*it)->weight);
				output += ") ";
			}
			output += "\n";
		}
	}
	return output;
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// implementing dfs using stack, but using cpp queue
	// we will be implemeting using queue as stack
	set<char> visited;
	queue<char> toVisit;

	toVisit.push(start);

	while (!toVisit.empty())
	{
		char curr = toVisit.front();
		toVisit.pop();

		// If already visited this node, miss
		if (visited.count(curr) > 0)
		{
			continue;
		}

		// If this is the destination node, return true
		if (curr == end)
		{
			return true;
		}

		// Mark the current node as visited
		visited.insert(curr);

		// Add all unvisited neighbors of the current node to the stack
		for (const auto &edge : graph[curr - 'A'])
		{
			if (visited.count(edge->dest) == 0)
			{
				toVisit.push(edge->dest);
			}
		}
	}

	// If all reachable nodes are visited and destination isnt found, then the destination is not reachable from the starting node
	return false;
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest) {
    vector<int> dist(size, numeric_limits<int>::max());
    vector<bool> visited(size, false);
    vector<char> prev(size, '\0');

    dist[getIndex(start)] = 0;

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push(make_pair(0, getIndex(start)));

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        if (visited[u]) continue;
        visited[u] = true;

        for (const auto& edge : graph[u]) {
            int v = getIndex(edge->dest);
            int weight = edge->weight;

            if (dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight;
                prev[v] = u + 'A';
                pq.push(make_pair(dist[v], v));
            }
        }
    }

    if (dist[getIndex(dest)] == numeric_limits<int>::max()) {
        // cout << "No path exists between " << start << " and " << dest << "." << endl;
        return -1;
    } else {
        string path;
        for (char curr = dest; curr != '\0'; curr = prev[getIndex(curr)]) {
            path += curr;
        }
        reverse(path.begin(), path.end());
        // cout << "Shortest path: " << path << endl;
        return dist[getIndex(dest)];
    }
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	vector<bool> visited(size, false);
    list<int> result;
    for (int i = 0; i < size; ++i) {
        if (!visited[i]) {
            topoSortUtil(i, visited, result, graph);
        }
    }

    string sortedCities;
    for (const auto &cityIndex : result) {
        sortedCities += (char)(cityIndex + 'A');
    }

    return sortedCities;
}

void Graph::topoSortUtil(int v, vector<bool> &visited, list<int> &result, vector<list<shared_ptr<Edge>>> &graph) {
    visited[v] = true;
    for (const auto &edge : graph[v]) {
        int neighbor = edge->dest - 'A';
        if (!visited[neighbor]) {
            topoSortUtil(neighbor, visited, result, graph);
        }
    }
    result.push_front(v);
}


#endif
