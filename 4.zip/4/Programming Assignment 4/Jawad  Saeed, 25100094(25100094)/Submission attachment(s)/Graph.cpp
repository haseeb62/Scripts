#ifndef GRAPH__CPP
#define GRAPH__CPP
#include "Graph.h"

//
// Add your constructor code here. It takes the filename and loads
// the graph from the file, storing into your representation of the
// graph. MAKE SURE you use the addEdge function here, and pass the 
// flag to it too.
//
Graph::Graph(string filename, bool flag)
{
	// TODO
	int cities;
	if(!flag)
	{
		ifstream datafile; //Open the file
		datafile.open(filename);
		char cities; //Read the first line char 
		int num_of_cities; //Read the first line int
		datafile >> cities;
		datafile >> num_of_cities;
		this->graph = vector<list<shared_ptr<Edge>>>(num_of_cities); //Initialize the graph with the number of cities since that is essentially the number of vertices
		char paths; //Read the second line char
		int num_of_paths; //Read the second line int
		datafile >> paths;
		datafile >> num_of_paths;
		for(int i = 0; i < num_of_paths; i++) //Loop through the number of paths which is essentially how many edges this graph will have
		{
			char start; 
			char end;
			int weight;
			datafile >> start; //Read the start city
			datafile >> end; //Read the end city
			datafile >> weight; //Read the weight
			this->addEdge(start, end, weight, flag); //Add the edge to the graph
		}
		datafile.close(); //Close the file
	}
	else //Same as above except this is for a directed graph
	{
		ifstream datafile;
		datafile.open(filename);
		char cities;
		int num_of_cities;
		datafile >> cities;
		datafile >> num_of_cities;
		this->graph = vector<list<shared_ptr<Edge>>>(num_of_cities);
		char paths;
		int num_of_paths;
		datafile >> paths;
		datafile >> num_of_paths;
		for(int i = 0; i < num_of_paths; i++)
		{
			char start;
			char end;
			int weight;
			datafile >> start;
			datafile >> end;
			datafile >> weight;
			//cout << start << " " << end << " " << weight << endl;
			this->addEdge(start, end, weight, flag);
		}
		datafile.close();
	}
}

int Graph::index(char city, char offset) //Helper function to get the index of the city where offset is essentially the first city in the graph and the assumption is that all the cities are in order greater than the first city
{
	return city - offset;
}

//
// Adds an edge to the graph. Useful when loading the graph from file.
// The flag determines whether the edges will be added according to a
// directed or undirected graph.
//
void Graph::addEdge(char start, char end, int weight, bool flag)
{
	// TODO
	shared_ptr<Edge> edge1 = make_shared<Edge>(); //Create two edges and start with a directed implementation and use flag to see if edge 2 needs to be used
	shared_ptr<Edge> edge2 = make_shared<Edge>(); //If flag is false then edge 2 will be used
	edge1->origin = start; //Set the origin, destination, and weight for edge1
	edge1->dest = end;
	edge1->weight = weight;
	char offset;
	if(this->graph[0].empty() == true)
	{
		this->graph[0].push_back(edge1);
		offset = start;
		if(!flag)
		{
			edge2->origin = end;
			edge2->dest = start;
			edge2->weight = weight;
			this->graph[this->index(end,offset)].push_back(edge2);
		}
	}
	else
	{
		offset = this->graph[0].front()->origin;
		this->graph[this->index(start,offset)].push_back(edge1); //Push edge1 into the graph
		if(!flag) //If flag is false then edge2 will be used in which case the origin and destination will be switched to cater for an undirected graph
		{
			edge2->origin = end;
			edge2->dest = start;
			edge2->weight = weight;
			this->graph[this->index(end,offset)].push_back(edge2);
		}
		else //If flag is true then edge2 will not be used and we will simply return
		{
			return;
		}
		return;
	}
}

//
// Returns the display of the graph as a string. Make sure
// you follow the same output as given in the manual.
//
string Graph::display()
{
	// TODO
	int vector_size = this->graph.size(); //Get the size of the graph
	string output = ""; //Initialize the output string
	for(int i = 0; i < this->graph.size(); i++) //Iterate over the elements in the adjacency list
	{
	   for(int j = 0; j < this->graph[i].size(); j++) //Iterate over the edges in each list in the adjacency list
	   {
		   shared_ptr<Edge> edge = this->graph[i].front(); //Get the front edge
		   this->graph[i].pop_front(); //Pop the front edge
		   this->graph[i].push_back(edge); //Push the edge back into the list. Initially the order is skewed but at the end when the last edge comes to the front and is pushed back the same inital order is restored
		   output += "(" + string(1, edge->origin) + "," + string(1, edge->dest) + "," + to_string(edge->weight) + ") "; //Add the edge to the output string
	   }
    }
	return output; //Return the output string
}

// Returns whether the destination city is reachable from the
// origin city or not.
//
bool Graph::Reachable(char start, char end)
{
	// TODO
	char offset = this->graph[0].front()->origin; //Get the offset
	queue<shared_ptr<Edge>> q; //Using BFS to check if the destination is reachable from the origin using a queue of edges
    vector<bool> visited(this->graph.size(), false); //Initialize a vector of bools to keep track of which vertices have been visited with initially all of them set to false since none have been visited
	q.push(this->graph[this->index(start,offset)].front()); //Push the first edge into the queue
    while (!q.empty()) //Keep running until the queue is empty
    {
        shared_ptr<Edge> curr = q.front(); //Get the front edge
        q.pop(); //Pop the front edge so that the next edge can be processed
         
        if (curr->dest == end) //If the destination is found then return true
        {
            return true;
        }
		else
		{
			visited[this->index(curr->dest,offset)] = true; //Mark the current vertex as visited
			for(int i = 0; i < this->graph[this->index(curr->dest,offset)].size(); i++) //Iterate over the edges in the list of the current vertex
			{
				shared_ptr<Edge> edge = this->graph[this->index(curr->dest,offset)].front(); //Get the front edge
				this->graph[this->index(curr->dest,offset)].pop_front(); //Same strategy as above of popping the front and storing a copy in a variable and then pushing it back into the list
				this->graph[this->index(curr->dest,offset)].push_back(edge);
				if (!visited[this->index(edge->dest,offset)]) // Check if the neighbor is unvisited and if so push it into the queue so it can be processed
				{
					q.push(edge);
				}
			}
		}
    }  
    return false; //If the destination is not found then return false
}

//
// Returns the weight of shortest path between origin and destination cities.
// Return -1 if no path exists.
//
int Graph::Dijkstra(char start, char dest)
{
	// TODO
	char offset = this->graph[0].front()->origin; //Get the offset
    int max = 50; //Initialize a max value that can be used as a placeholder for the maximum possible distance
    vector<int> dist(graph.size(), max); //Initialize a vector of ints to keep track of the distances from the origin to each vertex with each vertex initially set to the max value
    dist[this->index(start,offset)] = 0; //Set the distance of the origin to itself to 0
    vector<bool> visited(graph.size(), false); //Initialize a vector of bools to keep track of which vertices have been visited with initially all of them set to false since none have been visited
    vector<int> parent(graph.size(), -1); //Initialize a vector of ints to keep track of the parents of each vertex with each vertex initially set to -1
    int current = this->index(start,offset); //Set the current vertex to the starting vertex
    while(current != -1) //Keep running until all vertices have been visited or the destination is found
    {
        visited[current] = true; //Mark the current vertex as visited
        for(int i = 0; i < graph[current].size(); i++) //Iterate over the edges in the list of the current vertex
        {
            shared_ptr<Edge> edge = graph[current].front(); //Get the front edge
            graph[current].pop_front(); //Same strategy as above of popping the front and storing a copy in a variable and then pushing it back into the list
            graph[current].push_back(edge);
            char dest = edge->dest; //Get the destination of the edge
            int weight = edge->weight; //Get the weight of the edge
            if(dist[current] + weight < dist[this->index(dest,offset)]) //If the distance of the current vertex plus the weight of the edge is less than the distance of the destination vertex then update the distance of the destination vertex and parent
            {
                dist[this->index(dest,offset)] = dist[current] + weight; 
                parent[this->index(dest,offset)] = current;
            }
        }
        int minDist = max; //Initialize a variable to keep track of the minimum distance
        int nextVertex = -1; //Initialize a variable to keep track of the next vertex to visit
        for(int i = 0; i < graph.size(); i++) //Iterate over all vertices
        {
            if(!visited[i] && dist[i] < minDist) //If the vertex has not been visited and has a smaller distance than the current minimum distance then update the minimum distance and the next vertex to visit
            {
                minDist = dist[i];
                nextVertex = i;
            }
        }
        current = nextVertex; //Set the current vertex to the next vertex to visit
    }
    if(dist[this->index(dest,offset)] == max) //If the distance of the destination is still the max value then no path was found and return -1
    {
        return -1;
	}
	else
	{
		int cost = dist[this->index(dest,offset)]; //If the ditance is not the max value then a path was found and return the distance of the destination
		string path = "";
		path = DijkstraPath(dist, parent, dest,offset); //Get the path from the origin to the destination
		cout << "Shortest path from " << start << " to " << dest << " is " << path << " with cost " << dist[this->index(dest,offset)] << endl;
		return cost;
	}
}

string Graph::DijkstraPath(vector<int> dist, vector<int> parent, char dest, char offset)
{
	string path = ""; //Initialize a string to keep track of the path
	int curr = this->index(dest,offset); //Initialize a variable to keep track of the current vertex
	while(curr != -1) //Keep running until the current vertex is -1 meaning that the origin has been reached
	{
		path = string(1, offset + curr) + path; //Add the current vertex to the path
		curr = parent[curr]; //Update the current vertex to the parent of the current vertex
	}
	return path;
}

//
// Implement topological sort on the graph and return the string of the sorted cities
//
string Graph::topoSort()
{
	//TODO
	char offset = this->graph[0].front()->origin; //Get the offset
	vector<int> inDegree(graph.size(), 0); //Initialize a vector of ints to keep track of the in-degrees of each vertex with each vertex initially set to 0
	for(int i = 0; i < graph.size(); i++) //Iterate over the graph and update the in-degrees of each vertex
	{
		for(int j = 0; j < graph[i].size(); j++)
		{
			shared_ptr<Edge> edge = graph[i].front();
			graph[i].pop_front();
			graph[i].push_back(edge);
			inDegree[this->index(edge->dest,offset)]++;
		}
	}
    queue<int> q; //Initialize a queue of ints
    for (int i = 0; i < graph.size(); i++) //Iterate over the in-degrees and push the vertices with in-degree 0 into the queue
    {
        if (inDegree[i] == 0) 
        {
            q.push(i);
        }
    }
    string path = ""; //Initialize a string to keep track of the path
    while (!q.empty())  //Keep running until the queue is empty
    {
        int u = q.front(); //Get the front vertex
        q.pop(); //Pop the vertex so that the next vertex can be processed

        path += (char)(offset + u); //Add the vertex to the path with an offset of u to A which is then converted into the approptraite ACSII character

		for(int i = 0; i < graph[u].size(); i++) //Iterate over the edges in the list of the current vertex
		{
			shared_ptr<Edge> edge = graph[u].front(); //Get the front edge
			graph[u].pop_front();
			graph[u].push_back(edge);
			int v = this->index(edge->dest,offset); //Get the destination of the edge
			inDegree[v]--; //Decrement the in-degree of the destination vertex which is the same as removing the edge from the graph
			if (inDegree[v] == 0) //If the in-degree of the destination vertex is 0 then push it into the queue
			{
				q.push(v);
			}
		}
    }
    return path; //Return the path
}


#endif
