#!/bin/bash

parent_dir="/Users/haseeb/Desktop/TA assignment/4/Programming Assignment 4"
csv_file="/Users/haseeb/Desktop/TA assignment/4/Programming Assignment 4/grades4.csv"
# Get a list of directories in the parent directory
find "$parent_dir" -mindepth 1 -maxdepth 1 -type d -print0 | while IFS= read -r -d '' dir
do
  cd "$dir" 
  # Do something in the directory
  # cd "Submission attachment(s)"
  echo "$dir"
  number=$(echo "$dir" | grep -oE '\(([0-9]+)\)' | sed 's/[()]//g')
  echo "$number"
  cd "Submission attachment(s)"
  ls
  echo "$number"

done