#!/bin/bash

parent_dir="/Users/haseeb/Desktop/TA assignment/4/Programming Assignment 4"
csv_file="/Users/haseeb/Desktop/TA assignment/4/grades4.csv"
# Get a list of directories in the parent directory
find "$parent_dir" -mindepth 1 -maxdepth 1 -type d -print0 | while IFS= read -r -d '' dir
do
  cd "$dir" 
  # Do something in the directory
  # cd "Submission attachment(s)"
  echo "$dir"
  number=$(echo "$dir" | grep -oE '\(([0-9]+)\)' | sed 's/[()]//g')
#   echo "$number"
  cd "Submission attachment(s)" 
  sed -i '1s/^/#include <limits.h>\n/' Graph.cpp
#   cp /Users/haseeb/Downloads/PA4\ 3/* "/$dir/Submission attachment(s)/" && y
#   ls
  g++ test1.cpp -std=c++11
  output=$(./a.out)  # Run the command and capture the output
  part1=$(echo "$output" | grep "Display Test Passed" | cut -d":" -f2 | cut -d"/" -f1 | tr -d " ")
  g++ test2.cpp -std=c++11
  output=$(./a.out)  # Run the command and capture the output
  part2=0
  if [ "$output" = "Reachable Test Passed" ]; then
	part2=20
  fi
  
  # part 3
  g++ test3.cpp -std=c++11
  part3=0
  output=$(./a.out)
  last_line=$(echo "$output" | tail -n 1)
  if [ "$last_line" = "Shortest Path Test Passed" ]; then
        part3=30
  fi
  # part 4
  g++ test4.cpp -std=c++11
  part4=0
  output=$(./a.out)
  last_line=$(echo "$output" | tail -n 1)
  if [ "$last_line" = "Topological Sort Passed 30/30" ]; then
        part4=30
  fi
  # Add the marks to the grades.csv file
  echo "$number,$part1,$part2,$part3,$part4" >> "$csv_file"
done

done